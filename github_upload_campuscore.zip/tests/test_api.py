"""Unit and integration tests for FastAPI REST API routes."""

import pytest
from fastapi import HTTPException

from app.api import routes
from app.api.schemas import (
    ItemCreateSchema,
    ItemUpdateSchema,
    ReceiveStockSchema,
    IssueStockSchema,
    ImportPreviewRequest,
    ImportCommitRequest,
    BackupCreateRequest,
    SettingsUpdateSchema
)


class TestAPIRouteHandlers:
    def test_health_route(self, temp_environment, monkeypatch):
        res = routes.get_system_health()
        assert res["status"] == "healthy"
        assert "storage" in res
        assert res["storage"]["inventory_file_exists"] is True

    def test_dashboard_route(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])
        monkeypatch.setattr(routes, "pandas_reports", temp_environment["reports"])

        data = routes.get_dashboard_summary()
        assert "kpis" in data
        assert "category_summary" in data
        assert "critical_shortages" in data
        assert data["kpis"]["total_items"] == 5

    def test_inventory_list_and_search(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        # All items
        all_items = routes.list_inventory()
        assert len(all_items) == 5

        # Query filter
        filtered = routes.list_inventory(query="Gloves")
        assert len(filtered) == 2

    def test_get_single_item_success_and_404(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        item = routes.get_inventory_item("MED-T1")
        assert item["item_id"] == "MED-T1"

        with pytest.raises(HTTPException) as excinfo:
            routes.get_inventory_item("NON_EXISTENT_ID")
        assert excinfo.value.status_code == 404

    def test_add_inventory_item_and_duplicate_conflict(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        new_item = ItemCreateSchema(
            item_id="MED-API-TEST",
            item_name="API Bandage",
            category="Wound Care",
            unit="Roll",
            quantity=50,
            minimum_stock=20,
            expiry_date="2028-01-01",
            location="Room 1"
        )
        created = routes.add_inventory_item(new_item)
        assert created["item_id"] == "MED-API-TEST"

        # Duplicate attempt -> 409
        with pytest.raises(HTTPException) as excinfo:
            routes.add_inventory_item(new_item)
        assert excinfo.value.status_code == 409

    def test_update_and_delete_item(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        # Update
        updates = ItemUpdateSchema(item_name="Updated Gloves Name", quantity=110)
        updated = routes.update_inventory_item("MED-T1", updates)
        assert updated["item_name"] == "Updated Gloves Name"
        assert updated["quantity"] == 110

        # Delete
        del_res = routes.delete_inventory_item("MED-T1")
        assert del_res["status"] == "success"

        # Verify 404 after delete
        with pytest.raises(HTTPException) as excinfo:
            routes.get_inventory_item("MED-T1")
        assert excinfo.value.status_code == 404

    def test_receive_stock_route(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        payload = ReceiveStockSchema(
            item_id="MED-T2",
            quantity=25,
            reference="PO-API-99",
            remarks="API receipt"
        )
        res = routes.receive_stock(payload)
        assert res["item"]["quantity"] == 45  # 20 + 25
        assert res["transaction"]["transaction_type"] == "IN"

    def test_issue_stock_route_and_stockout_conflict(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        # Valid issue
        payload = IssueStockSchema(
            item_id="MED-T2",
            quantity=10,
            reference="REQ-API-01"
        )
        res = routes.issue_stock(payload)
        assert res["item"]["quantity"] == 10  # 20 - 10
        assert res["transaction"]["transaction_type"] == "OUT"

        # Excess issue -> Stockout 409
        excess_payload = IssueStockSchema(
            item_id="MED-T2",
            quantity=500
        )
        with pytest.raises(HTTPException) as excinfo:
            routes.issue_stock(excess_payload)
        assert excinfo.value.status_code == 409
        assert "StockoutWarningException" in str(excinfo.value.detail)

    def test_transactions_history(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        txs = routes.get_transactions()
        assert len(txs) >= 4

    def test_imports_preview_and_commit(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        csv_text = "item_id,item_name,category,unit,quantity,minimum_stock\nMED-IMP-API,Imp Item,General,Box,15,5\n"
        req_prev = ImportPreviewRequest(raw_csv=csv_text, target_entity="inventory")
        prev = routes.preview_import_csv(req_prev)
        assert prev["valid_count"] == 1
        assert prev["invalid_count"] == 0

        req_commit = ImportCommitRequest(raw_csv=csv_text, target_entity="inventory", reject_mode="reject_invalid")
        comm = routes.commit_import_csv(req_commit)
        assert comm["committed_count"] == 1

    def test_reports_endpoints(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "pandas_reports", temp_environment["reports"])
        monkeypatch.setattr(routes, "inventory_service", temp_environment["service"])

        low = routes.get_low_stock_report()
        assert isinstance(low, list)

        crit = routes.get_critical_stock_report()
        assert isinstance(crit, list)

        exp = routes.get_expiry_report()
        assert isinstance(exp, list)

        analytics = routes.get_numerical_analytics()
        assert "aggregate" in analytics
        assert "runway" in analytics

    def test_export_report_csv_endpoint(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "pandas_reports", temp_environment["reports"])

        resp = routes.export_report_csv("low-stock")
        assert resp.media_type == "text/csv"
        assert len(resp.body) > 0

    def test_backups_endpoints(self, temp_environment, monkeypatch):
        monkeypatch.setattr(routes, "backup_mgr", temp_environment["backup_mgr"])

        created = routes.create_backup(BackupCreateRequest(label="unit_api"))
        assert "backup_id" in created

        b_list = routes.list_backups()
        assert len(b_list) >= 1

    def test_logs_endpoint(self, temp_environment):
        diag_logs = routes.get_logs(log_type="diagnostic")
        assert isinstance(diag_logs, list)

        audit_logs = routes.get_logs(log_type="audit")
        assert isinstance(audit_logs, list)

    def test_settings_and_about_endpoints(self, temp_environment):
        about = routes.get_academic_info()
        assert about["course_code"] == "UC25CA2302"
        assert about["assessment_marks"] == 40

        settings = routes.get_settings()
        assert "critical_stock_ratio" in settings

        updated_settings = routes.update_settings(SettingsUpdateSchema(critical_stock_ratio=0.45))
        assert updated_settings["critical_stock_ratio"] == 0.45
