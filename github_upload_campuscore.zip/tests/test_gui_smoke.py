"""Smoke test for Tkinter Desktop GUI initialization and view instantiation."""

import pytest
import tkinter as tk
import os

from app.gui.app import MediStockApp


class TestGUISmoke:
    def test_gui_initialization_and_view_switching(self, temp_environment, monkeypatch):
        """Verify MediStockApp starts, mounts views, switches tabs, and destroys cleanly."""
        try:
            root = MediStockApp()
        except tk.TclError as e:
            pytest.skip(f"Tkinter display not available in current test environment: {e}")

        try:
            # Check title
            assert "MediStock Analytics" in root.title()

            # Test switching through all 10 views
            all_views = [
                "dashboard", "inventory", "transactions", "import",
                "alerts", "analytics", "backups", "logs", "settings", "about"
            ]

            for view_name in all_views:
                root.show_view(view_name)
                assert view_name in root.views
                assert root.current_view_name == view_name

            root.update()
        finally:
            root.destroy()
