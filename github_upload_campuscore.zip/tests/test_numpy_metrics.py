"""Unit tests for NumPy Analytics Engine.

Verifies mathematical accuracy of np.sum, np.mean, np.var, np.std,
zero-padded continuous date ranges, and runway calculations against hand-verified formulas.
"""

import pytest
import numpy as np

from app.models import Transaction, Item
from app.analytics.numpy_metrics import (
    calculate_consumption_metrics,
    calculate_item_runway_metrics,
    generate_date_range,
)


class TestNumPyMetrics:
    def test_hand_calculated_consumption_formulas(self):
        """Hand-Calculated Verification:

        Date range: 2026-10-01 to 2026-10-05 (5 days)
        Consumption data:
          - 2026-10-01: 10 units OUT
          - 2026-10-02: 0 units OUT (no transaction)
          - 2026-10-03: 20 units OUT
          - 2026-10-04: 0 units OUT (no transaction)
          - 2026-10-05: 10 units OUT
        Daily series: [10, 0, 20, 0, 10]

        Theoretical calculations:
          N = 5
          Sum = 10 + 0 + 20 + 0 + 10 = 40
          Mean = 40 / 5 = 8.0
          Deviations: [2, -8, 12, -8, 2]
          Sum of Squared Deviations = 4 + 64 + 144 + 64 + 4 = 280
          Population Variance (ddof=0) = 280 / 5 = 56.0
          Population Std Dev (ddof=0) = sqrt(56) = 7.4833
          Sample Variance (ddof=1) = 280 / 4 = 70.0
          Sample Std Dev (ddof=1) = sqrt(70) = 8.3666
        """
        txs = [
            Transaction("TX-1", "M1", "2026-10-01", "OUT", 10),
            Transaction("TX-2", "M1", "2026-10-03", "OUT", 20),
            Transaction("TX-3", "M1", "2026-10-05", "OUT", 10),
        ]

        metrics = calculate_consumption_metrics(
            txs, start_date="2026-10-01", end_date="2026-10-05"
        )

        assert metrics["days_in_period"] == 5
        assert metrics["total_consumed_units"] == 40
        assert metrics["average_daily_consumption"] == 8.0
        assert metrics["variance"] == 56.0
        assert metrics["std_deviation"] == 7.4833
        assert metrics["sample_variance"] == 70.0
        assert metrics["sample_std_deviation"] == 8.3666

    def test_empty_transaction_dataset(self):
        metrics = calculate_consumption_metrics([])
        assert metrics["total_consumed_units"] == 0
        assert metrics["average_daily_consumption"] == 0.0
        assert metrics["variance"] == 0.0
        assert metrics["std_deviation"] == 0.0

    def test_single_day_sample_variance_safety(self):
        txs = [Transaction("TX-1", "M1", "2026-10-01", "OUT", 15)]
        metrics = calculate_consumption_metrics(txs, start_date="2026-10-01", end_date="2026-10-01")
        assert metrics["days_in_period"] == 1
        assert metrics["total_consumed_units"] == 15
        assert metrics["average_daily_consumption"] == 15.0
        assert metrics["variance"] == 0.0
        # N=1 cannot compute sample variance (division by zero avoided)
        assert metrics["sample_variance"] == 0.0

    def test_item_runway_and_days_remaining(self):
        items = [
            Item("M1", "Gloves", "PPE", "Box", quantity=100, minimum_stock=20),
            Item("M2", "Expired Mask", "PPE", "Box", quantity=50, minimum_stock=10, expiry_date="2020-01-01"),
            Item("M3", "Unused Bandage", "Wound Care", "Roll", quantity=40, minimum_stock=10),
        ]
        # Transactions over 30 days
        txs = [
            Transaction(f"T{i}", "M1", "2026-10-15", "OUT", 2) for i in range(15)
        ]  # Total 30 units over 30 days = 1.0 unit/day

        runway = calculate_item_runway_metrics(items, txs, lookback_days=30)
        m1_metrics = next(r for r in runway if r["item_id"] == "M1")
        m2_metrics = next(r for r in runway if r["item_id"] == "M2")
        m3_metrics = next(r for r in runway if r["item_id"] == "M3")

        # M1 has usable stock 100, daily rate 1.0 -> 100 days remaining
        assert m1_metrics["total_lookback_consumed"] == 30
        assert m1_metrics["average_daily_rate"] == 1.0
        assert m1_metrics["estimated_days_remaining"] == 100.0

        # M2 is expired, usable stock is 0 -> days remaining is 0 or undefined
        assert m2_metrics["usable_stock"] == 0

        # M3 has no consumption -> days remaining is None (not division by zero)
        assert m3_metrics["average_daily_rate"] == 0.0
        assert m3_metrics["estimated_days_remaining"] is None
