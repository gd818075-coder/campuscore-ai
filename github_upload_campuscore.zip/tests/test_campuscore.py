"""
Comprehensive Test Suite for CampusCore AI Smart Campus Management System
Tests all 11 modules, database operations, and AI capabilities.
"""

import pytest
import json
from app import app

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_system_status(client):
    res = client.get("/api/system/status")
    assert res.status_code == 200
    data = res.get_json()
    assert data["success"] is True
    assert data["tables_verified"] == 18
    assert data["counts"]["students"] >= 12

def test_auth_me_and_role_switch(client):
    res = client.get("/api/auth/me")
    assert res.status_code == 200
    user = res.get_json()["user"]
    assert "role" in user

    # Switch to Faculty
    res2 = client.post("/api/auth/switch-role", json={"role": "Faculty"})
    assert res2.status_code == 200
    assert res2.get_json()["user"]["role"] == "Faculty"

    # Switch back to Administrator
    client.post("/api/auth/switch-role", json={"role": "Administrator"})

def test_dashboard_stats_and_charts(client):
    res1 = client.get("/api/dashboard/stats")
    assert res1.status_code == 200
    stats = res1.get_json()["stats"]
    assert stats["total_students"] >= 12
    assert stats["total_faculty"] >= 6
    assert stats["average_attendance"] > 0

    res2 = client.get("/api/dashboard/charts")
    assert res2.status_code == 200
    charts = res2.get_json()["charts"]
    assert len(charts["department_students"]) > 0
    assert len(charts["subject_scores"]) > 0

def test_students_crud(client):
    # GET list
    res = client.get("/api/students")
    assert res.status_code == 200
    initial_count = res.get_json()["total"]

    # POST new student
    new_reg = f"TEST{initial_count + 100}"
    new_student = {
        "reg_number": new_reg,
        "first_name": "Test",
        "last_name": "Student",
        "email": f"{new_reg.lower()}@student.campuscore.edu",
        "phone": "+91 9999900000",
        "cgpa": 8.75
    }
    res_post = client.post("/api/students", json=new_student)
    assert res_post.status_code == 201
    created_id = res_post.get_json()["student_id"]

    # GET detail
    res_detail = client.get(f"/api/students/{created_id}")
    assert res_detail.status_code == 200
    assert res_detail.get_json()["student"]["first_name"] == "Test"

    # DELETE cleanup
    res_del = client.delete(f"/api/students/{created_id}")
    assert res_del.status_code == 200

def test_ai_chatbot(client):
    res = client.post("/api/ai/chat", json={"message": "What is the 75 attendance shortage rule?"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["success"] is True
    assert "75%" in data["data"]["answer"]

def test_ai_academic_assistance(client):
    # Test Notes
    res1 = client.post("/api/ai/academic-assist", json={
        "task_type": "notes",
        "topic": "Heuristic Search Algorithms in Artificial Intelligence",
        "difficulty": "Intermediate"
    })
    assert res1.status_code == 200
    assert "Study Notes" in res1.get_json()["result"]["content"]

    # Test Quiz
    res2 = client.post("/api/ai/academic-assist", json={
        "task_type": "quiz",
        "topic": "Python Object Oriented Programming",
        "difficulty": "Foundational"
    })
    assert res2.status_code == 200
    assert "Quiz" in res2.get_json()["result"]["content"]

def test_student_performance_analysis(client):
    res = client.get("/api/marks/student/1")
    assert res.status_code == 200
    analysis = res.get_json()["analysis"]
    assert analysis["student_name"] == "Aarav Sharma"
    assert "Tier" in analysis["tier"]
    assert len(analysis["strengths"]) > 0

def test_attendance_analysis(client):
    res = client.get("/api/attendance/summary")
    assert res.status_code == 200
    summaries = res.get_json()["summaries"]
    assert len(summaries) >= 12
    # Ensure shortage calculation is performed
    shortages = [s for s in summaries if s["is_shortage"]]
    assert len(shortages) > 0

def test_feedback_sentiment(client):
    res = client.post("/api/feedback", json={
        "category": "Faculty & Teaching",
        "target_name": "Dr. Vikram Malhotra",
        "rating": 5,
        "comments": "The lecture was very engaging and crystal clear! Loved the hands-on AI demo."
    })
    assert res.status_code == 200
    data = res.get_json()
    assert data["sentiment"] == "Positive"
    assert data["sentiment_score"] > 0.6

def test_career_guidance(client):
    res = client.post("/api/ai/career-guidance", json={
        "skills": "Python, Machine Learning, TensorFlow",
        "interests": "Deep learning and natural language processing",
        "domain": "Artificial Intelligence"
    })
    assert res.status_code == 200
    rec = res.get_json()["career_recommendation"]
    assert "AI & Machine Learning Engineer" in rec["recommended_role"]
    assert len(rec["roadmap"]) == 4

def test_responsible_ai_logs(client):
    res = client.get("/api/ai/responsible-logs")
    assert res.status_code == 200
    logs = res.get_json()["logs"]
    assert len(logs) > 0

def test_csv_export(client):
    res = client.get("/api/reports/students.csv")
    assert res.status_code == 200
    assert "text/csv" in res.content_type
    assert b"Reg Number" in res.data


def test_events_and_registration(client):
    res = client.get("/api/events")
    assert res.status_code == 200
    events = res.get_json()["events"]
    assert len(events) >= 5

    # Register student for event 1
    res_reg = client.post("/api/events/1/register", json={"student_id": 10})
    assert res_reg.status_code in [200, 409]

def test_resources_and_booking(client):
    res = client.get("/api/resources")
    assert res.status_code == 200
    resources = res.get_json()["resources"]
    assert len(resources) >= 6

    # Book resource
    res_book = client.post("/api/resources/book", json={
        "resource_id": 1,
        "purpose": "Special AI Workshop Session",
        "time_slot": "04:30 PM - 06:30 PM",
        "booking_date": "2024-12-20"
    })
    assert res_book.status_code in [200, 409]

def test_ai_content_generator(client):
    res = client.post("/api/ai/content-generate", json={
        "content_type": "announcement",
        "topic": "Annual Hackathon Grand Finale",
        "tone": "Formal Academic"
    })
    assert res.status_code == 200
    content = res.get_json()["content"]["content"]
    assert "CIRCULAR" in content or "OFFICIAL" in content

def test_html_frontend_serves(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"CampusCore AI" in res.data
    assert b"id=\"root\"" in res.data


def test_admissions_inquiry_flow(client):
    # Submit inquiry from public university website
    res = client.post("/api/admissions/inquire", json={
        "full_name": "Test Candidate",
        "email": "test.candidate@gmail.com",
        "phone": "+91 9988776655",
        "program_interested": "BCA with AI Specialization",
        "academic_score": 89.5,
        "message": "Inquiring about admission cutoff and hostel."
    })
    assert res.status_code == 201
    inquiry_id = res.get_json()["inquiry_id"]

    # Admin lists inquiries
    res_list = client.get("/api/admissions")
    assert res_list.status_code == 200
    inquiries = res_list.get_json()["inquiries"]
    assert any(i["inquiry_id"] == inquiry_id for i in inquiries)

    # Admin updates inquiry status
    res_update = client.put(f"/api/admissions/{inquiry_id}/status", json={"status": "Admitted"})
    assert res_update.status_code == 200
    assert "Admitted" in res_update.get_json()["message"]

def test_public_university_info_and_contact(client):
    res_info = client.get("/api/public/university-info")
    assert res_info.status_code == 200
    data = res_info.get_json()
    assert "GM Smart University" in data["name"]

    res_contact = client.post("/api/contact", json={
        "name": "Alumni Association",
        "email": "alumni@gmuniversity.edu",
        "subject": "Annual Alumni Meet",
        "message": "Scheduling the alumni reunion event."
    })
    assert res_contact.status_code == 201

def test_separate_auth_portals(client):
    # 1. Admin login valid
    res_admin = client.post("/api/auth/admin/login", json={
        "identifier": "admin",
        "password": "password123"
    })
    assert res_admin.status_code == 200
    assert res_admin.get_json()["user"]["role"] == "Administrator"

    # 2. Faculty login valid (by employee code or username)
    res_fac = client.post("/api/auth/faculty/login", json={
        "identifier": "dr_vikram",
        "password": "password123"
    })
    assert res_fac.status_code == 200
    assert res_fac.get_json()["user"]["role"] == "Faculty"

    # 3. Student login valid (by registration number)
    res_stu = client.post("/api/auth/student/login", json={
        "identifier": "BCA24001",
        "password": "password123"
    })
    assert res_stu.status_code == 200
    assert res_stu.get_json()["user"]["role"] == "Student"

    # 4. Role Isolation: Student trying to use Admin portal -> 403 Forbidden
    res_breach = client.post("/api/auth/admin/login", json={
        "identifier": "BCA24001",
        "password": "password123"
    })
    assert res_breach.status_code == 403
    assert "Student" in res_breach.get_json()["message"]

    # 5. Invalid credentials -> 401 Unauthorized
    res_bad = client.post("/api/auth/admin/login", json={
        "identifier": "admin",
        "password": "wrongpassword"
    })
    assert res_bad.status_code == 401

def test_fees_and_timetable_endpoints(client):
    # Fees listing
    res_fees = client.get("/api/fees")
    assert res_fees.status_code == 200
    records = res_fees.get_json()["records"]
    assert len(records) > 0
    assert "payments" in records[0]

    # Process fee payment
    rec_id = records[0]["fee_record_id"]
    res_pay = client.post("/api/fees/pay", json={
        "fee_record_id": rec_id,
        "amount_paid": 5000.0,
        "payment_mode": "UPI Reference",
        "transaction_ref": "UPI/TEST/998877"
    })
    assert res_pay.status_code == 200
    assert "REC-" in res_pay.get_json()["receipt_number"]

    # Timetable listing
    res_tt = client.get("/api/timetable")
    assert res_tt.status_code == 200
    schedules = res_tt.get_json()["timetable"]
    assert len(schedules) > 0
    assert "time_slot" in schedules[0]

    # Users list (Admin)
    res_users = client.get("/api/users")
    assert res_users.status_code == 200
    users = res_users.get_json()["users"]
    assert len(users) >= 3
