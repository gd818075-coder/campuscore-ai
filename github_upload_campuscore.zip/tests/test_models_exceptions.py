"""Unit tests for domain models, validation logic, and exception hierarchy.

Validates CO4 and assignment exception specifications.
"""

import pytest
import math
from datetime import date

from app.exceptions import (
    MedicalInventoryError,
    StockoutWarningException,
    CorruptedDataRecordException,
    InvalidQuantityException,
    DuplicateRecordException,
    UnknownItemException,
    StorageOperationException,
    BackupOperationException,
)
from app.models import (
    Item,
    Transaction,
    parse_and_validate_quantity,
    validate_iso_date,
    sanitize_csv_field,
)


class TestExceptionHierarchy:
    def test_custom_exception_inheritance(self):
        """Verify that all custom exceptions derive from MedicalInventoryError."""
        custom_exceptions = [
            StockoutWarningException,
            CorruptedDataRecordException,
            InvalidQuantityException,
            DuplicateRecordException,
            UnknownItemException,
            StorageOperationException,
            BackupOperationException,
        ]
        for exc_cls in custom_exceptions:
            assert issubclass(exc_cls, MedicalInventoryError)
            assert issubclass(exc_cls, Exception)

    def test_exception_serialization(self):
        """Verify to_dict returns structured diagnostic info."""
        exc = StockoutWarningException("Not enough stock", details={"item_id": "M1", "available": 2})
        data = exc.to_dict()
        assert data["error_type"] == "StockoutWarningException"
        assert data["message"] == "Not enough stock"
        assert data["details"]["item_id"] == "M1"


class TestQuantityParsing:
    def test_valid_integer_quantities(self):
        assert parse_and_validate_quantity(10) == 10
        assert parse_and_validate_quantity("25") == 25
        assert parse_and_validate_quantity(0, allow_zero=True) == 0
        assert parse_and_validate_quantity(15.0) == 15

    def test_reject_negative_quantity(self):
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(-5)

    def test_reject_fractional_quantities(self):
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(12.34)
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity("12.5")

    def test_reject_nan_and_inf(self):
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(float("nan"))
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(float("inf"))

    def test_reject_boolean_and_empty(self):
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(True)
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity("")
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(None)

    def test_reject_zero_when_forbidden(self):
        with pytest.raises(InvalidQuantityException):
            parse_and_validate_quantity(0, allow_zero=False)


class TestDateValidation:
    def test_valid_iso_dates(self):
        assert validate_iso_date("2028-12-31") == "2028-12-31"
        assert validate_iso_date("", required=False) == ""

    def test_invalid_date_formats(self):
        with pytest.raises(CorruptedDataRecordException):
            validate_iso_date("31-12-2028")
        with pytest.raises(CorruptedDataRecordException):
            validate_iso_date("2028/12/31")
        with pytest.raises(CorruptedDataRecordException):
            validate_iso_date("not-a-date")


class TestCSVFormulaInjectionSanitization:
    def test_formula_prefix_escaping(self):
        assert sanitize_csv_field("=cmd|' /C calc'!A0") == "'=cmd|' /C calc'!A0"
        assert sanitize_csv_field("+12345") == "'+12345"
        assert sanitize_csv_field("-100") == "'-100"
        assert sanitize_csv_field("@SUM(A1:A5)") == "'@SUM(A1:A5)"
        assert sanitize_csv_field("Normal Medicine") == "Normal Medicine"


class TestItemModel:
    def test_item_instantiation_and_usable_stock(self):
        item = Item.from_dict({
            "item_id": "MED-01",
            "item_name": "Surgical Mask",
            "category": "PPE",
            "unit": "Box",
            "quantity": 100,
            "minimum_stock": 50,
            "expiry_date": "2028-01-01",
            "location": "Warehouse A"
        })
        assert item.item_id == "MED-01"
        assert item.usable_quantity == 100
        assert not item.is_expired()
        assert item.get_stock_status() == "Normal"

    def test_expired_item_quarantine(self):
        item = Item.from_dict({
            "item_id": "MED-EXP",
            "item_name": "Old Saline",
            "category": "Fluids",
            "unit": "Bottle",
            "quantity": 50,
            "minimum_stock": 20,
            "expiry_date": "2020-01-01",
            "location": "Quarantine"
        })
        assert item.is_expired()
        assert item.get_usable_quantity() == 0  # Expired stock cannot be used
        assert item.get_stock_status() == "Expired"

    def test_stock_status_levels(self):
        # Critical stock (<= 50% min stock)
        it_crit = Item.from_dict({
            "item_id": "MED-C", "item_name": "Critical Med", "category": "General",
            "unit": "Box", "quantity": 10, "minimum_stock": 40
        })
        assert it_crit.get_stock_status() == "Critical"

        # Low stock (<= min stock)
        it_low = Item.from_dict({
            "item_id": "MED-L", "item_name": "Low Med", "category": "General",
            "unit": "Box", "quantity": 30, "minimum_stock": 40
        })
        assert it_low.get_stock_status() == "Low Stock"
