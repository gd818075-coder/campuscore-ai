"""Pytest configuration and fixtures for CampusCore AI Smart Campus Management System."""

import pytest
from app import app as campuscore_app

@pytest.fixture
def client():
    campuscore_app.config["TESTING"] = True
    with campuscore_app.test_client() as c:
        yield c
