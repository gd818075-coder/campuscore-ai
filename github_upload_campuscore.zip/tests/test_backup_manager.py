"""Unit tests for BackupManager: snapshot creation, validation, retention, and restore."""

import pytest
from pathlib import Path
from app.exceptions import BackupOperationException
from app.repository.backup_manager import BackupManager


class TestBackupManager:
    def test_create_and_validate_backup(self, temp_environment):
        backup_mgr: BackupManager = temp_environment["backup_mgr"]
        res = backup_mgr.create_backup(label="test_run")
        assert res["backup_id"].startswith("backup_test_run_")
        assert Path(res["path"]).exists()

        # Check validation
        val = backup_mgr.validate_backup(Path(res["path"]))
        assert val["valid"] is True
        assert "inventory.csv" in val["files"]
        assert "consumption.csv" in val["files"]
        assert val["manifest"]["label"] == "test_run"

    def test_list_backups(self, temp_environment):
        backup_mgr: BackupManager = temp_environment["backup_mgr"]
        backup_mgr.create_backup(label="b1")
        backup_mgr.create_backup(label="b2")
        backups = backup_mgr.list_backups()
        assert len(backups) >= 2
        assert any("b1" in b["backup_id"] for b in backups)
        assert any("b2" in b["backup_id"] for b in backups)

    def test_restore_backup(self, temp_environment):
        backup_mgr: BackupManager = temp_environment["backup_mgr"]
        inv_file = temp_environment["inv_path"]

        # Step 1: Create initial backup
        snap = backup_mgr.create_backup(label="initial_state")

        # Step 2: Mutate live inventory
        inv_file.write_text("item_id,item_name,category,unit,quantity,minimum_stock,expiry_date,location\n", encoding="utf-8")
        assert inv_file.stat().st_size < 100

        # Step 3: Restore
        backup_mgr.restore_backup(snap["backup_id"])

        # Step 4: Verify restored contents
        content = inv_file.read_text(encoding="utf-8")
        assert "MED-T1" in content

    def test_validate_corrupted_backup_raises_exception(self, temp_environment):
        backup_mgr: BackupManager = temp_environment["backup_mgr"]
        corrupt_zip = temp_environment["backup_dir"] / "backup_corrupted.zip"
        corrupt_zip.write_text("not a valid zip file binary stream", encoding="utf-8")

        with pytest.raises(BackupOperationException):
            backup_mgr.validate_backup(corrupt_zip)
