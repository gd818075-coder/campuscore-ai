"""Unit tests for CSVRepository: atomic file replacement, WAL recovery, schema integrity."""

import pytest
import os
import json
from pathlib import Path

from app.exceptions import CorruptedDataRecordException, StorageOperationException
from app.models import Item, Transaction
from app.repository.csv_repository import CSVRepository


class TestCSVRepository:
    def test_load_inventory_items(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        items = repo.load_inventory_items()
        assert len(items) == 5
        assert items[0].item_id == "MED-T1"
        assert items[0].quantity == 100

    def test_save_inventory_items_atomic(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        items = repo.load_inventory_items()
        items[0].quantity = 150
        repo.save_inventory_items(items)

        # Reload directly and assert
        reloaded = repo.load_inventory_items()
        assert reloaded[0].quantity == 150

    def test_load_transactions(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        txs = repo.load_transactions()
        assert len(txs) == 4
        assert txs[0].transaction_id == "TX-T1"
        assert txs[0].transaction_type == "IN"

    def test_missing_header_raises_corrupted_data(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        bad_inv = temp_environment["inv_path"]
        # Write corrupted header
        bad_inv.write_text("item_id,item_name\nM1,Mask", encoding="utf-8")

        with pytest.raises(CorruptedDataRecordException) as excinfo:
            repo.load_inventory_items()
        assert "missing required headers" in str(excinfo.value).lower()

    def test_malformed_csv_row_raises_corrupted_data(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        bad_inv = temp_environment["inv_path"]
        # Bad quantity format
        bad_inv.write_text(
            "item_id,item_name,category,unit,quantity,minimum_stock,expiry_date,location\n"
            "M1,Mask,PPE,Box,not_a_number,10,2028-01-01,Shelf 1\n",
            encoding="utf-8"
        )
        with pytest.raises(CorruptedDataRecordException):
            repo.load_inventory_items()

    def test_commit_stock_mutation_multi_file(self, temp_environment):
        repo: CSVRepository = temp_environment["repo"]
        items = repo.load_inventory_items()
        items[0].quantity += 20

        new_tx = Transaction(
            transaction_id="TX-TEST-NEW",
            item_id=items[0].item_id,
            transaction_date="2026-10-28",
            transaction_type="IN",
            quantity=20,
            reference="PO-TEST",
            remarks="Test mutation"
        )

        repo.commit_stock_mutation(items, new_tx)

        # Verify both files updated
        updated_items = repo.load_inventory_items()
        updated_txs = repo.load_transactions()
        assert updated_items[0].quantity == 120
        assert any(t.transaction_id == "TX-TEST-NEW" for t in updated_txs)
        # Verify journal file was cleaned up
        assert not repo.journal_file.exists()

    def test_journal_recovery_on_startup(self, temp_environment):
        """Simulate crash during commit leaving pending journal and staged files."""
        data_dir = temp_environment["data_dir"]
        jrn_file = data_dir / "journal.json"
        staged_dummy = data_dir / ".staged_dummy.csv"
        staged_dummy.write_text("dummy staged data", encoding="utf-8")

        journal_payload = {
            "status": "PREPARED",
            "transaction_id": "TX-ORPHAN",
            "staged_files": [str(staged_dummy)]
        }
        jrn_file.write_text(json.dumps(journal_payload), encoding="utf-8")

        # Initialize repository which must trigger _recover_journal_if_needed
        new_repo = CSVRepository(data_dir=data_dir, journal_file=jrn_file)
        assert not staged_dummy.exists(), "Orphaned staged file should be cleaned up"
        assert not jrn_file.exists(), "Pending journal should be cleared"
