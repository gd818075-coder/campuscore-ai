"""Unit tests for InventoryService: business logic, stock transactions, import validation."""

import pytest
import threading

from app.exceptions import (
    StockoutWarningException,
    InvalidQuantityException,
    DuplicateRecordException,
    UnknownItemException,
    CorruptedDataRecordException
)
from app.services.inventory_service import InventoryService


class TestInventoryService:
    def test_get_all_and_search(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        items = service.get_all_items()
        assert len(items) == 5

        # Search by query
        results = service.search_items(query="Gloves")
        assert len(results) == 2

        # Filter by category
        results_cat = service.search_items(category="Syringes & Needles")
        assert len(results_cat) == 1
        assert results_cat[0].item_id == "MED-T3"

    def test_add_item_and_prevent_duplicate(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        new_item_data = {
            "item_id": "MED-NEW-1",
            "item_name": "Test Oxygen Mask",
            "category": "Respiratory",
            "unit": "Piece",
            "quantity": 50,
            "minimum_stock": 20,
            "expiry_date": "2028-10-10",
            "location": "Ward Store"
        }
        added = service.add_item(new_item_data)
        assert added.item_id == "MED-NEW-1"
        assert service.get_item_by_id("MED-NEW-1").quantity == 50

        # Attempt duplicate insertion
        with pytest.raises(DuplicateRecordException):
            service.add_item(new_item_data)

    def test_receive_stock_success(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        updated_item, tx = service.receive_stock(
            item_id="MED-T1",
            quantity=30,
            reference="PO-TEST-REC",
            remarks="Unit test receipt"
        )
        assert updated_item.quantity == 130
        assert tx.quantity == 30
        assert tx.transaction_type == "IN"

    def test_issue_stock_success(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        updated_item, tx = service.issue_stock(
            item_id="MED-T1",
            quantity=25,
            reference="REQ-TEST-ISSUE"
        )
        assert updated_item.quantity == 75
        assert tx.quantity == 25
        assert tx.transaction_type == "OUT"

    def test_issue_stock_stockout_warning_exception(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        # Available stock is 100
        with pytest.raises(StockoutWarningException) as excinfo:
            service.issue_stock(item_id="MED-T1", quantity=150)
        assert "Insufficient usable stock" in str(excinfo.value)
        # Verify committed quantity remains untouched
        assert service.get_item_by_id("MED-T1").quantity == 100

    def test_issue_expired_stock_rejected(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        # MED-T4 has physical stock 50, but expired in 2025
        with pytest.raises(StockoutWarningException) as excinfo:
            service.issue_stock(item_id="MED-T4", quantity=5)
        assert "Cannot issue expired medical supply" in str(excinfo.value)

    def test_reject_negative_or_zero_issue_quantity(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        with pytest.raises(InvalidQuantityException):
            service.issue_stock(item_id="MED-T1", quantity=0)
        with pytest.raises(InvalidQuantityException):
            service.issue_stock(item_id="MED-T1", quantity=-10)

    def test_concurrent_mutations_thread_safety(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        # Concurrently issue 1 unit 20 times across multiple threads
        errors = []

        def worker():
            try:
                service.issue_stock(item_id="MED-T1", quantity=1, reference="THREAD-ISSUE")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        final_item = service.get_item_by_id("MED-T1")
        assert final_item.quantity == 80  # 100 - 20

    def test_preview_and_commit_import_csv(self, temp_environment):
        service: InventoryService = temp_environment["service"]
        csv_payload = (
            "item_id,item_name,category,unit,quantity,minimum_stock,expiry_date,location\n"
            "MED-IMP-1,New Bandage,Wound Care,Roll,200,50,2028-01-01,Rack 5\n"
            "MED-IMP-2,Bad Stock,Wound Care,Roll,-20,50,2028-01-01,Rack 5\n"
        )
        preview = service.preview_import_csv(csv_payload, target_entity="inventory")
        assert preview["valid_count"] == 1
        assert preview["invalid_count"] == 1
        assert "cannot be negative" in preview["invalid_rows"][0]["reason"]

        # Commit with reject_invalid mode
        commit_res = service.commit_import_csv(csv_payload, target_entity="inventory", reject_mode="reject_invalid")
        assert commit_res["committed_count"] == 1
        assert commit_res["rejected_count"] == 1
        assert service.get_item_by_id("MED-IMP-1").quantity == 200
