"""Unit tests for Pandas Reporting and Analytics module."""

import pytest
import pandas as pd
from app.analytics.pandas_reports import PandasReports


class TestPandasReports:
    def test_get_inventory_df(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df = reports.get_inventory_df()
        assert not df.empty
        assert "usable_quantity" in df.columns
        assert "is_expired" in df.columns
        assert "stock_status" in df.columns
        # MED-T4 was expired in 2025
        t4_row = df[df["item_id"] == "MED-T4"].iloc[0]
        assert t4_row["is_expired"] is True or t4_row["is_expired"] == 1
        assert t4_row["usable_quantity"] == 0

    def test_low_stock_report(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_low = reports.generate_low_stock_report()
        # In sample data:
        # MED-T2: qty 20 <= min 40 (Shortage = 20)
        # MED-T3: qty 10 <= min 50 (Shortage = 40)
        assert len(df_low) >= 2
        assert "MED-T3" in df_low["item_id"].values
        assert "MED-T2" in df_low["item_id"].values

    def test_critical_stock_report(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_crit = reports.generate_critical_stock_report(ratio=0.5)
        # MED-T3: min 50, critical threshold 25. Qty = 10 <= 25 -> Critical!
        # MED-T2: min 40, critical threshold 20. Qty = 20 <= 20 -> Critical!
        assert "MED-T3" in df_crit["item_id"].values

    def test_expiry_report(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_exp = reports.generate_expiry_report(near_expiry_days=60)
        assert not df_exp.empty
        assert "MED-T4" in df_exp["item_id"].values
        assert df_exp[df_exp["item_id"] == "MED-T4"].iloc[0]["expiry_category"] == "Expired (Do Not Use)"

    def test_category_summary(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_cat = reports.generate_category_summary()
        assert not df_cat.empty
        assert "category" in df_cat.columns
        assert "total_physical_units" in df_cat.columns
        assert "total_usable_units" in df_cat.columns

    def test_daily_consumption_report(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_daily = reports.generate_daily_consumption_report()
        assert not df_daily.empty
        assert "units_issued" in df_daily.columns
        assert "transaction_date" in df_daily.columns

    def test_export_report_to_csv(self, temp_environment):
        reports: PandasReports = temp_environment["reports"]
        df_low = reports.generate_low_stock_report()
        out_csv = temp_environment["temp_dir"] / "test_low_export.csv"
        saved_path = reports.export_report_to_csv(df_low, out_csv)
        assert out_csv.exists()
        read_back = pd.read_csv(out_csv)
        assert len(read_back) == len(df_low)
