import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import apiRoutes from './server/routes/apiRoutes.ts';
import { initDatabase } from './server/db/connection.ts';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Middleware for parsing JSON and urlencoded requests
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Mount REST API routes
app.use('/api', apiRoutes);

async function startServer() {
  console.log('----------------------------------------------------');
  console.log('   CAMPUSCORE: STUDENT MANAGEMENT DATABASE SYSTEM   ');
  console.log('   Semester 3 BCA DBMS Project-Based Learning       ');
  console.log('----------------------------------------------------');

  try {
    console.log('[CampusCore DB] Initializing database engine...');
    const dbStatus = await initDatabase();
    console.log(`[CampusCore DB] Active Engine: ${dbStatus.activeEngine}`);
    console.log(`[CampusCore DB] Tables: ${dbStatus.tablesCount} | Total Tuples: ${dbStatus.totalRecordsCount}`);
    if (dbStatus.mysqlConnected) {
      console.log(`[CampusCore DB] Connected to MySQL 8 on ${dbStatus.mysqlHost}:${dbStatus.mysqlPort}/${dbStatus.mysqlDatabase}`);
    } else {
      console.log(`[CampusCore DB] MySQL status: ${dbStatus.mysqlError}`);
      console.log(`[CampusCore DB] Running with In-Process Relational SQL Engine (sql.js) for live demo execution.`);
    }
  } catch (err: any) {
    console.error('[CampusCore DB] Database initialization error:', err.message);
  }

  if (!isProd) {
    // Mount Vite dev server in middleware mode
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {}
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve static dist assets
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CampusCore Server] Listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[CampusCore Server] Fatal error during startup:', err);
  process.exit(1);
});
