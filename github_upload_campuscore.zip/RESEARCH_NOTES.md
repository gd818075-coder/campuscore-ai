# RESEARCH NOTES: MediStock Analytics

## 1. Domain & Workflow Research: Medical Supply Inventory Systems

### 1.1 Industry Benchmark Analysis (Sortly & Zoho Inventory)
- **Sortly Medical Supplies Paradigm**:
  - Focuses on visual tracking, low-stock threshold triggers, lot/expiry date monitoring, and mobile/desktop quick scans.
  - Critical distinction between **Total Physical Stock** and **Usable/Available Stock**: expired medical supplies cannot be dispensed to patients and must be immediately quarantined or flagged.
  - Reorder points (minimum stock levels) must trigger tiered warnings: Warning (at or below minimum stock) vs. Critical Shortage (e.g., at or below 50% minimum stock).
- **Zoho Inventory Transaction Pattern**:
  - Double-entry or directional movement: Stock Receipts (`IN`) and Stock Issues/Dispatches (`OUT`).
  - Strict non-negative quantity constraints: dispensing cannot result in negative stock; transactions must be rejected atomically before updating persistent state.
  - Audit trail immutability: transactions cannot be silently deleted or edited without an offsetting counter-transaction or clear audit trail.

### 1.2 Information Architecture & User Experience
- Standard modern medical software utilizes a **clean, light-theme palette** (white `#FFFFFF`, clinical slate/blue `#0284C7` / `#2563EB`, neutral grays `#F8FAFC` to `#1E293B`, with functional accents: emerald `#10B981` for sufficient stock, amber `#F59E0B` for warning/low stock, and crimson `#EF4444` for critical/expired supplies).
- High visual contrast, generous touch/click targets, clear tabular data grids with sortable columns, and instant responsive feedback reduce medical errors.

---

## 2. Technical Standards & References

### 2.1 Python Tkinter & ttk Light-Theme Architecture
- **Official Documentation**: Python 3.11/3.14 `tkinter` and `tkinter.ttk` module specifications.
- **Theme Architecture**:
  - Use `ttk.Style` with a clean modern theme (such as `'clam'` or `'alt'`) styled with explicit color hexes matching the medical light theme.
  - Geometry manager discipline: strictly adhere to either `pack` or `grid` per container/parent widget; mixing `grid` and `pack` inside the same frame leads to geometry loop crashes.
  - Thread safety: Tkinter is not thread-safe for background worker updates. Background threads must communicate with the GUI via event queues (`queue.Queue`) or `root.after()`.
  - Accessible dialogs: Use standard modal `tkinter.simpledialog` and custom `Toplevel` dialogs with grab (`grab_set()`) and transient binding (`transient(parent)`).

### 2.2 Pandas DataFrame Processing Best Practices
- **Official Documentation**: pandas.pydata.org (Pandas 3.x / 2.x API).
- Safe CSV reading: Use `dtype` dictionaries, explicit `parse_dates` or explicit `pd.to_datetime(..., format='%Y-%m-%d', errors='coerce')` to prevent silent corruption.
- Vectorized filtering: Boolean masks `(df['quantity'] <= df['minimum_stock']) & (df['usable'] == True)` rather than iterating row-by-row.
- Grouping & Aggregations: `df.groupby('category').agg(...)` for category distribution, handling empty groups without `NaN`.
- Exporting: Use `df.to_csv(path, index=False)` with UTF-8 encoding.

### 2.3 NumPy Numerical Analytics
- **Official Documentation**: numpy.org API reference for `np.sum`, `np.mean`, `np.var`, `np.std`.
- **Statistical Conventions**:
  - `np.var(a, ddof=0)` computes the **population variance**: \(\sigma^2 = \frac{1}{N}\sum (x_i - \mu)^2\).
  - `np.var(a, ddof=1)` computes the **sample variance**: \(s^2 = \frac{1}{N-1}\sum (x_i - \bar{x})^2\).
  - MediStock Analytics standardizes on **population statistics** (`ddof=0`) as default for inventory audit batches, while clearly indicating and documenting formula parameters.
- **Handling Zero and Missing Days**:
  - Daily consumption calculation must span the complete user-selected date range including days with 0 consumption. Calculating average daily consumption only from transaction days creates significant upward bias.
  - Days remaining calculation: \(\text{Days Remaining} = \frac{\text{Usable Stock}}{\text{Average Daily Consumption}}\) (only defined when average daily consumption > 0).

### 2.4 File Integrity, Atomic Replacement & Concurrency
- `os.replace` on POSIX and modern Windows (NTFS) provides atomic file replacement within the same filesystem/volume.
- Writing to a temporary file (`tempfile.NamedTemporaryFile(dir=data_dir, delete=False)`) followed by `flush()`, `os.fsync()`, and `os.replace()` guarantees that a crash during writing never corrupts the target CSV.
- **Locking Strategy**: Since Tkinter GUI and FastAPI run as Python processes, file-level locking (`filelock` pattern or cross-thread `threading.Lock` within shared process) prevents race conditions. A write-ahead journal (`journal.json`) records in-flight multi-file state changes (e.g. updating both `inventory.csv` and `consumption.csv`) for automatic rollback/recovery on startup.

### 2.5 OWASP & Academic Security Guidelines
- **CSV Injection (Formula Injection)**: Any string starting with `=`, `+`, `-`, `@`, `\t`, or `\r` must be sanitized or escaped when exported for spreadsheet software (e.g., prefixing with a single quote `'`).
- **Structured Logging**: Log timestamps in ISO 8601 UTC/local time, severity levels (INFO, WARNING, ERROR, CRITICAL), correlation IDs, and separate user audit trails (`audit.log`) from internal diagnostic stack traces (`app.log`). Never log sensitive medical or authentication tokens.
- **Path Traversal Protection**: Ensure file paths for backups and CSV imports are strictly resolved within project boundaries using `pathlib.Path.resolve()`.
