# REQUIREMENTS TRACEABILITY MATRIX: MediStock Analytics

**Course**: Python Programming with Practice (`UC25CA2302`)  
**Assignment**: Assignment 2 (Units 4, 5, 6) — 40 Marks  
**Program**: BCA (BCA-IT, UG), SCA, FCIT  

---

## 1. Course Outcomes (CO) Coverage Matrix

| Course Outcome | Syllabi Focus Area | Implemented Modules & Features | Verification & Automated Tests |
|---|---|---|---|
| **CO4** | Advanced File Handling, Exception Handling, Logging, and Safe System Operations | `app/exceptions.py`<br>`app/repository/csv_repository.py`<br>`app/repository/backup_manager.py`<br>`app/services/logger_service.py` | `tests/test_models_exceptions.py`<br>`tests/test_csv_repository.py`<br>`tests/test_backup_manager.py` |
| **CO5** | GUI Programming (Tkinter/ttk), NumPy Numerical Computing, and Pandas Data Analysis | `app/gui/app.py`<br>`app/gui/views/*.py`<br>`app/analytics/numpy_metrics.py`<br>`app/analytics/pandas_reports.py` | `tests/test_numpy_metrics.py`<br>`tests/test_pandas_reports.py`<br>`tests/test_gui_smoke.py` |
| **CO6** | Software Architecture, Multi-Tier Engineering, Modular Service Design, Testing & Academic Reporting | `app/services/inventory_service.py`<br>`app/api/routes.py`<br>`app/static/*`<br>`docs/*` | `tests/test_inventory_service.py`<br>`tests/test_api.py`<br>Comprehensive Pytest Suite |

---

## 2. Assessment Rubric Traceability (40 Marks)

| Rubric Dimension | Marks | Assignment Requirement | MediStock Analytics Implementation | Verification Evidence |
|---|---|---|---|---|
| **1. Exception Handling Architecture** | 6 | Custom exception hierarchy with `MedicalInventoryError`, `StockoutWarningException`, `CorruptedDataRecordException`, `InvalidQuantityException`, and rigorous `try/except/else/finally`. | `app/exceptions.py` defines full hierarchy. Services strictly utilize `try/except/else/finally`. | `tests/test_models_exceptions.py` tests hierarchy inheritance and messaging. |
| **2. Safe CSV Storage & File Management** | 6 | OS-based file manipulation, `os.replace` atomic writes, backup snapshot management, restore validation, write-ahead journaling. | `app/repository/csv_repository.py` and `app/repository/backup_manager.py` handle atomic staging, locking, backup retention, and rollback. | `tests/test_csv_repository.py` and `tests/test_backup_manager.py` test atomic swap and recovery. |
| **3. Inventory Business Rules & Logic** | 6 | Central `InventoryService`, strict stock issue/receipt, usable vs expired stock calculation, rejection of negative/fractional quantities, duplicate prevention. | `app/services/inventory_service.py` enforces all business constraints. | `tests/test_inventory_service.py` tests stock receipts, stockouts, expired item quarantine. |
| **4. NumPy Analytics Engine** | 5 | Accurate NumPy array computing: `np.sum`, `np.mean`, `np.var`, `np.std` (`ddof=0` population, `ddof=1` sample), zero-day range padding, days remaining. | `app/analytics/numpy_metrics.py` implements hand-verified formulas and non-transaction date range zero-padding. | `tests/test_numpy_metrics.py` tests calculations against known synthetic ground truth. |
| **5. Pandas Reporting & Analytics** | 5 | Real DataFrame operations: `pd.read_csv`, boolean masking, `groupby`, `agg`, `merge`, shortage reports (<= min stock), critical shortage (<= 50% min), CSV export. | `app/analytics/pandas_reports.py` generates 6 distinct report categories with zero-division safety and CSV export. | `tests/test_pandas_reports.py` tests DataFrame schemas and aggregation outputs. |
| **6. Dual User Interface (Tkinter + Web)** | 7 | Working Python Tkinter/ttk desktop GUI with 11 distinct view screens, light theme, treeviews, dialogs; companion responsive web interface via FastAPI. | `app/gui/app.py` & `app/gui/views/*.py` for Tkinter; `app/api/routes.py` & `app/static/*` for web. | `tests/test_gui_smoke.py`, `tests/test_api.py`, manual GUI execution. |
| **7. Technical Report, Code Quality & Viva** | 5 | Max 10-page handwritten technical report structure, IEEE citations, wireframes, demo script, viva questions, clean modular code. | `docs/report_outline.md`, `docs/wireframe.md`, `docs/references.md`, `docs/viva_questions.md`, `DEMO_SCRIPT.md`. | Complete academic documentation set in `docs/`. |

---

## 3. Detailed Specification & Screen-to-Module Mapping

| Required Screen / Module | Tkinter Desktop View | Web API Route | Description & Business Logic |
|---|---|---|---|
| **1. Dashboard** | `DashboardView` | `GET /api/dashboard` | Metric cards (total items, usable units, low stock, expired), category charts, critical supplies. |
| **2. Inventory Grid** | `InventoryView` | `GET /api/inventory` | Search by ID/name, category & location filters, sortable Treeview, stock status badges. |
| **3. Add/Edit/View Supply** | `ItemDialog` | `POST/PUT /api/inventory` | Strict input validation, ISO date format checks, uniqueness assertion. |
| **4. Stock Transactions** | `TransactionView` | `POST /api/transactions/*` | Stock Receipts (`IN`) and Issues (`OUT`); validates usable stock, rejects stockouts. |
| **5. CSV Import Center** | `ImportView` | `POST /api/imports/*` | Pre-import parsing, preview table, row-level error breakdown, commit/rollback workflow. |
| **6. Stock Alerts** | `AlertsView` | `GET /api/reports/*` | Filtered tables of Low Stock (`<= min`), Critical (`<= 50% min`), and Expired items. |
| **7. Analytics & Reports** | `AnalyticsView` | `GET /api/analytics/*` | NumPy summary cards, Pandas aggregated tables, date-range picker, CSV export. |
| **8. Backups & File Manager** | `BackupView` | `GET/POST /api/backups/*` | Timestamped zip/csv snapshots, snapshot integrity validation, one-click restore. |
| **9. Exception & Audit Logs** | `LogView` | `GET /api/logs` | Dual log viewer (Diagnostic `app.log` + Audit `audit.log`) with search and level filters. |
| **10. Settings & Help** | `SettingsView` | `GET/PUT /api/settings` | Threshold configs (critical stock %), backup retention days, application guides. |
| **11. About & Academic Info** | `AboutView` | `GET /api/about` | Assignment details, course code `UC25CA2302`, student USN placeholders, rubric details. |
