# PLAN.md: MediStock Analytics Implementation Plan

## 1. Project Overview & Academic Requirements
- **Course**: Python Programming with Practice (`UC25CA2302`)
- **Assessment**: Assignment 2, Units 4, 5, 6 (40 Marks)
- **Program**: BCA (BCA-IT, UG), SCA, FCIT
- **Deadline**: 24 November 2026
- **Assignment Title**: Interactive GUI-Based Medical Logistics and CSV Data Analytics Platform
- **Dual Deliverable**:
  1. A genuine, production-grade Python Tkinter desktop GUI satisfying syllabus units 4, 5, and 6.
  2. A polished responsive companion web application (FastAPI backend + responsive light-theme Single Page Application with full TypeScript/React source code).
  3. Shared Python business logic, data models, exception handling, and CSV repository.

---

## 2. Architecture & Data Flow

```mermaid
flowchart TD
    subgraph Storage ["Safe CSV Storage Layer"]
        INV["data/inventory.csv"]
        CON["data/consumption.csv"]
        JRN["data/journal.json (WAL)"]
        BAK["backups/ (Timestamped Snapshots)"]
        LOGS["logs/app.log & logs/audit.log"]
    end

    subgraph CoreEngine ["Shared Python Business Engine"]
        EXC["Custom Exceptions Hierarchy\n(StockoutWarning, CorruptedData, InvalidQuantity...)"]
        REPO["CSVRepository & BackupManager\n(Atomic Writes, fsync, os.replace, FileLock)"]
        SRV["InventoryService\n(Transactions, Validation, Business Rules)"]
        NUMPY["analytics/numpy_metrics.py\n(np.sum, np.mean, np.var, np.std, ddof=0/1)"]
        PANDAS["analytics/pandas_reports.py\n(read_csv, groupby, agg, filter, export)"]
    end

    subgraph TkinterGUI ["Desktop Application (Python Tkinter/ttk)"]
        TK_APP["app/gui/app.py"]
        TK_VIEWS["Views: Dashboard, Inventory, Transact, Import,\nAlerts, Analytics, Backups, Logs, About"]
    end

    subgraph WebCompanion ["Web Companion Interface"]
        API["FastAPI REST Endpoints (/api/...)"]
        SPA["Static / React Responsive UI\n(Tailwind Light Theme, Metric Cards, Charts, Tables)"]
    end

    INV --> REPO
    CON --> REPO
    JRN --> REPO
    BAK --> REPO
    REPO --> SRV
    EXC --> SRV
    SRV --> NUMPY
    SRV --> PANDAS
    SRV --> TK_APP
    TK_APP --> TK_VIEWS
    SRV --> API
    API --> SPA
```

---

## 3. Custom Exception Hierarchy

```
MedicalInventoryError (Base Exception)
├── StockoutWarningException (Raised when issuing OUT exceeds usable inventory)
├── CorruptedDataRecordException (Raised on malformed CSV rows, header mismatches, invalid types)
├── InvalidQuantityException (Raised on negative, non-integer, zero, NaN, or non-numeric amounts)
├── DuplicateRecordException (Raised on duplicate item_id or transaction_id)
├── UnknownItemException (Raised when a transaction or import references a non-existent item_id)
├── StorageOperationException (Raised on file system I/O failures, permission errors, lock timeouts)
└── BackupOperationException (Raised on failed backup creation, corrupted snapshot, or restore failure)
```

Every mutating operation rigorously implements the `try / except / else / finally` pattern:
- `try`: Prepare data, acquire lock, stage transaction in journal.
- `except`: Log failure with stack trace, revert staging, translate to custom exception.
- `else`: Commit transaction journal, emit audit log entry, update in-memory cache/UI.
- `finally`: Release locks, clean up temporary files and stream handles.

---

## 4. Phase Breakdown & Execution Milestones

- **Phase 1: Foundation & Planning** (DONE / IN PROGRESS)
  - Inspect environment (Python 3.14 with Tkinter 9.0, Pandas 3.1.0, NumPy 2.5.4, FastAPI, Uvicorn, Pydantic, Pytest installed).
  - Draft `RESEARCH_NOTES.md`, `PLAN.md`, `REQUIREMENTS_TRACEABILITY.md`.

- **Phase 2: Core Domain, Exceptions & Safe CSV Storage**
  - Implement `app/exceptions.py`.
  - Implement `app/models.py` (Item, Transaction, Validation rules, CSV Injection Sanitization).
  - Implement `app/repository/csv_repository.py` (atomic replacement with `os.replace`, WAL journal, locking).
  - Implement `app/repository/backup_manager.py` (timestamped zip/csv backups, verification, rotation, restoration).
  - Implement `app/services/logger_service.py` (Rotating diagnostic logger + structured audit trail).
  - Write unit tests: `tests/test_models_exceptions.py`, `tests/test_csv_repository.py`, `tests/test_backup_manager.py`.

- **Phase 3: Inventory Service & Business Rules**
  - Implement `app/services/inventory_service.py`:
    - List/filter/sort supplies.
    - Add, edit, remove supplies.
    - Receive stock (`IN` transaction).
    - Issue stock (`OUT` transaction with usable stock check and `StockoutWarningException`).
    - Transaction history inspection.
    - Safe CSV import center with pre-validation, preview, row-level error reporting, and rollback.
  - Write unit tests: `tests/test_inventory_service.py`.

- **Phase 4: Numerical Analytics & Reporting**
  - Implement `analytics/numpy_metrics.py`:
    - Total consumed units, average daily consumption over date ranges (including 0-usage days).
    - Population variance (`ddof=0`) and standard deviation; sample variance (`ddof=1`).
    - Consumption velocity and estimated days of supply remaining.
  - Implement `analytics/pandas_reports.py`:
    - Low-stock report (`quantity <= minimum_stock`).
    - Critical-stock report (`quantity <= 0.5 * minimum_stock`).
    - Expired and near-expiry report (expired excluded from usable stock).
    - Category aggregation, daily consumption, transaction audit reports.
    - CSV export generator.
  - Write unit tests: `tests/test_numpy_metrics.py`, `tests/test_pandas_reports.py`.

- **Phase 5: Python Tkinter Desktop Application**
  - Implement `app/gui/styles.py` (clean modern light medical theme).
  - Implement `app/gui/app.py` (navigation sidebar, header, module loader, status bar).
  - Implement all 11 required view screens in `app/gui/views/`:
    1. Dashboard view
    2. Inventory treeview with filters/search
    3. Add/Edit dialog & view
    4. Stock transactions view (Receive/Issue)
    5. CSV Import Center view with error inspector
    6. Stock Alerts view (Low, Critical, Expired)
    7. Analytics & Reports view (NumPy cards + Pandas reports + CSV export)
    8. Backups & File Manager view
    9. Audit & Exception Logs view
    10. Settings & Help view
    11. About & Academic Project Info view
  - Write smoke test: `tests/test_gui_smoke.py`.

- **Phase 6: Web Backend (FastAPI) & API Testing**
  - Implement `app/api/schemas.py` (Pydantic request/response schemas).
  - Implement `app/api/routes.py` (Health, Dashboard, Inventory, Transactions, Imports, Reports, Backups, Logs).
  - Implement `app/main.py` (FastAPI app, CORS, static file mounting, error handlers).
  - Write API test suite: `tests/test_api.py`.

- **Phase 7: Responsive Web Companion Interface**
  - Build polished light-theme web dashboard Single Page Application in `app/static/`:
    - Responsive layout with sidebar, header, KPIs, interactive charts, data grids, modal dialogs.
    - CSV import wizard with live preview and error table.
    - Backup and log viewer.
    - Dynamic filter and date range selectors.
  - Maintain React/TypeScript source repository in `web/` for clean multi-target deployment.

- **Phase 8: End-to-End Integration, Verification & Sample Data**
  - Generate deterministic medical inventory sample data (`data/inventory.csv`, `data/consumption.csv`, valid and invalid import test files).
  - Verify concurrent access safety and transactional consistency between GUI and Web.
  - Run the entire automated test suite (`pytest`) and verify 100% passing tests.

- **Phase 9: Academic Documentation & Technical Report**
  - Author comprehensive documentation in `docs/`:
    - `architecture.md` (detailed design + Mermaid diagrams)
    - `requirements_traceability.md` (rubric & CO mappings)
    - `wireframe.md` (ASCII/Mermaid screen layouts)
    - `csv_schema.md` (data dictionary)
    - `api.md` (OpenAPI specs)
    - `testing.md` (test matrices & execution evidence)
    - `known_limitations.md`
    - `report_outline.md` (10-page handwritten student technical report guide)
    - `references.md` (IEEE citations)
    - `viva_questions.md` (viva voce preparation)
  - Author `DEMO_SCRIPT.md`, `README.md`, launcher scripts `run_gui.py`, `run_web.py`, `run_all.py`.

---

## 5. Risk Assessment & Mitigation Strategies

| Risk | Impact | Mitigation |
|------|--------|------------|
| **Multi-file CSV Corruption** | High | Write-Ahead Journal (`journal.json`), atomic temporary file write with `os.replace`, and automated snapshot before mutations. |
| **Silent Data Truncation** | High | Strict Pydantic & Python dataclass validation; malformed rows are rejected into an error manifest rather than cast to defaults. |
| **Tkinter UI Freezing** | Medium | Non-blocking service calls, event loop yielding, and separate daemon threads for long I/O operations with `root.after()`. |
| **Statistical Bias in Daily Usage** | Medium | Date range expansion with zero-fill for days without transactions before computing NumPy mean and standard deviation. |
| **Cross-Platform Pathing** | Low | Strict usage of `pathlib.Path` with absolute project anchoring. |
