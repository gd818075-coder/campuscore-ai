"""Academic Project Information and About View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk

from app.config import config
from app.gui.styles import COLORS, FONTS


class AboutView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()

    def _build_ui(self):
        # Scrollable container for full academic details
        canvas = tk.Canvas(self, bg=COLORS["bg_main"], highlightthickness=0)
        v_scroll = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, style="TFrame")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scroll.set)

        canvas.pack(side="left", fill="both", expand=True, padx=25, pady=20)
        v_scroll.pack(side="right", fill="y")

        # Title Card
        title_card = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=18)
        title_card.pack(fill="x", pady=(0, 15))

        ttk.Label(title_card, text="MediStock Analytics - Academic Project", font=FONTS["title"], foreground=COLORS["primary"], background=COLORS["bg_surface"]).pack(anchor="w")
        ttk.Label(title_card, text="Interactive GUI-Based Medical Logistics and CSV Data Analytics Platform", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(4, 0))

        # Academic Metadata Card
        meta_card = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=16)
        meta_card.pack(fill="x", pady=(0, 15))

        ttk.Label(meta_card, text="Course & Submission Details", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 10))

        metadata_rows = [
            ("Course Title:", config.COURSE_NAME),
            ("Course Code:", config.COURSE_CODE),
            ("Assignment:", "Assignment 2 (Units 4, 5, 6)"),
            ("Program:", "Bachelor of Computer Applications (BCA / BCA-IT, UG)"),
            ("School / Faculty:", "School of Computer Applications (SCA), FCIT"),
            ("Assessment Weightage:", "40 Marks"),
            ("Official Deadline:", config.SUBMISSION_DEADLINE),
            ("Student Name:", "[STUDENT NAME PLACEHOLDER]"),
            ("University Seat Number (USN):", "[STUDENT USN PLACEHOLDER]"),
        ]

        for lbl, val in metadata_rows:
            row = ttk.Frame(meta_card, style="Card.TFrame")
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=lbl, font=FONTS["body_bold"], width=28, background=COLORS["bg_surface"]).pack(side="left")
            ttk.Label(row, text=val, font=FONTS["body"], background=COLORS["bg_surface"]).pack(side="left")

        # Course Outcomes (CO) Card
        co_card = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=16)
        co_card.pack(fill="x", pady=(0, 15))

        ttk.Label(co_card, text="Course Outcomes (CO) Implementation Evidence", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 10))

        co_data = [
            ("CO4 (File Handling, Exceptions, Logging):",
             "Implemented custom exception hierarchy (StockoutWarningException, CorruptedDataRecordException, "
             "InvalidQuantityException, StorageOperationException, BackupOperationException). "
             "Strict use of try/except/else/finally. Atomic CSV replacement via os.replace, Write-Ahead Journaling (WAL), "
             "and structured rotating audit/diagnostic loggers."),
            ("CO5 (GUI Programming, NumPy & Pandas):",
             "Implemented modular Python Tkinter/ttk desktop application with custom medical light styling. "
             "NumPy analytics engine for np.sum, np.mean, np.var, np.std (ddof=0/1) with zero-padded date series. "
             "Pandas DataFrame processing for low-stock, critical shortage, expiry, and consumption reports."),
            ("CO6 (Architecture, Testing & Software Engineering):",
             "Engineered a multi-tier shared service layer (InventoryService, CSVRepository, BackupManager) reused "
             "seamlessly across both the Tkinter Desktop GUI and companion FastAPI REST web interface. "
             "Extensive automated Pytest test suite covering atomic writes, thread safety, and edge cases.")
        ]

        for title, desc in co_data:
            c_frame = ttk.Frame(co_card, style="Card.TFrame")
            c_frame.pack(fill="x", pady=6)
            ttk.Label(c_frame, text=title, font=FONTS["body_bold"], foreground=COLORS["primary"], background=COLORS["bg_surface"]).pack(anchor="w")
            ttk.Label(c_frame, text=desc, font=FONTS["body"], wraplength=700, justify="left", background=COLORS["bg_surface"]).pack(anchor="w", pady=(2, 0))

        # Custom Exception Hierarchy Card
        exc_card = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=16)
        exc_card.pack(fill="x", pady=(0, 15))

        ttk.Label(exc_card, text="Custom Domain Exception Hierarchy", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 8))

        exc_tree_text = (
            "MedicalInventoryError (Base Domain Exception)\n"
            "├── StockoutWarningException (Raised when issuing OUT exceeds usable stock)\n"
            "├── CorruptedDataRecordException (Raised on malformed CSV, bad types, missing headers)\n"
            "├── InvalidQuantityException (Raised on negative, fractional, zero, or non-numeric qty)\n"
            "├── DuplicateRecordException (Raised on duplicate item_id or transaction_id)\n"
            "├── UnknownItemException (Raised on missing item references)\n"
            "├── StorageOperationException (Raised on filesystem, locking, or atomic swap failures)\n"
            "└── BackupOperationException (Raised on backup creation, validation, or restore errors)"
        )
        ttk.Label(exc_card, text=exc_tree_text, font=FONTS["mono"], background=COLORS["bg_surface"]).pack(anchor="w")

        # Viva Voce Quick Checklist
        viva_card = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=16)
        viva_card.pack(fill="x")

        ttk.Label(viva_card, text="Viva Voce Preparation Highlights", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 8))
        viva_text = (
            "• Q: Why use os.replace instead of standard open(..., 'w')?\n"
            "  A: os.replace provides atomic file replacement. If the process crashes mid-write, the original CSV is never corrupted.\n\n"
            "• Q: What is the difference between physical stock and usable stock?\n"
            "  A: Physical stock includes all units in inventory. Usable stock excludes expired batches, which are legally quarantined and forbidden from being issued to patients.\n\n"
            "• Q: Why pad zero consumption days in NumPy calculations?\n"
            "  A: Calculating averages only from days with transactions introduces severe upward sampling bias. True daily usage must include days with zero consumption over the audit period."
        )
        ttk.Label(viva_card, text=viva_text, font=FONTS["body"], wraplength=700, justify="left", background=COLORS["bg_surface"]).pack(anchor="w")
