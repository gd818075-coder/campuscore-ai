"""Stock Consumption & Movement Transaction View for MediStock Analytics."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Optional

from app.gui.styles import COLORS, FONTS
from app.gui.components.transaction_dialog import TransactionDialog
from app.services.inventory_service import inventory_service
from app.analytics.pandas_reports import pandas_reports


class TransactionView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Toolbar
        toolbar = ttk.Frame(self, style="Card.TFrame", padding=12)
        toolbar.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(toolbar, text="Stock Movement Audit Trail", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 15))

        # Item filter
        ttk.Label(toolbar, text="Item ID:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.item_filter_var = tk.StringVar()
        self.item_entry = ttk.Entry(toolbar, textvariable=self.item_filter_var, width=14)
        self.item_entry.pack(side="left", padx=(0, 10))
        self.item_entry.bind("<KeyRelease>", lambda e: self.filter_data())

        # Type filter
        ttk.Label(toolbar, text="Type:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.type_var = tk.StringVar(value="All")
        self.type_combo = ttk.Combobox(toolbar, textvariable=self.type_var, width=10, state="readonly", values=["All", "IN", "OUT"])
        self.type_combo.pack(side="left", padx=(0, 10))
        self.type_combo.bind("<<ComboboxSelected>>", lambda e: self.filter_data())

        ttk.Button(toolbar, text="Reset", style="Secondary.TButton", command=self.reset_filters).pack(side="left")

        # Action Buttons
        btn_bar = ttk.Frame(self, style="TFrame")
        btn_bar.pack(fill="x", padx=20, pady=(0, 10))

        ttk.Button(btn_bar, text="+ Receive Stock (IN)", style="Primary.TButton", command=lambda: self.on_transact("IN")).pack(side="left", padx=(0, 6))
        ttk.Button(btn_bar, text="- Issue Stock (OUT)", style="Primary.TButton", command=lambda: self.on_transact("OUT")).pack(side="left", padx=6)
        ttk.Button(btn_bar, text="Export CSV", style="Secondary.TButton", command=self.on_export_csv).pack(side="right")
        ttk.Button(btn_bar, text="Refresh", style="Secondary.TButton", command=self.refresh).pack(side="right", padx=6)

        # Treeview
        grid_frame = ttk.Frame(self, style="Card.TFrame", padding=2)
        grid_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        columns = ("transaction_id", "item_id", "transaction_date", "transaction_type", "quantity", "reference", "remarks")
        self.tree = ttk.Treeview(grid_frame, columns=columns, show="headings", selectmode="browse")

        headers = [
            ("transaction_id", "Transaction ID", 180),
            ("item_id", "Item ID", 110),
            ("transaction_date", "Date", 110),
            ("transaction_type", "Type", 80),
            ("quantity", "Quantity", 80),
            ("reference", "Reference #", 140),
            ("remarks", "Remarks / Clinical Purpose", 250),
        ]

        for col_id, col_text, col_width in headers:
            self.tree.heading(col_id, text=col_text)
            anchor = "center" if col_id in ("transaction_date", "transaction_type", "quantity") else "w"
            self.tree.column(col_id, width=col_width, anchor=anchor)

        v_scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        h_scroll = ttk.Scrollbar(grid_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        v_scroll.pack(side="right", fill="y")
        h_scroll.pack(side="bottom", fill="x")

    def refresh(self):
        self.filter_data()

    def filter_data(self):
        it_filter = self.item_filter_var.get().strip()
        t_type = self.type_var.get()

        txs = inventory_service.get_transactions(
            item_id=it_filter if it_filter else None,
            transaction_type=t_type if t_type != "All" else None,
            limit=500
        )

        for item in self.tree.get_children():
            self.tree.delete(item)

        for tx in txs:
            self.tree.insert("", "end", values=(
                tx.transaction_id, tx.item_id, tx.transaction_date,
                tx.transaction_type, tx.quantity, tx.reference, tx.remarks
            ))

    def reset_filters(self):
        self.item_filter_var.set("")
        self.type_var.set("All")
        self.filter_data()

    def on_transact(self, transaction_type: str):
        # Quick dialog to pick item ID
        items = inventory_service.get_all_items()
        if not items:
            messagebox.showwarning("No Items", "Inventory catalog is empty.", parent=self)
            return

        pick_win = tk.Toplevel(self)
        pick_win.title(f"Select Item for Stock {transaction_type}")
        pick_win.geometry("400x180")
        pick_win.resizable(False, False)
        pick_win.transient(self)
        pick_win.grab_set()

        ttk.Label(pick_win, text=f"Choose Medical Supply for Stock {transaction_type}:", font=FONTS["heading"]).pack(padx=20, pady=(15, 8), anchor="w")

        item_names = [f"{it.item_id} - {it.item_name}" for it in items]
        combo = ttk.Combobox(pick_win, values=item_names, width=42, state="readonly")
        combo.pack(padx=20, pady=5)
        combo.current(0)

        def proceed():
            sel = combo.get()
            selected_id = sel.split(" - ")[0].strip()
            item = inventory_service.get_item_by_id(selected_id)
            pick_win.destroy()
            dlg = TransactionDialog(self, item=item, transaction_type=transaction_type)
            self.wait_window(dlg)
            if dlg.result:
                try:
                    if transaction_type == "IN":
                        up_item, tx = inventory_service.receive_stock(
                            item_id=dlg.result["item_id"],
                            quantity=dlg.result["quantity"],
                            transaction_date=dlg.result["transaction_date"],
                            reference=dlg.result["reference"],
                            remarks=dlg.result["remarks"]
                        )
                    else:
                        up_item, tx = inventory_service.issue_stock(
                            item_id=dlg.result["item_id"],
                            quantity=dlg.result["quantity"],
                            transaction_date=dlg.result["transaction_date"],
                            reference=dlg.result["reference"],
                            remarks=dlg.result["remarks"]
                        )
                    messagebox.showinfo("Success", f"Transaction {tx.transaction_id} committed successfully.", parent=self)
                    self.refresh()
                except Exception as e:
                    messagebox.showerror("Transaction Error", str(e), parent=self)

        ttk.Button(pick_win, text="Proceed", style="Primary.TButton", command=proceed).pack(pady=15)

    def on_export_csv(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="consumption_transactions_export.csv",
            parent=self
        )
        if path:
            try:
                df = pandas_reports.get_consumption_df()
                pandas_reports.export_report_to_csv(df, Path(path))
                messagebox.showinfo("Export Successful", f"Transactions exported to:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)
