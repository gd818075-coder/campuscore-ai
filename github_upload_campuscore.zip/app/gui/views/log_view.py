"""Log and Audit Viewer for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import json

from app.gui.styles import COLORS, FONTS
from app.services.logger_service import logger_service


class LogView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header toolbar
        header = ttk.Frame(self, style="Card.TFrame", padding=12)
        header.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(header, text="Exception & Audit Log Center", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 15))

        # Severity filter
        ttk.Label(header, text="Severity:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.level_var = tk.StringVar(value="ALL")
        self.level_combo = ttk.Combobox(header, textvariable=self.level_var, values=["ALL", "INFO", "WARNING", "ERROR"], width=10, state="readonly")
        self.level_combo.pack(side="left", padx=(0, 10))
        self.level_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        # Search filter
        ttk.Label(header, text="Search:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(header, textvariable=self.search_var, width=16)
        self.search_entry.pack(side="left", padx=(0, 10))
        self.search_entry.bind("<KeyRelease>", lambda e: self.refresh())

        ttk.Button(header, text="Refresh", style="Primary.TButton", command=self.refresh).pack(side="right")
        ttk.Button(header, text="Export Logs", style="Secondary.TButton", command=self.on_export_logs).pack(side="right", padx=6)

        # Tabbed Viewer
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        # Tab 1: Diagnostic Error & Internal App Logs
        tab_app = ttk.Frame(self.notebook, style="Card.TFrame", padding=6)
        self.notebook.add(tab_app, text="1. Internal Diagnostic Logs (app.log)")

        self.txt_app = tk.Text(tab_app, wrap="none", font=FONTS["mono"], bg=COLORS["bg_surface"], fg=COLORS["text_dark"], relief="flat")
        app_v_scroll = ttk.Scrollbar(tab_app, orient="vertical", command=self.txt_app.yview)
        app_h_scroll = ttk.Scrollbar(tab_app, orient="horizontal", command=self.txt_app.xview)
        self.txt_app.configure(yscrollcommand=app_v_scroll.set, xscrollcommand=app_h_scroll.set)

        self.txt_app.pack(side="left", fill="both", expand=True)
        app_v_scroll.pack(side="right", fill="y")
        app_h_scroll.pack(side="bottom", fill="x")

        # Tab 2: Structured Audit Trail
        tab_audit = ttk.Frame(self.notebook, style="Card.TFrame", padding=6)
        self.notebook.add(tab_audit, text="2. Mutation Audit Trail (audit.log)")

        cols = ("timestamp", "operation", "entity", "entity_id", "outcome", "details")
        self.tree_audit = ttk.Treeview(tab_audit, columns=cols, show="headings", height=12)

        headers = [
            ("timestamp", "Timestamp", 160),
            ("operation", "Operation", 130),
            ("entity", "Entity", 90),
            ("entity_id", "Target ID", 150),
            ("outcome", "Outcome", 90),
            ("details", "Audit Description", 300),
        ]

        for col_id, col_text, col_width in headers:
            self.tree_audit.heading(col_id, text=col_text)
            self.tree_audit.column(col_id, width=col_width, anchor="center" if col_id in ("timestamp", "outcome") else "w")

        aud_v_scroll = ttk.Scrollbar(tab_audit, orient="vertical", command=self.tree_audit.yview)
        self.tree_audit.configure(yscrollcommand=aud_v_scroll.set)
        self.tree_audit.pack(side="left", fill="both", expand=True)
        aud_v_scroll.pack(side="right", fill="y")

    def refresh(self):
        lvl = self.level_var.get()
        lvl_filter = None if lvl == "ALL" else lvl
        search_kw = self.search_var.get().strip() or None

        # 1. Diagnostic logs
        lines = logger_service.get_app_logs(limit=200, level_filter=lvl_filter, search=search_kw)
        self.txt_app.delete("1.0", tk.END)
        for line in lines:
            self.txt_app.insert(tk.END, line + "\n")

        # 2. Audit logs
        audit_entries = logger_service.get_audit_logs(limit=200, search=search_kw)
        for item in self.tree_audit.get_children():
            self.tree_audit.delete(item)

        for entry in audit_entries:
            ts = entry.get("timestamp", "")[:19].replace("T", " ")
            self.tree_audit.insert("", "end", values=(
                ts,
                entry.get("operation", ""),
                entry.get("entity_type", ""),
                entry.get("entity_id", ""),
                entry.get("outcome", ""),
                entry.get("details", "")
            ))

    def on_export_logs(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("Log files", "*.log")],
            initialfile="medistock_diagnostic_log.txt",
            parent=self
        )
        if path:
            try:
                content = self.txt_app.get("1.0", tk.END)
                Path(path).write_text(content, encoding="utf-8")
                messagebox.showinfo("Exported", f"Logs exported to:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)
