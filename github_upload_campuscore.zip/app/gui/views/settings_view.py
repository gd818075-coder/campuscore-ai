"""Settings and Help Configuration View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

from app.config import config
from app.gui.styles import COLORS, FONTS


class SettingsView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()

    def _build_ui(self):
        container = ttk.Frame(self, style="TFrame")
        container.pack(fill="both", expand=True, padx=25, pady=20)

        ttk.Label(container, text="Application Settings & Guidance", font=FONTS["title"]).pack(anchor="w", pady=(0, 15))

        # Card 1: Inventory Policies
        card_policy = ttk.Frame(container, style="Card.TFrame", padding=16)
        card_policy.pack(fill="x", pady=(0, 15))

        ttk.Label(card_policy, text="Inventory Policy Parameters", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 10))

        row1 = ttk.Frame(card_policy, style="Card.TFrame")
        row1.pack(fill="x", pady=6)
        ttk.Label(row1, text="Critical Shortage Ratio (Fraction of Min Stock):", style="Card.TLabel").pack(side="left")
        self.crit_ratio_var = tk.StringVar(value=str(config.CRITICAL_STOCK_RATIO))
        crit_entry = ttk.Entry(row1, textvariable=self.crit_ratio_var, width=10)
        crit_entry.pack(side="left", padx=10)
        ttk.Label(row1, text="e.g. 0.50 = Flagged when quantity <= 50% of minimum_stock", font=FONTS["small"], foreground=COLORS["text_muted"], background=COLORS["bg_surface"]).pack(side="left")

        row2 = ttk.Frame(card_policy, style="Card.TFrame")
        row2.pack(fill="x", pady=6)
        ttk.Label(row2, text="Backup Retention Archive Count:", style="Card.TLabel").pack(side="left")
        self.retention_var = tk.StringVar(value=str(config.BACKUP_RETENTION_COUNT))
        ret_entry = ttk.Entry(row2, textvariable=self.retention_var, width=10)
        ret_entry.pack(side="left", padx=10)
        ttk.Label(row2, text="Automatic pruning keeps only newest N backup zip files", font=FONTS["small"], foreground=COLORS["text_muted"], background=COLORS["bg_surface"]).pack(side="left")

        row3 = ttk.Frame(card_policy, style="Card.TFrame")
        row3.pack(fill="x", pady=6)
        self.quarantine_var = tk.BooleanVar(value=config.EXCLUDE_EXPIRED_FROM_USABLE)
        chk = ttk.Checkbutton(row3, text="Strict Patient Safety: Exclude Expired Items from Usable Quantity", variable=self.quarantine_var)
        chk.pack(side="left")

        save_btn = ttk.Button(card_policy, text="Save Parameters", style="Primary.TButton", command=self.on_save_settings)
        save_btn.pack(anchor="e", pady=(10, 0))

        # Card 2: Environment Paths
        card_paths = ttk.Frame(container, style="Card.TFrame", padding=16)
        card_paths.pack(fill="x", pady=(0, 15))

        ttk.Label(card_paths, text="System File Anchoring", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 10))

        paths_info = [
            ("Base Directory:", str(config.BASE_DIR)),
            ("Inventory CSV:", str(config.INVENTORY_CSV)),
            ("Consumption CSV:", str(config.CONSUMPTION_CSV)),
            ("Backups Directory:", str(config.BACKUP_DIR)),
            ("Application Logs:", str(config.APP_LOG_FILE)),
            ("Audit Trail:", str(config.AUDIT_LOG_FILE)),
        ]

        for lbl_text, val_text in paths_info:
            p_row = ttk.Frame(card_paths, style="Card.TFrame")
            p_row.pack(fill="x", pady=3)
            ttk.Label(p_row, text=lbl_text, font=FONTS["body_bold"], width=18, background=COLORS["bg_surface"]).pack(side="left")
            ttk.Label(p_row, text=val_text, font=FONTS["mono"], foreground=COLORS["text_muted"], background=COLORS["bg_surface"]).pack(side="left")

        # Card 3: Help & Operator Guidance
        card_help = ttk.Frame(container, style="Card.TFrame", padding=16)
        card_help.pack(fill="x")

        ttk.Label(card_help, text="Help & Academic Logistics Guidelines", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(anchor="w", pady=(0, 8))
        help_text = (
            "1. Stock Movements: Use 'Receive (IN)' to record deliveries and 'Issue (OUT)' to record patient or ward dispensing.\n"
            "2. Safety Checks: Issuing more stock than is usable raises a StockoutWarningException. Expired supplies cannot be issued.\n"
            "3. Safe CSV Imports: The CSV Import Center provides full previewing and row-level validation before any file writes.\n"
            "4. Crash Resilience: Multi-file mutations use a Write-Ahead Journal (WAL) with automatic recovery on startup."
        )
        ttk.Label(card_help, text=help_text, font=FONTS["body"], background=COLORS["bg_surface"]).pack(anchor="w")

    def on_save_settings(self):
        try:
            ratio = float(self.crit_ratio_var.get())
            if not 0.0 < ratio <= 1.0:
                raise ValueError("Critical ratio must be between 0.01 and 1.00.")

            retention = int(self.retention_var.get())
            if retention < 1:
                raise ValueError("Retention count must be at least 1.")

            config.CRITICAL_STOCK_RATIO = ratio
            config.BACKUP_RETENTION_COUNT = retention
            config.EXCLUDE_EXPIRED_FROM_USABLE = self.quarantine_var.get()

            messagebox.showinfo("Settings Saved", "Configuration parameters updated successfully.", parent=self)
        except Exception as e:
            messagebox.showerror("Invalid Setting", str(e), parent=self)
