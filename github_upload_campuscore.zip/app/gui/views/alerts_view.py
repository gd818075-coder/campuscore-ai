"""Stock Alerts & Safety Center View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

from app.gui.styles import COLORS, FONTS
from app.gui.components.transaction_dialog import TransactionDialog
from app.services.inventory_service import inventory_service
from app.analytics.pandas_reports import pandas_reports


class AlertsView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header toolbar
        header = ttk.Frame(self, style="Card.TFrame", padding=14)
        header.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(header, text="Stock Shortage & Expiry Alerts", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left")
        ttk.Button(header, text="Refresh Alerts", style="Secondary.TButton", command=self.refresh).pack(side="right")
        ttk.Button(header, text="Quick Receive (Restock)", style="Primary.TButton", command=self.on_quick_restock).pack(side="right", padx=8)

        # Tabbed alert containers
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        # Tab 1: Critical Shortage (<= 50% Min)
        self.tab_critical = ttk.Frame(self.notebook, style="Card.TFrame", padding=6)
        self.notebook.add(self.tab_critical, text="1. Critical Shortages (<= 50% Min)")
        self.tree_crit = self._create_treeview(self.tab_critical, ("item_id", "item_name", "category", "quantity", "minimum_stock", "shortage_units"))

        # Tab 2: Low Stock (<= Min)
        self.tab_low = ttk.Frame(self.notebook, style="Card.TFrame", padding=6)
        self.notebook.add(self.tab_low, text="2. Low Stock (Reorder Point)")
        self.tree_low = self._create_treeview(self.tab_low, ("item_id", "item_name", "category", "quantity", "minimum_stock", "shortage_units"))

        # Tab 3: Expired & Near-Expiry
        self.tab_expiry = ttk.Frame(self.notebook, style="Card.TFrame", padding=6)
        self.notebook.add(self.tab_expiry, text="3. Expired & Near-Expiry Quarantines")
        self.tree_exp = self._create_treeview(self.tab_expiry, ("item_id", "item_name", "category", "quantity", "expiry_date", "expiry_category"))

    def _create_treeview(self, parent: ttk.Frame, cols: tuple) -> ttk.Treeview:
        tree = ttk.Treeview(parent, columns=cols, show="headings", height=12)
        for c in cols:
            tree.heading(c, text=c.replace("_", " ").title())
            tree.column(c, width=120, anchor="center" if "date" in c or "units" in c or "stock" in c or "quantity" in c else "w")

        v_scroll = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=v_scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        v_scroll.pack(side="right", fill="y")
        return tree

    def refresh(self):
        try:
            # 1. Critical
            for item in self.tree_crit.get_children():
                self.tree_crit.delete(item)
            crit_df = pandas_reports.generate_critical_stock_report()
            for _, r in crit_df.iterrows():
                shortage = max(0, r["minimum_stock"] - r["quantity"])
                self.tree_crit.insert("", "end", values=(
                    r["item_id"], r["item_name"], r["category"],
                    r["quantity"], r["minimum_stock"], shortage
                ))

            # 2. Low Stock
            for item in self.tree_low.get_children():
                self.tree_low.delete(item)
            low_df = pandas_reports.generate_low_stock_report()
            for _, r in low_df.iterrows():
                shortage = max(0, r["minimum_stock"] - r["quantity"])
                self.tree_low.insert("", "end", values=(
                    r["item_id"], r["item_name"], r["category"],
                    r["quantity"], r["minimum_stock"], shortage
                ))

            # 3. Expiry
            for item in self.tree_exp.get_children():
                self.tree_exp.delete(item)
            exp_df = pandas_reports.generate_expiry_report(near_expiry_days=45)
            for _, r in exp_df.iterrows():
                self.tree_exp.insert("", "end", values=(
                    r["item_id"], r["item_name"], r["category"],
                    r["quantity"], r["expiry_date"], r.get("expiry_category", "Expired")
                ))

        except Exception as e:
            messagebox.showerror("Alerts Error", f"Failed loading alerts: {e}", parent=self)

    def on_quick_restock(self):
        current_tab_idx = self.notebook.index(self.notebook.select())
        active_tree = self.tree_crit if current_tab_idx == 0 else (self.tree_low if current_tab_idx == 1 else self.tree_exp)

        sel = active_tree.selection()
        if not sel:
            messagebox.showwarning("Selection Required", "Please select an item from the active alerts list to restock.", parent=self)
            return

        values = active_tree.item(sel[0], "values")
        item_id = values[0]
        try:
            item = inventory_service.get_item_by_id(item_id)
            dlg = TransactionDialog(self, item=item, transaction_type="IN")
            self.wait_window(dlg)
            if dlg.result:
                up_item, tx = inventory_service.receive_stock(
                    item_id=dlg.result["item_id"],
                    quantity=dlg.result["quantity"],
                    transaction_date=dlg.result["transaction_date"],
                    reference=dlg.result["reference"],
                    remarks="Emergency restock from alerts view"
                )
                messagebox.showinfo("Restocked", f"Received +{tx.quantity} units for {up_item.item_name}.\nNew stock: {up_item.quantity}", parent=self)
                self.refresh()
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)
