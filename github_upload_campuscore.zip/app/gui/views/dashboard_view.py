"""Dashboard View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Callable, Optional

from app.gui.styles import COLORS, FONTS
from app.services.inventory_service import inventory_service
from app.analytics.pandas_reports import pandas_reports


class DashboardView(ttk.Frame):
    def __init__(self, parent: tk.Widget, navigate_fn: Callable[[str], None]):
        super().__init__(parent, style="TFrame")
        self.navigate_fn = navigate_fn
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header banner
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(header_frame, text="Medical Logistics Dashboard", font=FONTS["title"]).pack(side="left")
        
        refresh_btn = ttk.Button(header_frame, text="Refresh Data", style="Secondary.TButton", command=self.refresh)
        refresh_btn.pack(side="right")

        # Top Metric Cards Container
        cards_frame = ttk.Frame(self, style="TFrame")
        cards_frame.pack(fill="x", padx=20, pady=10)

        self.card_total_items = self._create_metric_card(cards_frame, "Total Catalog Supplies", "0", COLORS["primary"], 0)
        self.card_usable_units = self._create_metric_card(cards_frame, "Usable Stock Units", "0", COLORS["success"], 1)
        self.card_low_stock = self._create_metric_card(cards_frame, "Low Stock Warnings", "0", COLORS["warning"], 2)
        self.card_expired = self._create_metric_card(cards_frame, "Expired / Quarantined", "0", COLORS["danger"], 3)

        # Middle split: Left = Critical Shortages Table, Right = Category Summary
        split_frame = ttk.Frame(self, style="TFrame")
        split_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Left Container: Critical Shortages
        left_container = ttk.Frame(split_frame, style="Card.TFrame", padding=12)
        left_container.pack(side="left", fill="both", expand=True, padx=(0, 10))

        lbl_crit = ttk.Label(left_container, text="Critical Supply Shortages (<= 50% Min)", font=FONTS["subtitle"], background=COLORS["bg_surface"])
        lbl_crit.pack(anchor="w", pady=(0, 8))

        cols_crit = ("item_id", "item_name", "category", "quantity", "minimum_stock", "status")
        self.tree_crit = ttk.Treeview(left_container, columns=cols_crit, show="headings", height=8)
        self.tree_crit.heading("item_id", text="Item ID")
        self.tree_crit.heading("item_name", text="Supply Name")
        self.tree_crit.heading("category", text="Category")
        self.tree_crit.heading("quantity", text="Stock")
        self.tree_crit.heading("minimum_stock", text="Min Level")
        self.tree_crit.heading("status", text="Status")

        self.tree_crit.column("item_id", width=80)
        self.tree_crit.column("item_name", width=180)
        self.tree_crit.column("category", width=110)
        self.tree_crit.column("quantity", width=60, anchor="center")
        self.tree_crit.column("minimum_stock", width=70, anchor="center")
        self.tree_crit.column("status", width=80, anchor="center")

        crit_scroll = ttk.Scrollbar(left_container, orient="vertical", command=self.tree_crit.yview)
        self.tree_crit.configure(yscrollcommand=crit_scroll.set)
        self.tree_crit.pack(side="left", fill="both", expand=True)
        crit_scroll.pack(side="right", fill="y")

        # Right Container: Category Breakdown
        right_container = ttk.Frame(split_frame, style="Card.TFrame", padding=12)
        right_container.pack(side="right", fill="both", expand=True, padx=(10, 0))

        lbl_cat = ttk.Label(right_container, text="Inventory by Category", font=FONTS["subtitle"], background=COLORS["bg_surface"])
        lbl_cat.pack(anchor="w", pady=(0, 8))

        cols_cat = ("category", "total_items", "total_units")
        self.tree_cat = ttk.Treeview(right_container, columns=cols_cat, show="headings", height=8)
        self.tree_cat.heading("category", text="Category")
        self.tree_cat.heading("total_items", text="SKU Count")
        self.tree_cat.heading("total_units", text="Physical Units")

        self.tree_cat.column("category", width=150)
        self.tree_cat.column("total_items", width=90, anchor="center")
        self.tree_cat.column("total_units", width=100, anchor="center")

        cat_scroll = ttk.Scrollbar(right_container, orient="vertical", command=self.tree_cat.yview)
        self.tree_cat.configure(yscrollcommand=cat_scroll.set)
        self.tree_cat.pack(side="left", fill="both", expand=True)
        cat_scroll.pack(side="right", fill="y")

        # Quick Actions Bar at bottom
        quick_bar = ttk.Frame(self, style="Card.TFrame", padding=12)
        quick_bar.pack(fill="x", padx=20, pady=(5, 15))

        ttk.Label(quick_bar, text="Quick Navigation:", font=FONTS["heading"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 15))
        ttk.Button(quick_bar, text="View All Inventory", style="Secondary.TButton", command=lambda: self.navigate_fn("inventory")).pack(side="left", padx=4)
        ttk.Button(quick_bar, text="Record Stock Transaction", style="Primary.TButton", command=lambda: self.navigate_fn("transactions")).pack(side="left", padx=4)
        ttk.Button(quick_bar, text="CSV Import Center", style="Secondary.TButton", command=lambda: self.navigate_fn("import")).pack(side="left", padx=4)
        ttk.Button(quick_bar, text="Generate Analytics", style="Secondary.TButton", command=lambda: self.navigate_fn("analytics")).pack(side="left", padx=4)

    def _create_metric_card(self, parent: ttk.Frame, title: str, default_val: str, accent_color: str, col_idx: int) -> ttk.Label:
        card = ttk.Frame(parent, style="Card.TFrame", padding=14)
        card.grid(row=0, column=col_idx, sticky="ew", padx=6)
        parent.columnconfigure(col_idx, weight=1)

        ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
        val_lbl = ttk.Label(card, text=default_val, font=FONTS["metric_value"], foreground=accent_color, background=COLORS["bg_surface"])
        val_lbl.pack(anchor="w", pady=(6, 0))
        return val_lbl

    def refresh(self):
        try:
            items = inventory_service.get_all_items()
            total_items = len(items)
            usable_units = sum(it.usable_quantity for it in items)
            low_stock_items = sum(1 for it in items if it.quantity <= it.minimum_stock and not it.is_expired())
            expired_items = sum(1 for it in items if it.is_expired())

            self.card_total_items.config(text=str(total_items))
            self.card_usable_units.config(text=f"{usable_units:,}")
            self.card_low_stock.config(text=str(low_stock_items))
            self.card_expired.config(text=str(expired_items))

            # Populate Critical Table
            for item in self.tree_crit.get_children():
                self.tree_crit.delete(item)

            crit_df = pandas_reports.generate_critical_stock_report()
            for _, row in crit_df.iterrows():
                self.tree_crit.insert("", "end", values=(
                    row["item_id"], row["item_name"], row["category"],
                    row["quantity"], row["minimum_stock"], row["stock_status"]
                ))

            # Populate Category Breakdown Table
            for item in self.tree_cat.get_children():
                self.tree_cat.delete(item)

            cat_df = pandas_reports.generate_category_summary()
            for _, row in cat_df.iterrows():
                self.tree_cat.insert("", "end", values=(
                    row["category"], row["total_items"], f"{row['total_physical_units']:,}"
                ))

        except Exception as e:
            messagebox.showerror("Dashboard Error", f"Failed to refresh dashboard: {e}", parent=self)
