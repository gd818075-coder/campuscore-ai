"""Analytics and Reports View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date, timedelta
from pathlib import Path

from app.gui.styles import COLORS, FONTS
from app.services.inventory_service import inventory_service
from app.analytics.numpy_metrics import calculate_consumption_metrics, calculate_item_runway_metrics
from app.analytics.pandas_reports import pandas_reports


class AnalyticsView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header toolbar
        header = ttk.Frame(self, style="Card.TFrame", padding=12)
        header.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(header, text="NumPy Metrics & Consumption Analytics", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 15))

        # Date range
        ttk.Label(header, text="Start Date:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.start_date_var = tk.StringVar(value=(date.today() - timedelta(days=30)).isoformat())
        self.start_entry = ttk.Entry(header, textvariable=self.start_date_var, width=12)
        self.start_entry.pack(side="left", padx=(0, 10))

        ttk.Label(header, text="End Date:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.end_date_var = tk.StringVar(value=date.today().isoformat())
        self.end_entry = ttk.Entry(header, textvariable=self.end_date_var, width=12)
        self.end_entry.pack(side="left", padx=(0, 15))

        ttk.Button(header, text="Recalculate", style="Primary.TButton", command=self.refresh).pack(side="left")
        ttk.Button(header, text="Export Runway CSV", style="Secondary.TButton", command=self.on_export_runway).pack(side="right")

        # Top NumPy Statistical Cards Container
        cards_frame = ttk.Frame(self, style="TFrame")
        cards_frame.pack(fill="x", padx=20, pady=(0, 10))

        self.card_total = self._create_metric_card(cards_frame, "Total Consumed (np.sum)", "0 units", COLORS["primary"], 0)
        self.card_mean = self._create_metric_card(cards_frame, "Daily Mean (np.mean)", "0.0 / day", COLORS["primary"], 1)
        self.card_var = self._create_metric_card(cards_frame, "Pop. Variance (ddof=0)", "0.00", COLORS["primary"], 2)
        self.card_std = self._create_metric_card(cards_frame, "Pop. Std Dev (ddof=0)", "0.00", COLORS["primary"], 3)
        self.card_sample_std = self._create_metric_card(cards_frame, "Sample Std Dev (ddof=1)", "0.00", COLORS["text_muted"], 4)

        # Runway and Days Remaining Data Grid
        grid_container = ttk.Frame(self, style="Card.TFrame", padding=12)
        grid_container.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        lbl_grid = ttk.Label(grid_container, text="Item-Wise Consumption Runway & Estimated Days Remaining", font=FONTS["heading"], background=COLORS["bg_surface"])
        lbl_grid.pack(anchor="w", pady=(0, 8))

        cols = (
            "item_id", "item_name", "category", "usable_stock",
            "total_consumed", "daily_rate", "rate_std", "days_remaining", "trend"
        )
        self.tree_runway = ttk.Treeview(grid_container, columns=cols, show="headings", height=10)

        headers = [
            ("item_id", "Item ID", 90),
            ("item_name", "Supply Name", 200),
            ("category", "Category", 120),
            ("usable_stock", "Usable Stock", 90),
            ("total_consumed", "Total Used", 85),
            ("daily_rate", "Daily Avg", 85),
            ("rate_std", "Std Dev", 75),
            ("days_remaining", "Days Remaining", 110),
            ("trend", "Consumption Trend", 120),
        ]

        for col_id, text, width in headers:
            self.tree_runway.heading(col_id, text=text)
            self.tree_runway.column(col_id, width=width, anchor="center" if "stock" in col_id or "rate" in col_id or "days" in col_id or "consumed" in col_id else "w")

        r_scroll = ttk.Scrollbar(grid_container, orient="vertical", command=self.tree_runway.yview)
        self.tree_runway.configure(yscrollcommand=r_scroll.set)
        self.tree_runway.pack(side="left", fill="both", expand=True)
        r_scroll.pack(side="right", fill="y")

    def _create_metric_card(self, parent: ttk.Frame, title: str, default_val: str, color: str, col_idx: int) -> ttk.Label:
        card = ttk.Frame(parent, style="Card.TFrame", padding=10)
        card.grid(row=0, column=col_idx, sticky="ew", padx=4)
        parent.columnconfigure(col_idx, weight=1)

        ttk.Label(card, text=title, font=FONTS["small"], foreground=COLORS["text_muted"], background=COLORS["bg_surface"]).pack(anchor="w")
        val_lbl = ttk.Label(card, text=default_val, font=FONTS["subtitle"], foreground=color, background=COLORS["bg_surface"])
        val_lbl.pack(anchor="w", pady=(4, 0))
        return val_lbl

    def refresh(self):
        s_date = self.start_date_var.get().strip()
        e_date = self.end_date_var.get().strip()

        try:
            items = inventory_service.get_all_items()
            txs = inventory_service.get_transactions(limit=1000)

            # Calculate NumPy aggregate metrics across continuous date range
            metrics = calculate_consumption_metrics(txs, start_date=s_date, end_date=e_date)

            self.card_total.config(text=f"{metrics['total_consumed_units']:,} units")
            self.card_mean.config(text=f"{metrics['average_daily_consumption']:.2f} / day")
            self.card_var.config(text=f"{metrics['variance']:.4f}")
            self.card_std.config(text=f"{metrics['std_deviation']:.4f}")
            self.card_sample_std.config(text=f"{metrics['sample_std_deviation']:.4f}")

            # Populate Runway table
            for item in self.tree_runway.get_children():
                self.tree_runway.delete(item)

            runway = calculate_item_runway_metrics(items, txs, lookback_days=30)
            for r in runway:
                days_disp = f"{r['estimated_days_remaining']} days" if r['estimated_days_remaining'] is not None else "No usage"
                self.tree_runway.insert("", "end", values=(
                    r["item_id"], r["item_name"], r["category"],
                    f"{r['usable_stock']} {r['unit']}",
                    r["total_lookback_consumed"],
                    f"{r['average_daily_rate']:.2f}",
                    f"{r['rate_std_deviation']:.2f}",
                    days_disp,
                    r["trend"]
                ))

        except Exception as e:
            messagebox.showerror("Analytics Error", f"Failed calculating analytics: {e}", parent=self)

    def on_export_runway(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="consumption_runway_report.csv",
            parent=self
        )
        if path:
            try:
                df = pandas_reports.generate_item_consumption_report()
                pandas_reports.export_report_to_csv(df, Path(path))
                messagebox.showinfo("Exported", f"Runway report saved to:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)
