"""GUI views package."""
from app.gui.views.dashboard_view import DashboardView
from app.gui.views.inventory_view import InventoryView
from app.gui.views.transaction_view import TransactionView
from app.gui.views.import_view import ImportView
from app.gui.views.alerts_view import AlertsView
from app.gui.views.analytics_view import AnalyticsView
from app.gui.views.backup_view import BackupView
from app.gui.views.log_view import LogView
from app.gui.views.settings_view import SettingsView
from app.gui.views.about_view import AboutView

__all__ = [
    "DashboardView",
    "InventoryView",
    "TransactionView",
    "ImportView",
    "AlertsView",
    "AnalyticsView",
    "BackupView",
    "LogView",
    "SettingsView",
    "AboutView"
]
