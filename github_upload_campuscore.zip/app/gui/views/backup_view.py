"""Backups and File Disaster Recovery View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from pathlib import Path
import os

from app.config import config
from app.gui.styles import COLORS, FONTS
from app.repository.backup_manager import BackupManager


class BackupView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self.backup_mgr = BackupManager()
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header toolbar
        header = ttk.Frame(self, style="Card.TFrame", padding=14)
        header.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(header, text="Data Snapshots & Disaster Recovery", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left")

        ttk.Button(header, text="+ Create Snapshot", style="Primary.TButton", command=self.on_create_backup).pack(side="right", padx=(8, 0))
        ttk.Button(header, text="Validate Archive", style="Secondary.TButton", command=self.on_validate_backup).pack(side="right", padx=6)
        ttk.Button(header, text="Restore Selected", style="Danger.TButton", command=self.on_restore_backup).pack(side="right", padx=6)
        ttk.Button(header, text="Refresh", style="Secondary.TButton", command=self.refresh).pack(side="right")

        # Info card
        info_card = ttk.Frame(self, style="TFrame")
        info_card.pack(fill="x", padx=20, pady=(0, 10))

        dir_text = f"Backup Storage Location: {config.BACKUP_DIR} | Retention: Last {config.BACKUP_RETENTION_COUNT} archives"
        ttk.Label(info_card, text=dir_text, font=FONTS["small"], foreground=COLORS["text_muted"]).pack(side="left")

        # Backups Treeview
        grid_frame = ttk.Frame(self, style="Card.TFrame", padding=2)
        grid_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        cols = ("filename", "created_at", "size")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", selectmode="browse", height=12)

        self.tree.heading("filename", text="Archive File Name")
        self.tree.heading("created_at", text="Creation Timestamp")
        self.tree.heading("size", text="Archive Size")

        self.tree.column("filename", width=340)
        self.tree.column("created_at", width=200, anchor="center")
        self.tree.column("size", width=120, anchor="center")

        v_scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=v_scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        v_scroll.pack(side="right", fill="y")

    def refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        backups = self.backup_mgr.list_backups()
        for b in backups:
            self.tree.insert("", "end", values=(
                b["filename"], b["created_at"].replace("T", " ")[:19], b["size_display"]
            ))

    def get_selected_filename(self) -> str:
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selection Required", "Please select a backup archive from the table.", parent=self)
            return ""
        return self.tree.item(sel[0], "values")[0]

    def on_create_backup(self):
        label = simpledialog.askstring("Backup Label", "Enter a label for this backup (or leave blank for manual):", parent=self)
        if label is None:
            return
        lbl = label.strip() or "manual"
        try:
            res = self.backup_mgr.create_backup(label=lbl)
            messagebox.showinfo("Backup Created", f"Successfully created backup archive:\n{res['backup_id']}", parent=self)
            self.refresh()
        except Exception as e:
            messagebox.showerror("Backup Failed", str(e), parent=self)

    def on_validate_backup(self):
        fn = self.get_selected_filename()
        if not fn:
            return
        path = config.BACKUP_DIR / fn
        try:
            val = self.backup_mgr.validate_backup(path)
            details = (
                f"Archive Integrity: VERIFIED (Clean CRC Checksum)\n"
                f"Contained Files: {', '.join(val['files'])}\n"
                f"Created: {val['manifest'].get('created_at', 'N/A')}\n"
                f"Label: {val['manifest'].get('label', 'N/A')}"
            )
            messagebox.showinfo("Archive Valid", details, parent=self)
        except Exception as e:
            messagebox.showerror("Validation Failed", f"Archive is corrupted or invalid:\n{e}", parent=self)

    def on_restore_backup(self):
        fn = self.get_selected_filename()
        if not fn:
            return

        confirm_msg = (
            f"CAUTION: Restoring will overwrite live inventory and consumption records with data from:\n\n"
            f"  {fn}\n\n"
            f"A pre-restore safety snapshot will be created automatically before overwriting.\n\n"
            f"Are you sure you wish to restore?"
        )
        if messagebox.askyesno("Confirm Disaster Recovery Restore", confirm_msg, icon="warning", parent=self):
            try:
                self.backup_mgr.restore_backup(fn)
                messagebox.showinfo("Restore Complete", f"Data successfully restored from {fn}.", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Restore Failed", str(e), parent=self)
