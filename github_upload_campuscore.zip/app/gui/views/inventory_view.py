"""Inventory Data Grid View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Optional, List

from app.gui.styles import COLORS, FONTS
from app.gui.components.item_dialog import ItemDialog
from app.gui.components.transaction_dialog import TransactionDialog
from app.models import Item
from app.services.inventory_service import inventory_service
from app.analytics.pandas_reports import pandas_reports


class InventoryView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header & Filter Toolbar
        toolbar = ttk.Frame(self, style="Card.TFrame", padding=12)
        toolbar.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(toolbar, text="Medical Supplies Catalog", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 15))

        # Search Query
        ttk.Label(toolbar, text="Search:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(toolbar, textvariable=self.search_var, width=18)
        self.search_entry.pack(side="left", padx=(0, 10))
        self.search_entry.bind("<KeyRelease>", lambda e: self.filter_data())

        # Category Filter
        ttk.Label(toolbar, text="Category:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.cat_var = tk.StringVar(value="All")
        self.cat_combo = ttk.Combobox(toolbar, textvariable=self.cat_var, width=16, state="readonly")
        self.cat_combo.pack(side="left", padx=(0, 10))
        self.cat_combo.bind("<<ComboboxSelected>>", lambda e: self.filter_data())

        # Status Filter
        ttk.Label(toolbar, text="Status:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.status_var = tk.StringVar(value="All")
        self.status_combo = ttk.Combobox(
            toolbar, textvariable=self.status_var, width=14, state="readonly",
            values=["All", "Normal", "Low Stock", "Critical", "Expired", "Out of Stock"]
        )
        self.status_combo.pack(side="left", padx=(0, 10))
        self.status_combo.bind("<<ComboboxSelected>>", lambda e: self.filter_data())

        ttk.Button(toolbar, text="Reset Filters", style="Secondary.TButton", command=self.reset_filters).pack(side="left")

        # Action Buttons
        btn_bar = ttk.Frame(self, style="TFrame")
        btn_bar.pack(fill="x", padx=20, pady=(0, 10))

        ttk.Button(btn_bar, text="+ Add Supply", style="Primary.TButton", command=self.on_add_item).pack(side="left", padx=(0, 6))
        ttk.Button(btn_bar, text="Edit Selected", style="Secondary.TButton", command=self.on_edit_item).pack(side="left", padx=6)
        ttk.Button(btn_bar, text="Receive (IN)", style="Secondary.TButton", command=self.on_receive_stock).pack(side="left", padx=6)
        ttk.Button(btn_bar, text="Issue (OUT)", style="Secondary.TButton", command=self.on_issue_stock).pack(side="left", padx=6)
        ttk.Button(btn_bar, text="Delete", style="Danger.TButton", command=self.on_delete_item).pack(side="left", padx=6)
        ttk.Button(btn_bar, text="Export CSV", style="Secondary.TButton", command=self.on_export_csv).pack(side="right")
        ttk.Button(btn_bar, text="Refresh", style="Secondary.TButton", command=self.refresh).pack(side="right", padx=6)

        # Main Treeview Data Grid
        grid_frame = ttk.Frame(self, style="Card.TFrame", padding=2)
        grid_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        columns = (
            "item_id", "item_name", "category", "unit",
            "quantity", "usable_quantity", "minimum_stock", "expiry_date", "location", "status"
        )
        self.tree = ttk.Treeview(grid_frame, columns=columns, show="headings", selectmode="browse")

        headers = [
            ("item_id", "Item ID", 90),
            ("item_name", "Supply Name", 220),
            ("category", "Category", 130),
            ("unit", "Unit", 100),
            ("quantity", "Physical", 70),
            ("usable_quantity", "Usable", 70),
            ("minimum_stock", "Min Level", 75),
            ("expiry_date", "Expiry Date", 95),
            ("location", "Storage Location", 150),
            ("status", "Status", 95),
        ]

        for col_id, col_text, col_width in headers:
            self.tree.heading(col_id, text=col_text, command=lambda c=col_id: self.sort_by_column(c, False))
            anchor = "center" if col_id in ("quantity", "usable_quantity", "minimum_stock", "status", "expiry_date") else "w"
            self.tree.column(col_id, width=col_width, anchor=anchor)

        v_scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        h_scroll = ttk.Scrollbar(grid_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        v_scroll.pack(side="right", fill="y")
        h_scroll.pack(side="bottom", fill="x")

        # Double click to edit
        self.tree.bind("<Double-1>", lambda e: self.on_edit_item())

    def get_selected_item(self) -> Optional[Item]:
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Selection Required", "Please select a medical supply item from the table.", parent=self)
            return None
        values = self.tree.item(selected[0], "values")
        item_id = values[0]
        try:
            return inventory_service.get_item_by_id(item_id)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to retrieve item: {e}", parent=self)
            return None

    def refresh(self):
        # Refresh categories in dropdown
        items = inventory_service.get_all_items()
        categories = sorted(list({it.category for it in items}))
        self.cat_combo["values"] = ["All"] + categories
        self.filter_data()

    def filter_data(self):
        query = self.search_var.get().strip()
        cat = self.cat_var.get()
        status = self.status_var.get()

        filtered = inventory_service.search_items(
            query=query,
            category=cat if cat != "All" else None,
            status=status if status != "All" else None
        )

        for item in self.tree.get_children():
            self.tree.delete(item)

        for it in filtered:
            self.tree.insert("", "end", values=(
                it.item_id, it.item_name, it.category, it.unit,
                it.quantity, it.usable_quantity, it.minimum_stock,
                it.expiry_date or "N/A", it.location, it.get_stock_status()
            ))

    def reset_filters(self):
        self.search_var.set("")
        self.cat_var.set("All")
        self.status_var.set("All")
        self.filter_data()

    def sort_by_column(self, col: str, reverse: bool):
        items = [(self.tree.set(k, col), k) for k in self.tree.get_children("")]
        try:
            # Try numeric sort
            items.sort(key=lambda t: float(t[0]) if t[0].replace(".", "", 1).isdigit() else t[0].lower(), reverse=reverse)
        except ValueError:
            items.sort(key=lambda t: t[0].lower(), reverse=reverse)

        for index, (_, k) in enumerate(items):
            self.tree.move(k, "", index)
        self.tree.heading(col, command=lambda: self.sort_by_column(col, not reverse))

    def on_add_item(self):
        dlg = ItemDialog(self, title="Add Medical Supply", is_edit=False)
        self.wait_window(dlg)
        if dlg.result:
            try:
                added = inventory_service.add_item(dlg.result)
                messagebox.showinfo("Success", f"Medical supply '{added.item_name}' added successfully.", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error Adding Supply", str(e), parent=self)

    def on_edit_item(self):
        item = self.get_selected_item()
        if not item:
            return
        dlg = ItemDialog(self, title="Edit Medical Supply", item=item, is_edit=True)
        self.wait_window(dlg)
        if dlg.result:
            try:
                updated = inventory_service.update_item(item.item_id, dlg.result)
                messagebox.showinfo("Success", f"Supply '{updated.item_name}' updated successfully.", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error Updating Supply", str(e), parent=self)

    def on_delete_item(self):
        item = self.get_selected_item()
        if not item:
            return
        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete '{item.item_name}' ({item.item_id})?", parent=self):
            try:
                inventory_service.delete_item(item.item_id)
                messagebox.showinfo("Deleted", f"Supply '{item.item_name}' deleted.", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=self)

    def on_receive_stock(self):
        item = self.get_selected_item()
        if not item:
            return
        dlg = TransactionDialog(self, item=item, transaction_type="IN")
        self.wait_window(dlg)
        if dlg.result:
            try:
                up_item, tx = inventory_service.receive_stock(
                    item_id=dlg.result["item_id"],
                    quantity=dlg.result["quantity"],
                    transaction_date=dlg.result["transaction_date"],
                    reference=dlg.result["reference"],
                    remarks=dlg.result["remarks"]
                )
                messagebox.showinfo("Receipt Confirmed", f"Received +{tx.quantity} units for {up_item.item_name}.\nNew physical stock: {up_item.quantity}", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Receipt Error", str(e), parent=self)

    def on_issue_stock(self):
        item = self.get_selected_item()
        if not item:
            return
        dlg = TransactionDialog(self, item=item, transaction_type="OUT")
        self.wait_window(dlg)
        if dlg.result:
            try:
                up_item, tx = inventory_service.issue_stock(
                    item_id=dlg.result["item_id"],
                    quantity=dlg.result["quantity"],
                    transaction_date=dlg.result["transaction_date"],
                    reference=dlg.result["reference"],
                    remarks=dlg.result["remarks"]
                )
                messagebox.showinfo("Issue Confirmed", f"Dispensed -{tx.quantity} units for {up_item.item_name}.\nRemaining usable stock: {up_item.usable_quantity}", parent=self)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Stockout / Issue Error", str(e), parent=self)

    def on_export_csv(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="inventory_export.csv",
            parent=self
        )
        if path:
            try:
                df = pandas_reports.get_inventory_df()
                pandas_reports.export_report_to_csv(df, Path(path))
                messagebox.showinfo("Export Successful", f"Inventory exported to:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)
