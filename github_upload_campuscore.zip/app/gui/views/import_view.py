"""CSV Import Center View for MediStock Analytics Tkinter GUI."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import csv

from app.config import config
from app.gui.styles import COLORS, FONTS
from app.services.inventory_service import inventory_service


class ImportView(ttk.Frame):
    def __init__(self, parent: tk.Widget):
        super().__init__(parent, style="TFrame")
        self.raw_csv_content = ""
        self.current_preview = None
        self._build_ui()

    def _build_ui(self):
        # Header Toolbar
        top_frame = ttk.Frame(self, style="Card.TFrame", padding=14)
        top_frame.pack(fill="x", padx=20, pady=(15, 10))

        ttk.Label(top_frame, text="CSV Data Import & Validation Center", font=FONTS["subtitle"], background=COLORS["bg_surface"]).pack(side="left", padx=(0, 20))

        ttk.Label(top_frame, text="Target Entity:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.entity_var = tk.StringVar(value="inventory")
        self.entity_combo = ttk.Combobox(top_frame, textvariable=self.entity_var, values=["inventory", "consumption"], width=14, state="readonly")
        self.entity_combo.pack(side="left", padx=(0, 15))

        ttk.Label(top_frame, text="Policy:", style="Card.TLabel").pack(side="left", padx=(0, 4))
        self.policy_var = tk.StringVar(value="reject_invalid")
        self.policy_combo = ttk.Combobox(
            top_frame, textvariable=self.policy_var,
            values=["reject_invalid", "all_or_nothing"], width=16, state="readonly"
        )
        self.policy_combo.pack(side="left", padx=(0, 15))

        ttk.Button(top_frame, text="Browse CSV...", style="Primary.TButton", command=self.on_browse_file).pack(side="left", padx=4)
        ttk.Button(top_frame, text="Load Valid Sample", style="Secondary.TButton", command=self.on_load_sample_valid).pack(side="left", padx=4)
        ttk.Button(top_frame, text="Load Invalid Sample", style="Secondary.TButton", command=self.on_load_sample_invalid).pack(side="left", padx=4)

        # Status & Stats Banner
        self.stats_frame = ttk.Frame(self, style="TFrame")
        self.stats_frame.pack(fill="x", padx=20, pady=(0, 10))

        self.lbl_file = ttk.Label(self.stats_frame, text="No CSV file loaded.", font=FONTS["body_bold"])
        self.lbl_file.pack(side="left", padx=(0, 20))

        self.lbl_summary = ttk.Label(self.stats_frame, text="", font=FONTS["body"])
        self.lbl_summary.pack(side="left")

        # Split: Notebook with Preview Tab & Error Inspector Tab
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        # Tab 1: Valid Rows Preview
        preview_tab = ttk.Frame(notebook, style="Card.TFrame", padding=6)
        notebook.add(preview_tab, text="Validated Records (Preview)")

        self.tree_preview = ttk.Treeview(preview_tab, show="headings", height=10)
        p_scroll = ttk.Scrollbar(preview_tab, orient="vertical", command=self.tree_preview.yview)
        self.tree_preview.configure(yscrollcommand=p_scroll.set)
        self.tree_preview.pack(side="left", fill="both", expand=True)
        p_scroll.pack(side="right", fill="y")

        # Tab 2: Error & Rejection Inspector
        errors_tab = ttk.Frame(notebook, style="Card.TFrame", padding=6)
        notebook.add(errors_tab, text="Rejection & Error Inspector")

        err_cols = ("row", "reason", "data")
        self.tree_errors = ttk.Treeview(errors_tab, columns=err_cols, show="headings", height=10)
        self.tree_errors.heading("row", text="CSV Line #")
        self.tree_errors.heading("reason", text="Rejection Reason")
        self.tree_errors.heading("data", text="Row Content")

        self.tree_errors.column("row", width=80, anchor="center")
        self.tree_errors.column("reason", width=320)
        self.tree_errors.column("data", width=400)

        e_scroll = ttk.Scrollbar(errors_tab, orient="vertical", command=self.tree_errors.yview)
        self.tree_errors.configure(yscrollcommand=e_scroll.set)
        self.tree_errors.pack(side="left", fill="both", expand=True)
        e_scroll.pack(side="right", fill="y")

        # Commit Bar
        commit_bar = ttk.Frame(self, style="Card.TFrame", padding=12)
        commit_bar.pack(fill="x", padx=20, pady=(0, 15))

        self.btn_commit = ttk.Button(commit_bar, text="Confirm & Commit Import", style="Primary.TButton", command=self.on_commit_import, state="disabled")
        self.btn_commit.pack(side="right", padx=(8, 0))

        ttk.Button(commit_bar, text="Export Error Report", style="Secondary.TButton", command=self.on_export_errors).pack(side="right", padx=8)
        ttk.Button(commit_bar, text="Cancel / Clear", style="Secondary.TButton", command=self.clear_import).pack(side="right")

    def on_browse_file(self):
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            parent=self
        )
        if path:
            self._process_file_path(Path(path))

    def on_load_sample_valid(self):
        path = config.DATA_DIR / "sample_import_valid.csv"
        if path.exists():
            self.entity_var.set("inventory")
            self._process_file_path(path)
        else:
            messagebox.showwarning("Not Found", "sample_import_valid.csv not found in data directory.", parent=self)

    def on_load_sample_invalid(self):
        path = config.DATA_DIR / "sample_import_invalid.csv"
        if path.exists():
            self.entity_var.set("inventory")
            self._process_file_path(path)
        else:
            messagebox.showwarning("Not Found", "sample_import_invalid.csv not found in data directory.", parent=self)

    def _process_file_path(self, path: Path):
        try:
            content = path.read_text(encoding="utf-8")
            self.raw_csv_content = content
            self.lbl_file.config(text=f"Loaded File: {path.name}")
            self.run_preview()
        except Exception as e:
            messagebox.showerror("File Error", f"Could not read CSV file: {e}", parent=self)

    def run_preview(self):
        if not self.raw_csv_content:
            return
        entity = self.entity_var.get()
        try:
            preview = inventory_service.preview_import_csv(self.raw_csv_content, target_entity=entity)
            self.current_preview = preview

            # Summary banner
            self.lbl_summary.config(
                text=f"Total: {preview['total_rows']} rows | Valid: {preview['valid_count']} | Invalid: {preview['invalid_count']}",
                foreground=COLORS["danger"] if preview['invalid_count'] > 0 else COLORS["success"]
            )

            # Setup Preview Columns dynamically
            for item in self.tree_preview.get_children():
                self.tree_preview.delete(item)

            if entity == "inventory":
                cols = ("action", "item_id", "item_name", "category", "unit", "quantity", "minimum_stock", "expiry_date")
                self.tree_preview["columns"] = cols
                for c in cols:
                    self.tree_preview.heading(c, text=c.replace("_", " ").title())
                    self.tree_preview.column(c, width=110)
                self.tree_preview.column("action", width=80, anchor="center")

                for row in preview["valid_rows"]:
                    d = row["data"]
                    self.tree_preview.insert("", "end", values=(
                        row["action"], d.get("item_id"), d.get("item_name"),
                        d.get("category"), d.get("unit"), d.get("quantity"),
                        d.get("minimum_stock"), d.get("expiry_date")
                    ))
            else:
                cols = ("action", "transaction_id", "item_id", "transaction_date", "transaction_type", "quantity")
                self.tree_preview["columns"] = cols
                for c in cols:
                    self.tree_preview.heading(c, text=c.replace("_", " ").title())
                    self.tree_preview.column(c, width=120)

                for row in preview["valid_rows"]:
                    d = row["data"]
                    self.tree_preview.insert("", "end", values=(
                        row["action"], d.get("transaction_id"), d.get("item_id"),
                        d.get("transaction_date"), d.get("transaction_type"), d.get("quantity")
                    ))

            # Populate Error Inspector
            for item in self.tree_errors.get_children():
                self.tree_errors.delete(item)

            for err in preview["invalid_rows"]:
                self.tree_errors.insert("", "end", values=(
                    f"Line {err['row']}",
                    err["reason"],
                    str(err["data"])
                ))

            self.btn_commit.configure(state="normal" if preview["can_commit"] else "disabled")

        except Exception as e:
            messagebox.showerror("Preview Failed", str(e), parent=self)
            self.btn_commit.configure(state="disabled")

    def on_commit_import(self):
        if not self.raw_csv_content or not self.current_preview:
            return
        entity = self.entity_var.get()
        policy = self.policy_var.get()

        valid_c = self.current_preview["valid_count"]
        invalid_c = self.current_preview["invalid_count"]

        msg = (
            f"Ready to commit import into '{entity.upper()}'.\n\n"
            f"- Valid rows to commit: {valid_c}\n"
            f"- Rejected rows: {invalid_c}\n"
            f"- Policy: {policy}\n\n"
            "An automated safety backup will be created prior to commit.\n"
            "Proceed with commit?"
        )

        if messagebox.askyesno("Confirm Safe Import", msg, parent=self):
            try:
                res = inventory_service.commit_import_csv(
                    raw_csv_content=self.raw_csv_content,
                    target_entity=entity,
                    reject_mode=policy
                )
                success_msg = (
                    f"Import successfully committed!\n\n"
                    f"- Records committed: {res['committed_count']}\n"
                    f"- Records rejected: {res['rejected_count']}\n"
                    f"- Safety Backup: {res['backup_id']}"
                )
                messagebox.showinfo("Import Complete", success_msg, parent=self)
                self.clear_import()
            except Exception as e:
                messagebox.showerror("Import Rejected", str(e), parent=self)

    def on_export_errors(self):
        if not self.current_preview or not self.current_preview["invalid_rows"]:
            messagebox.showinfo("No Errors", "There are no rejected rows to export.", parent=self)
            return

        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="import_rejected_rows_report.csv",
            parent=self
        )
        if path:
            try:
                with open(path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(["line_number", "rejection_reason", "raw_data"])
                    for err in self.current_preview["invalid_rows"]:
                        writer.writerow([err["row"], err["reason"], str(err["data"])])
                messagebox.showinfo("Exported", f"Error report saved to:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)

    def clear_import(self):
        self.raw_csv_content = ""
        self.current_preview = None
        self.lbl_file.config(text="No CSV file loaded.")
        self.lbl_summary.config(text="")
        for item in self.tree_preview.get_children():
            self.tree_preview.delete(item)
        for item in self.tree_errors.get_children():
            self.tree_errors.delete(item)
        self.btn_commit.configure(state="disabled")
