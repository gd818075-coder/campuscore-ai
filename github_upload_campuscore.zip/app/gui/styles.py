"""Theme and styling configuration for the Tkinter desktop GUI.

Implements a professional, accessible Medical Light Theme using ttk.Style.
"""

import tkinter as tk
from tkinter import ttk


# Medical Light Theme Color Palette
COLORS = {
    "bg_main": "#F8FAFC",         # Soft light background
    "bg_surface": "#FFFFFF",      # Card / container white
    "bg_sidebar": "#F1F5F9",      # Sidebar slate
    "border": "#E2E8F0",          # Subtle borders
    "primary": "#0284C7",         # Clinical Medical Blue
    "primary_hover": "#0369A1",
    "primary_light": "#E0F2FE",
    "text_dark": "#0F172A",       # High contrast title text
    "text_body": "#334155",       # Body text
    "text_muted": "#64748B",      # Secondary / hints
    "text_light": "#FFFFFF",
    "success": "#10B981",         # Normal / Good status
    "success_bg": "#ECFDF5",
    "warning": "#F59E0B",         # Low stock amber
    "warning_bg": "#FFFBEB",
    "danger": "#EF4444",          # Critical / Expired red
    "danger_bg": "#FEF2F2",
    "active_nav": "#0284C7"
}

FONTS = {
    "title": ("Segoe UI", 16, "bold"),
    "subtitle": ("Segoe UI", 12, "bold"),
    "heading": ("Segoe UI", 11, "bold"),
    "body": ("Segoe UI", 10),
    "body_bold": ("Segoe UI", 10, "bold"),
    "small": ("Segoe UI", 9),
    "metric_value": ("Segoe UI", 20, "bold"),
    "mono": ("Consolas", 9)
}


def apply_light_theme(root: tk.Tk) -> ttk.Style:
    """Configure modern ttk styles for light theme."""
    style = ttk.Style(root)
    # Use clam as reliable base across platforms
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    root.configure(bg=COLORS["bg_main"])

    # Base Frame & Card Styles
    style.configure("TFrame", background=COLORS["bg_main"])
    style.configure("Card.TFrame", background=COLORS["bg_surface"], relief="flat", borderwidth=1)
    style.configure("Sidebar.TFrame", background=COLORS["bg_sidebar"])
    style.configure("Header.TFrame", background=COLORS["bg_surface"])

    # Labels
    style.configure("TLabel", background=COLORS["bg_main"], foreground=COLORS["text_body"], font=FONTS["body"])
    style.configure("Card.TLabel", background=COLORS["bg_surface"], foreground=COLORS["text_body"], font=FONTS["body"])
    style.configure("Title.TLabel", background=COLORS["bg_main"], foreground=COLORS["text_dark"], font=FONTS["title"])
    style.configure("Header.TLabel", background=COLORS["bg_surface"], foreground=COLORS["text_dark"], font=FONTS["title"])
    style.configure("CardTitle.TLabel", background=COLORS["bg_surface"], foreground=COLORS["text_muted"], font=FONTS["heading"])
    style.configure("CardValue.TLabel", background=COLORS["bg_surface"], foreground=COLORS["primary"], font=FONTS["metric_value"])
    style.configure("Status.TLabel", background=COLORS["border"], foreground=COLORS["text_dark"], font=FONTS["small"])

    # Buttons
    style.configure(
        "TButton",
        font=FONTS["body"],
        padding=(10, 6),
        borderwidth=1,
        relief="flat"
    )

    style.configure(
        "Primary.TButton",
        background=COLORS["primary"],
        foreground=COLORS["text_light"],
        font=FONTS["body_bold"],
        padding=(12, 6)
    )
    style.map(
        "Primary.TButton",
        background=[("active", COLORS["primary_hover"])],
        foreground=[("active", COLORS["text_light"])]
    )

    style.configure(
        "Secondary.TButton",
        background=COLORS["bg_surface"],
        foreground=COLORS["text_dark"],
        bordercolor=COLORS["border"],
        font=FONTS["body"],
        padding=(10, 6)
    )

    style.configure(
        "Danger.TButton",
        background=COLORS["danger"],
        foreground=COLORS["text_light"],
        font=FONTS["body_bold"],
        padding=(10, 6)
    )

    style.configure(
        "Nav.TButton",
        background=COLORS["bg_sidebar"],
        foreground=COLORS["text_dark"],
        font=FONTS["body"],
        anchor="w",
        padding=(14, 8),
        borderwidth=0
    )
    style.map(
        "Nav.TButton",
        background=[("active", COLORS["primary_light"])],
        foreground=[("active", COLORS["primary"])]
    )

    style.configure(
        "ActiveNav.TButton",
        background=COLORS["primary"],
        foreground=COLORS["text_light"],
        font=FONTS["body_bold"],
        anchor="w",
        padding=(14, 8),
        borderwidth=0
    )

    # Entry & Combobox
    style.configure("TEntry", fieldbackground=COLORS["bg_surface"], foreground=COLORS["text_dark"], padding=6)
    style.configure("TCombobox", fieldbackground=COLORS["bg_surface"], foreground=COLORS["text_dark"], padding=5)

    # Treeview (Data Grids)
    style.configure(
        "Treeview",
        background=COLORS["bg_surface"],
        foreground=COLORS["text_dark"],
        fieldbackground=COLORS["bg_surface"],
        rowheight=26,
        font=FONTS["body"],
        borderwidth=0
    )
    style.configure(
        "Treeview.Heading",
        background=COLORS["bg_sidebar"],
        foreground=COLORS["text_dark"],
        font=FONTS["heading"],
        relief="flat",
        padding=(6, 6)
    )
    style.map("Treeview", background=[("selected", COLORS["primary_light"])], foreground=[("selected", COLORS["primary"])])

    # Notebook (Tabs)
    style.configure("TNotebook", background=COLORS["bg_main"], borderwidth=0)
    style.configure("TNotebook.Tab", background=COLORS["bg_sidebar"], foreground=COLORS["text_dark"], padding=(12, 6), font=FONTS["heading"])
    style.map("TNotebook.Tab", background=[("selected", COLORS["bg_surface"])], foreground=[("selected", COLORS["primary"])])

    return style
