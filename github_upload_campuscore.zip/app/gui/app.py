"""Main Tkinter Desktop Application for MediStock Analytics.

Integrates all 10 module views with professional medical light theme,
left navigation sidebar, status bar, and menu system.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from typing import Dict, Any

from app.config import config
from app.gui.styles import apply_light_theme, COLORS, FONTS
from app.gui.views import (
    DashboardView,
    InventoryView,
    TransactionView,
    ImportView,
    AlertsView,
    AnalyticsView,
    BackupView,
    LogView,
    SettingsView,
    AboutView
)


class MediStockApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MediStock Analytics - Medical Logistics & CSV Analytics Platform")
        self.geometry("1240x780")
        self.minsize(1024, 650)

        # Apply Light Theme ttk styling
        self.style = apply_light_theme(self)

        self.current_view_name = "dashboard"
        self.views: Dict[str, ttk.Frame] = {}
        self.nav_buttons: Dict[str, ttk.Button] = {}

        self._build_menu()
        self._build_layout()
        self.show_view("dashboard")
        self._update_clock()

    def _build_menu(self):
        menubar = tk.Menu(self)

        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Dashboard", command=lambda: self.show_view("dashboard"))
        file_menu.add_command(label="CSV Import Center", command=lambda: self.show_view("import"))
        file_menu.add_command(label="Backups & Snapshots", command=lambda: self.show_view("backups"))
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        # Inventory Menu
        inv_menu = tk.Menu(menubar, tearoff=0)
        inv_menu.add_command(label="All Supplies", command=lambda: self.show_view("inventory"))
        inv_menu.add_command(label="Stock Transactions", command=lambda: self.show_view("transactions"))
        inv_menu.add_command(label="Shortage Alerts", command=lambda: self.show_view("alerts"))
        menubar.add_cascade(label="Inventory", menu=inv_menu)

        # Analytics Menu
        analytics_menu = tk.Menu(menubar, tearoff=0)
        analytics_menu.add_command(label="NumPy Analytics", command=lambda: self.show_view("analytics"))
        analytics_menu.add_command(label="System & Audit Logs", command=lambda: self.show_view("logs"))
        menubar.add_cascade(label="Analytics", menu=analytics_menu)

        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Settings & Guidance", command=lambda: self.show_view("settings"))
        help_menu.add_command(label="About Academic Project", command=lambda: self.show_view("about"))
        menubar.add_cascade(label="Help", menu=help_menu)

        self.config(menu=menubar)

    def _build_layout(self):
        # 1. Top Header Bar
        top_header = tk.Frame(self, bg=COLORS["bg_surface"], height=55, highlightthickness=1, highlightbackground=COLORS["border"])
        top_header.pack(side="top", fill="x")

        # Brand Title
        brand_frame = tk.Frame(top_header, bg=COLORS["bg_surface"])
        brand_frame.pack(side="left", padx=18, pady=8)

        lbl_logo = tk.Label(brand_frame, text="MEDISTOCK", font=("Segoe UI", 13, "bold"), fg=COLORS["primary"], bg=COLORS["bg_surface"])
        lbl_logo.pack(side="left")
        lbl_sub = tk.Label(brand_frame, text="ANALYTICS", font=("Segoe UI", 13), fg=COLORS["text_dark"], bg=COLORS["bg_surface"])
        lbl_sub.pack(side="left", padx=(4, 12))

        lbl_course = tk.Label(brand_frame, text="UC25CA2302 | Python Programming Practice", font=FONTS["small"], fg=COLORS["text_muted"], bg=COLORS["bg_surface"])
        lbl_course.pack(side="left", padx=(8, 0))

        # Clock & System Indicator
        right_header = tk.Frame(top_header, bg=COLORS["bg_surface"])
        right_header.pack(side="right", padx=18, pady=8)

        self.clock_lbl = tk.Label(right_header, text="", font=FONTS["small"], fg=COLORS["text_body"], bg=COLORS["bg_surface"])
        self.clock_lbl.pack(side="right", padx=(10, 0))

        status_pill = tk.Label(right_header, text="  SYSTEM READY  ", font=("Segoe UI", 8, "bold"), bg=COLORS["success_bg"], fg=COLORS["success"])
        status_pill.pack(side="right")

        # 2. Main Body Split: Left Sidebar + Central Dynamic Content
        body_frame = tk.Frame(self, bg=COLORS["bg_main"])
        body_frame.pack(side="top", fill="both", expand=True)

        # Left Sidebar Navigation
        sidebar = tk.Frame(body_frame, bg=COLORS["bg_sidebar"], width=230, highlightthickness=1, highlightbackground=COLORS["border"])
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        nav_header = tk.Label(sidebar, text="NAVIGATION", font=("Segoe UI", 9, "bold"), fg=COLORS["text_muted"], bg=COLORS["bg_sidebar"])
        nav_header.pack(anchor="w", padx=16, pady=(16, 8))

        nav_items = [
            ("dashboard", "Dashboard"),
            ("inventory", "Inventory Catalog"),
            ("transactions", "Stock Transactions"),
            ("import", "CSV Import Center"),
            ("alerts", "Stock Alerts"),
            ("analytics", "Analytics & Reports"),
            ("backups", "Backups & Files"),
            ("logs", "Exception & Audit Logs"),
            ("settings", "Settings & Help"),
            ("about", "About Academic Info"),
        ]

        for view_key, nav_label in nav_items:
            btn = ttk.Button(
                sidebar,
                text=f"  {nav_label}",
                style="Nav.TButton",
                command=lambda k=view_key: self.show_view(k)
            )
            btn.pack(fill="x", padx=8, pady=2)
            self.nav_buttons[view_key] = btn

        # 3. Central Content Area
        self.content_area = tk.Frame(body_frame, bg=COLORS["bg_main"])
        self.content_area.pack(side="left", fill="both", expand=True)

        # 4. Bottom Status Bar
        status_bar = tk.Frame(self, bg=COLORS["border"], height=24)
        status_bar.pack(side="bottom", fill="x")

        self.status_left = tk.Label(
            status_bar,
            text=f"Data Source: {config.INVENTORY_CSV.name} | Journal: Active | Storage: Atomic os.replace",
            font=FONTS["small"],
            fg=COLORS["text_dark"],
            bg=COLORS["border"]
        )
        self.status_left.pack(side="left", padx=10)

        self.status_right = tk.Label(
            status_bar,
            text="Course: UC25CA2302 (Assignment 2) | FCIT BCA",
            font=FONTS["small"],
            fg=COLORS["text_muted"],
            bg=COLORS["border"]
        )
        self.status_right.pack(side="right", padx=10)

    def _update_clock(self):
        now_str = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
        self.clock_lbl.config(text=now_str)
        self.after(1000, self._update_clock)

    def show_view(self, view_name: str):
        self.current_view_name = view_name

        # Update Nav Button Styles
        for key, btn in self.nav_buttons.items():
            if key == view_name:
                btn.configure(style="ActiveNav.TButton")
            else:
                btn.configure(style="Nav.TButton")

        # Lazy initialize or reuse view
        if view_name not in self.views:
            if view_name == "dashboard":
                self.views[view_name] = DashboardView(self.content_area, navigate_fn=self.show_view)
            elif view_name == "inventory":
                self.views[view_name] = InventoryView(self.content_area)
            elif view_name == "transactions":
                self.views[view_name] = TransactionView(self.content_area)
            elif view_name == "import":
                self.views[view_name] = ImportView(self.content_area)
            elif view_name == "alerts":
                self.views[view_name] = AlertsView(self.content_area)
            elif view_name == "analytics":
                self.views[view_name] = AnalyticsView(self.content_area)
            elif view_name == "backups":
                self.views[view_name] = BackupView(self.content_area)
            elif view_name == "logs":
                self.views[view_name] = LogView(self.content_area)
            elif view_name == "settings":
                self.views[view_name] = SettingsView(self.content_area)
            elif view_name == "about":
                self.views[view_name] = AboutView(self.content_area)

        # Hide other views and show target view
        for name, view in self.views.items():
            if name == view_name:
                view.pack(fill="both", expand=True)
                if hasattr(view, "refresh"):
                    view.refresh()
            else:
                view.pack_forget()


def launch_gui():
    """Application launcher function."""
    app = MediStockApp()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
