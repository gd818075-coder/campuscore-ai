"""Modal dialog for executing stock transactions (Receive IN / Issue OUT) in Tkinter."""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from typing import Optional, Dict, Any

from app.gui.styles import COLORS, FONTS
from app.models import Item


class TransactionDialog(tk.Toplevel):
    def __init__(
        self,
        parent: tk.Widget,
        item: Item,
        transaction_type: str = "IN"  # "IN" or "OUT"
    ):
        super().__init__(parent)
        self.item = item
        self.transaction_type = transaction_type.upper()
        self.result: Optional[Dict[str, Any]] = None

        action_name = "Receive Stock (IN)" if self.transaction_type == "IN" else "Issue Stock (OUT)"
        self.title(f"MedStock - {action_name}")
        self.geometry("480x440")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg_surface"])

        self.transient(parent)
        self.grab_set()

        self._build_ui()
        self.center_window(parent)

    def center_window(self, parent: tk.Widget):
        self.update_idletasks()
        pw = parent.winfo_width()
        ph = parent.winfo_height()
        px = parent.winfo_rootx()
        py = parent.winfo_rooty()
        w = self.winfo_width()
        h = self.winfo_height()
        x = px + (pw - w) // 2
        y = py + (ph - h) // 2
        self.geometry(f"+{max(0, x)}+{max(0, y)}")

    def _build_ui(self):
        container = ttk.Frame(self, style="Card.TFrame", padding=20)
        container.pack(fill="both", expand=True)

        is_in = self.transaction_type == "IN"
        action_title = "Receive Incoming Supplies (Stock IN)" if is_in else "Dispense / Issue Supplies (Stock OUT)"
        accent_color = COLORS["success"] if is_in else COLORS["primary"]

        ttk.Label(
            container,
            text=action_title,
            font=FONTS["subtitle"],
            foreground=accent_color,
            background=COLORS["bg_surface"]
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))

        # Item Info summary card
        info_frame = tk.Frame(container, bg=COLORS["bg_main"], padx=12, pady=10)
        info_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 16))

        info_text = (
            f"Supply: {self.item.item_name} ({self.item.item_id})\n"
            f"Physical Stock: {self.item.quantity} {self.item.unit} | Usable Stock: {self.item.usable_quantity} {self.item.unit}\n"
            f"Expiry Date: {self.item.expiry_date or 'N/A'} | Status: {self.item.get_stock_status()}"
        )
        ttk.Label(info_frame, text=info_text, font=FONTS["small"]).pack(anchor="w")

        # Inputs
        ttk.Label(container, text="Quantity to Transact *:", style="Card.TLabel").grid(row=2, column=0, sticky="w", pady=6)
        self.qty_entry = ttk.Entry(container, width=28)
        self.qty_entry.grid(row=2, column=1, sticky="w", pady=6)
        self.qty_entry.insert(0, "1")

        ttk.Label(container, text="Transaction Date (YYYY-MM-DD):", style="Card.TLabel").grid(row=3, column=0, sticky="w", pady=6)
        self.date_entry = ttk.Entry(container, width=28)
        self.date_entry.grid(row=3, column=1, sticky="w", pady=6)
        self.date_entry.insert(0, date.today().isoformat())

        ttk.Label(container, text="Reference # (PO / Ward Req):", style="Card.TLabel").grid(row=4, column=0, sticky="w", pady=6)
        self.ref_entry = ttk.Entry(container, width=28)
        self.ref_entry.grid(row=4, column=1, sticky="w", pady=6)
        self.ref_entry.insert(0, "PO-REC-01" if is_in else "REQ-WARD-01")

        ttk.Label(container, text="Remarks / Department:", style="Card.TLabel").grid(row=5, column=0, sticky="w", pady=6)
        self.remarks_entry = ttk.Entry(container, width=28)
        self.remarks_entry.grid(row=5, column=1, sticky="w", pady=6)
        self.remarks_entry.insert(0, "Pharmacy receipt" if is_in else "Dispensed to Clinic")

        # Buttons
        btn_frame = ttk.Frame(container, style="Card.TFrame")
        btn_frame.grid(row=6, column=0, columnspan=2, sticky="e", pady=(24, 0))

        ttk.Button(btn_frame, text="Cancel", style="Secondary.TButton", command=self.destroy).pack(side="right", padx=(8, 0))
        btn_style = "Primary.TButton" if is_in else "Primary.TButton"
        btn_txt = "Confirm Receipt" if is_in else "Confirm Issue"
        ttk.Button(btn_frame, text=btn_txt, style=btn_style, command=self._on_submit).pack(side="right")

    def _on_submit(self):
        try:
            qty_str = self.qty_entry.get().strip()
            date_str = self.date_entry.get().strip()
            ref_str = self.ref_entry.get().strip()
            remarks_str = self.remarks_entry.get().strip()

            if not qty_str:
                messagebox.showerror("Error", "Quantity is required.", parent=self)
                return

            self.result = {
                "item_id": self.item.item_id,
                "quantity": int(qty_str),
                "transaction_date": date_str,
                "reference": ref_str,
                "remarks": remarks_str,
                "type": self.transaction_type
            }
            self.destroy()
        except ValueError:
            messagebox.showerror("Error", "Quantity must be a valid positive integer.", parent=self)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)
