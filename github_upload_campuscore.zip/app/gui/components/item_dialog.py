"""Modal dialog for adding and editing medical supplies in Tkinter."""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Dict, Any

from app.gui.styles import COLORS, FONTS
from app.models import Item


class ItemDialog(tk.Toplevel):
    def __init__(
        self,
        parent: tk.Widget,
        title: str,
        item: Optional[Item] = None,
        is_edit: bool = False
    ):
        super().__init__(parent)
        self.title(title)
        self.geometry("520x560")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg_surface"])

        self.item = item
        self.is_edit = is_edit
        self.result: Optional[Dict[str, Any]] = None

        self.transient(parent)
        self.grab_set()

        self._build_ui()
        self.center_window(parent)

    def center_window(self, parent: tk.Widget):
        self.update_idletasks()
        pw = parent.winfo_width()
        ph = parent.winfo_height()
        px = parent.winfo_rootx()
        py = parent.winfo_rooty()
        w = self.winfo_width()
        h = self.winfo_height()
        x = px + (pw - w) // 2
        y = py + (ph - h) // 2
        self.geometry(f"+{max(0, x)}+{max(0, y)}")

    def _build_ui(self):
        container = ttk.Frame(self, style="Card.TFrame", padding=20)
        container.pack(fill="both", expand=True)

        header_lbl = ttk.Label(
            container,
            text="Edit Medical Supply" if self.is_edit else "Add New Medical Supply",
            font=FONTS["subtitle"],
            foreground=COLORS["primary"],
            background=COLORS["bg_surface"]
        )
        header_lbl.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 16))

        # Fields
        labels = [
            ("Item ID *:", "item_id"),
            ("Item Name *:", "item_name"),
            ("Category *:", "category"),
            ("Unit of Measure *:", "unit"),
            ("Physical Quantity *:", "quantity"),
            ("Minimum Reorder Level *:", "minimum_stock"),
            ("Expiry Date (YYYY-MM-DD):", "expiry_date"),
            ("Storage Location:", "location"),
        ]

        self.entries: Dict[str, ttk.Entry] = {}

        categories = [
            "Protective Wear", "Respiratory", "Syringes & Needles",
            "IV Infusion", "Wound Care", "Sanitation",
            "Antiseptics", "Surgical Instruments", "Diagnostics", "General"
        ]

        for idx, (label_text, field_key) in enumerate(labels, start=1):
            lbl = ttk.Label(container, text=label_text, style="Card.TLabel")
            lbl.grid(row=idx, column=0, sticky="w", pady=6)

            if field_key == "category":
                combo = ttk.Combobox(container, values=categories, width=32)
                combo.grid(row=idx, column=1, sticky="w", pady=6)
                self.entries[field_key] = combo
            else:
                entry = ttk.Entry(container, width=34)
                entry.grid(row=idx, column=1, sticky="w", pady=6)
                self.entries[field_key] = entry

        # Pre-fill if editing
        if self.item:
            self.entries["item_id"].insert(0, self.item.item_id)
            if self.is_edit:
                self.entries["item_id"].configure(state="disabled")
            self.entries["item_name"].insert(0, self.item.item_name)
            self.entries["category"].set(self.item.category)
            self.entries["unit"].insert(0, self.item.unit)
            self.entries["quantity"].insert(0, str(self.item.quantity))
            self.entries["minimum_stock"].insert(0, str(self.item.minimum_stock))
            self.entries["expiry_date"].insert(0, self.item.expiry_date)
            self.entries["location"].insert(0, self.item.location)
        else:
            self.entries["category"].set("General")
            self.entries["unit"].insert(0, "Piece")
            self.entries["quantity"].insert(0, "0")
            self.entries["minimum_stock"].insert(0, "10")
            self.entries["location"].insert(0, "Main Pharmacy")

        # Buttons frame
        btn_frame = ttk.Frame(container, style="Card.TFrame")
        btn_frame.grid(row=len(labels) + 1, column=0, columnspan=2, sticky="e", pady=(20, 0))

        cancel_btn = ttk.Button(btn_frame, text="Cancel", style="Secondary.TButton", command=self.destroy)
        cancel_btn.pack(side="right", padx=(8, 0))

        save_btn = ttk.Button(btn_frame, text="Save Supply", style="Primary.TButton", command=self._on_save)
        save_btn.pack(side="right")

    def _on_save(self):
        try:
            data = {k: v.get().strip() for k, v in self.entries.items()}
            # Validation
            if not data["item_id"]:
                messagebox.showerror("Validation Error", "Item ID is required.", parent=self)
                return
            if not data["item_name"]:
                messagebox.showerror("Validation Error", "Item Name is required.", parent=self)
                return
            if not data["category"]:
                messagebox.showerror("Validation Error", "Category is required.", parent=self)
                return

            self.result = data
            self.destroy()
        except Exception as e:
            messagebox.showerror("Input Error", str(e), parent=self)
