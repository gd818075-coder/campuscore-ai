"""FastAPI Application Entry Point for MediStock Analytics.

Serves REST API routes and hosts the responsive companion web application.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pathlib import Path
import os

from app.config import config
from app.api.routes import router as api_router
from app.services.logger_service import logger_service
from app.exceptions import MedicalInventoryError

app = FastAPI(
    title="MediStock Analytics API",
    description="Backend API and companion service layer for Medical Logistics & CSV Analytics Platform",
    version=config.VERSION,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS configuration for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register REST API Router
app.include_router(api_router)


# Global Exception Handler for domain errors
@app.exception_handler(MedicalInventoryError)
async def domain_exception_handler(request: Request, exc: MedicalInventoryError):
    logger_service.log_diagnostic("WARNING", f"Handled domain exception: {exc.message}")
    return JSONResponse(
        status_code=400,
        content=exc.to_dict()
    )


# Static files mount for companion web interface
STATIC_DIR = Path(__file__).resolve().parent / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", include_in_schema=False)
def serve_web_companion():
    """Serve the root Single Page Application."""
    index_file = STATIC_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {
        "app": config.APP_NAME,
        "status": "online",
        "api_docs": "/docs",
        "message": "Web companion static index not yet generated."
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
