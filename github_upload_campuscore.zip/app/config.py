"""Centralized application configuration and settings for MediStock Analytics."""

import os
from pathlib import Path
from dataclasses import dataclass


@dataclass
class AppConfig:
    # Anchor all paths relative to project root
    BASE_DIR: Path = Path(__file__).resolve().parent.parent

    # Data directory & file paths
    DATA_DIR: Path = BASE_DIR / "data"
    INVENTORY_CSV: Path = DATA_DIR / "inventory.csv"
    CONSUMPTION_CSV: Path = DATA_DIR / "consumption.csv"
    JOURNAL_FILE: Path = DATA_DIR / "journal.json"
    LOCK_FILE: Path = DATA_DIR / "medistock.lock"

    # Backup settings
    BACKUP_DIR: Path = BASE_DIR / "backups"
    BACKUP_RETENTION_COUNT: int = 15

    # Logging settings
    LOG_DIR: Path = BASE_DIR / "logs"
    APP_LOG_FILE: Path = LOG_DIR / "app.log"
    AUDIT_LOG_FILE: Path = LOG_DIR / "audit.log"
    LOG_MAX_BYTES: int = 5 * 1024 * 1024  # 5 MB
    LOG_BACKUP_COUNT: int = 5

    # Inventory business rules
    CRITICAL_STOCK_RATIO: float = 0.50  # quantity <= 50% of minimum_stock
    EXCLUDE_EXPIRED_FROM_USABLE: bool = True

    # Application metadata
    APP_NAME: str = "MediStock Analytics"
    VERSION: str = "2.0.0"
    COURSE_NAME: str = "Python Programming with Practice"
    COURSE_CODE: str = "UC25CA2302"
    SUBMISSION_DEADLINE: str = "24 November 2026"
    MAX_REPORT_PAGES: int = 10

    def ensure_directories(self) -> None:
        """Create necessary system directories if they do not exist."""
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        self.LOG_DIR.mkdir(parents=True, exist_ok=True)


config = AppConfig()
config.ensure_directories()
