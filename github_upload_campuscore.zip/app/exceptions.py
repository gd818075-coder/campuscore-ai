"""Custom exception hierarchy for MediStock Analytics.

Explicitly satisfies Course Outcome CO4 and assignment exception handling requirements.
"""

from typing import Optional, Dict, Any


class MedicalInventoryError(Exception):
    """Base exception for all domain-specific errors in MediStock Analytics."""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception details to dictionary for API/logging contracts."""
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "details": self.details
        }


class StockoutWarningException(MedicalInventoryError):
    """Raised when an issue/consumption operation exceeds usable physical stock."""
    pass


class CorruptedDataRecordException(MedicalInventoryError):
    """Raised when a CSV record has missing headers, wrong column count, or malformed data."""
    pass


class InvalidQuantityException(MedicalInventoryError):
    """Raised when a quantity is non-numeric, negative, fractional, zero (where forbidden), NaN, or infinite."""
    pass


class DuplicateRecordException(MedicalInventoryError):
    """Raised when an item_id or transaction_id already exists in the repository."""
    pass


class UnknownItemException(MedicalInventoryError):
    """Raised when referencing an item_id that does not exist in inventory."""
    pass


class StorageOperationException(MedicalInventoryError):
    """Raised when file I/O, atomic file swap, or locking encounters a system failure."""
    pass


class BackupOperationException(MedicalInventoryError):
    """Raised when creating, verifying, rotating, or restoring a backup fails."""
    pass
