"""Services package initialization."""
# Keep package init clean to avoid circular dependencies between repo and service layers.
