"""Logging and auditing services for MediStock Analytics.

Implements rotating file handlers for internal diagnostic error logs
and structured JSON-compatible audit trail logs.
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
import json

from app.config import config


class LoggerService:
    _instance: Optional["LoggerService"] = None

    def __init__(self, log_dir: Optional[Path] = None):
        self.log_dir = log_dir or config.LOG_DIR
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.app_log_path = self.log_dir / "app.log"
        self.audit_log_path = self.log_dir / "audit.log"

        self.app_logger = self._setup_app_logger()
        self.audit_logger = self._setup_audit_logger()

    @classmethod
    def get_instance(cls) -> "LoggerService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _setup_app_logger(self) -> logging.Logger:
        logger = logging.getLogger("medistock.app")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = RotatingFileHandler(
                self.app_log_path,
                maxBytes=config.LOG_MAX_BYTES,
                backupCount=config.LOG_BACKUP_COUNT,
                encoding="utf-8"
            )
            formatter = logging.Formatter(
                fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        return logger

    def _setup_audit_logger(self) -> logging.Logger:
        logger = logging.getLogger("medistock.audit")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = RotatingFileHandler(
                self.audit_log_path,
                maxBytes=config.LOG_MAX_BYTES,
                backupCount=config.LOG_BACKUP_COUNT,
                encoding="utf-8"
            )
            formatter = logging.Formatter(fmt="%(message)s")
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    def log_diagnostic(self, level: str, message: str, exc_info: bool = False) -> None:
        """Record diagnostic messages to app.log."""
        lvl = getattr(logging, level.upper(), logging.INFO)
        self.app_logger.log(lvl, message, exc_info=exc_info)

    def log_audit(
        self,
        operation: str,
        entity_type: str,
        entity_id: str,
        outcome: str,
        before_state: Optional[Dict[str, Any]] = None,
        after_state: Optional[Dict[str, Any]] = None,
        details: Optional[str] = None
    ) -> None:
        """Record an auditable mutation event with before/after state to audit.log."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": operation,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "outcome": outcome,
            "before_state": before_state or {},
            "after_state": after_state or {},
            "details": details or ""
        }
        self.audit_logger.info(json.dumps(entry))
        self.app_logger.info(f"AUDIT: [{operation}] {entity_type} {entity_id} -> {outcome}. {details or ''}")

    def get_app_logs(self, limit: int = 100, level_filter: Optional[str] = None, search: Optional[str] = None) -> List[str]:
        """Read and filter recent lines from app.log."""
        if not self.app_log_path.exists():
            return []
        try:
            with open(self.app_log_path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            
            results = []
            for line in reversed(lines):
                if level_filter and f"[{level_filter.upper()}]" not in line:
                    continue
                if search and search.lower() not in line.lower():
                    continue
                results.append(line.strip())
                if len(results) >= limit:
                    break
            return results
        except Exception as e:
            return [f"Failed to read application logs: {e}"]

    def get_audit_logs(self, limit: int = 100, search: Optional[str] = None) -> List[Dict[str, Any]]:
        """Read and parse recent entries from audit.log."""
        if not self.audit_log_path.exists():
            return []
        results = []
        try:
            with open(self.audit_log_path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            for line in reversed(lines):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if search:
                        s_lower = search.lower()
                        serialized = json.dumps(entry).lower()
                        if s_lower not in serialized:
                            continue
                    results.append(entry)
                    if len(results) >= limit:
                        break
                except json.JSONDecodeError:
                    continue
            return results
        except Exception:
            return []


# Global singleton instance
logger_service = LoggerService.get_instance()
