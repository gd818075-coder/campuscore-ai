"""Central business logic service for MediStock Analytics.

Coordinates inventory mutations, stock transactions, import validation,
and audit logging while ensuring transactional consistency.
"""

from datetime import datetime, date
import uuid
from typing import List, Dict, Any, Optional, Tuple

from app.config import config
from app.exceptions import (
    StockoutWarningException,
    CorruptedDataRecordException,
    InvalidQuantityException,
    DuplicateRecordException,
    UnknownItemException,
)
from app.models import (
    Item,
    Transaction,
    parse_and_validate_quantity,
    validate_iso_date,
    sanitize_csv_field
)
from app.repository.csv_repository import CSVRepository
from app.repository.backup_manager import BackupManager
from app.services.logger_service import logger_service


class InventoryService:
    def __init__(
        self,
        repository: Optional[CSVRepository] = None,
        backup_manager: Optional[BackupManager] = None
    ):
        self.repo = repository or CSVRepository()
        self.backup_manager = backup_manager or BackupManager(data_dir=self.repo.data_dir)

    # ==========================
    # INVENTORY QUERY & MUTATION
    # ==========================

    def get_all_items(self) -> List[Item]:
        """Fetch all inventory records."""
        return self.repo.load_inventory_items()

    def get_item_by_id(self, item_id: str) -> Item:
        """Find an item by unique item_id or raise UnknownItemException."""
        items = self.repo.load_inventory_items()
        for item in items:
            if item.item_id == item_id:
                return item
        raise UnknownItemException(f"Medical supply item '{item_id}' was not found in inventory.")

    def search_items(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        location: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Item]:
        """Search and filter inventory with multi-criteria conditions."""
        items = self.repo.load_inventory_items()
        results: List[Item] = []

        q_lower = query.strip().lower() if query else ""

        for it in items:
            # Query filter (matches ID or Name)
            if q_lower:
                if q_lower not in it.item_id.lower() and q_lower not in it.item_name.lower():
                    continue

            # Category filter
            if category and category.lower() != "all" and it.category.lower() != category.lower():
                continue

            # Location filter
            if location and location.lower() != "all" and it.location.lower() != location.lower():
                continue

            # Status filter
            if status and status.lower() != "all":
                st = it.get_stock_status().lower()
                target_st = status.lower()
                if target_st == "low stock" and st != "low stock":
                    continue
                elif target_st == "critical" and st != "critical":
                    continue
                elif target_st == "expired" and not it.is_expired():
                    continue
                elif target_st == "out of stock" and it.quantity > 0:
                    continue
                elif target_st == "normal" and st != "normal":
                    continue

            results.append(it)

        return results

    def add_item(self, item_data: Dict[str, Any]) -> Item:
        """Add a new medical supply record to inventory.

        Validates uniqueness, ISO dates, integer quantities, and sanitizes input.
        """
        new_item = Item.from_dict(item_data)
        with self.repo._lock:
            items = self.repo.load_inventory_items()

            # Check duplicate item_id
            for existing in items:
                if existing.item_id.lower() == new_item.item_id.lower():
                    raise DuplicateRecordException(
                        f"Item with ID '{new_item.item_id}' already exists in inventory."
                    )

            items.append(new_item)
            self.repo.save_inventory_items(items)

            logger_service.log_audit(
                operation="ADD_ITEM",
                entity_type="ITEM",
                entity_id=new_item.item_id,
                outcome="SUCCESS",
                after_state=new_item.to_dict(),
                details=f"Added medical supply '{new_item.item_name}'"
            )
            return new_item

    def update_item(self, item_id: str, updates: Dict[str, Any]) -> Item:
        """Update an existing medical supply item."""
        with self.repo._lock:
            items = self.repo.load_inventory_items()
            found_idx = -1
            for idx, it in enumerate(items):
                if it.item_id == item_id:
                    found_idx = idx
                    break

            if found_idx == -1:
                raise UnknownItemException(f"Cannot update: Item '{item_id}' does not exist.")

            current = items[found_idx]
            before_state = current.to_dict()

            # Merge updates
            merged_data = current.to_dict()
            merged_data.update(updates)
            merged_data["item_id"] = item_id  # Prevent ID tampering

            updated_item = Item.from_dict(merged_data)
            items[found_idx] = updated_item
            self.repo.save_inventory_items(items)

            logger_service.log_audit(
                operation="UPDATE_ITEM",
                entity_type="ITEM",
                entity_id=item_id,
                outcome="SUCCESS",
                before_state=before_state,
                after_state=updated_item.to_dict(),
                details=f"Updated properties for supply '{updated_item.item_name}'"
            )
            return updated_item

    def delete_item(self, item_id: str) -> None:
        """Remove an item from inventory."""
        with self.repo._lock:
            items = self.repo.load_inventory_items()
            found = None
            remaining = []
            for it in items:
                if it.item_id == item_id:
                    found = it
                else:
                    remaining.append(it)

            if not found:
                raise UnknownItemException(f"Cannot delete: Item '{item_id}' does not exist.")

            self.repo.save_inventory_items(remaining)
            logger_service.log_audit(
                operation="DELETE_ITEM",
                entity_type="ITEM",
                entity_id=item_id,
                outcome="SUCCESS",
                before_state=found.to_dict(),
                details=f"Deleted supply record '{found.item_name}'"
            )

    # ==========================
    # STOCK TRANSACTIONS
    # ==========================

    def receive_stock(
        self,
        item_id: str,
        quantity: int,
        transaction_date: Optional[str] = None,
        reference: str = "",
        remarks: str = ""
    ) -> Tuple[Item, Transaction]:
        """Receive incoming stock ('IN' transaction). Increases available physical quantity."""
        qty = parse_and_validate_quantity(quantity, field_name="quantity", allow_zero=False)
        tx_date = validate_iso_date(transaction_date or date.today().isoformat(), required=True)

        with self.repo._lock:
            items = self.repo.load_inventory_items()
            target_item = None
            for it in items:
                if it.item_id == item_id:
                    target_item = it
                    break

            if not target_item:
                raise UnknownItemException(f"Cannot receive stock: Unknown item ID '{item_id}'.")

            before_qty = target_item.quantity
            after_qty = before_qty + qty
            target_item.quantity = after_qty

            tx_id = f"TX-IN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:4].upper()}"
            tx = Transaction(
                transaction_id=tx_id,
                item_id=item_id,
                transaction_date=tx_date,
                transaction_type="IN",
                quantity=qty,
                reference=reference,
                remarks=remarks
            )

            # Commit multi-file transaction
            self.repo.commit_stock_mutation(items, tx)

            logger_service.log_audit(
                operation="RECEIVE_STOCK",
                entity_type="TRANSACTION",
                entity_id=tx.transaction_id,
                outcome="SUCCESS",
                before_state={"item_id": item_id, "quantity": before_qty},
                after_state={"item_id": item_id, "quantity": after_qty},
                details=f"Received +{qty} units for '{target_item.item_name}'. Ref: {reference}"
            )
            return target_item, tx

    def issue_stock(
        self,
        item_id: str,
        quantity: int,
        transaction_date: Optional[str] = None,
        reference: str = "",
        remarks: str = ""
    ) -> Tuple[Item, Transaction]:
        """Issue/consume stock ('OUT' transaction).

        Enforces usable stock availability.
        Raises StockoutWarningException if usable stock is insufficient.
        """
        qty = parse_and_validate_quantity(quantity, field_name="quantity", allow_zero=False)
        tx_date = validate_iso_date(transaction_date or date.today().isoformat(), required=True)

        with self.repo._lock:
            items = self.repo.load_inventory_items()
            target_item = None
            for it in items:
                if it.item_id == item_id:
                    target_item = it
                    break

            if not target_item:
                raise UnknownItemException(f"Cannot issue stock: Unknown item ID '{item_id}'.")

            # Expiry rule: expired supplies cannot be dispensed to patients
            usable_qty = target_item.get_usable_quantity()
            if target_item.is_expired():
                raise StockoutWarningException(
                    f"Cannot issue expired medical supply '{target_item.item_name}' (Expired on {target_item.expiry_date}). Usable stock is 0.",
                    details={"item_id": item_id, "expiry_date": target_item.expiry_date, "usable_stock": 0}
                )

            if qty > usable_qty:
                raise StockoutWarningException(
                    f"Insufficient usable stock for '{target_item.item_name}' ({item_id}). Requested {qty} units, but only {usable_qty} units available.",
                    details={"item_id": item_id, "requested": qty, "usable_stock": usable_qty}
                )

            before_qty = target_item.quantity
            after_qty = before_qty - qty
            target_item.quantity = after_qty

            tx_id = f"TX-OUT-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:4].upper()}"
            tx = Transaction(
                transaction_id=tx_id,
                item_id=item_id,
                transaction_date=tx_date,
                transaction_type="OUT",
                quantity=qty,
                reference=reference,
                remarks=remarks
            )

            # Commit multi-file mutation
            self.repo.commit_stock_mutation(items, tx)

            logger_service.log_audit(
                operation="ISSUE_STOCK",
                entity_type="TRANSACTION",
                entity_id=tx.transaction_id,
                outcome="SUCCESS",
                before_state={"item_id": item_id, "quantity": before_qty},
                after_state={"item_id": item_id, "quantity": after_qty},
                details=f"Issued -{qty} units for '{target_item.item_name}'. Ref: {reference}"
            )
            return target_item, tx

    def get_transactions(
        self,
        item_id: Optional[str] = None,
        transaction_type: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 200
    ) -> List[Transaction]:
        """Fetch transactions with multi-field filtering."""
        all_txs = self.repo.load_transactions()
        filtered = []

        for tx in reversed(all_txs):
            if item_id and tx.item_id.lower() != item_id.lower():
                continue
            if transaction_type and transaction_type.upper() != "ALL" and tx.transaction_type.upper() != transaction_type.upper():
                continue
            if start_date and tx.transaction_date < start_date:
                continue
            if end_date and tx.transaction_date > end_date:
                continue
            filtered.append(tx)
            if len(filtered) >= limit:
                break

        return filtered

    # ==========================
    # CSV IMPORT CENTER
    # ==========================

    def preview_import_csv(self, raw_csv_text: str, target_entity: str = "inventory") -> Dict[str, Any]:
        """Parse, validate, and report errors for an import batch without persisting changes.

        Returns preview statistics and detailed row-level error reports.
        """
        import csv
        import io

        lines = [line for line in raw_csv_text.strip().splitlines() if line.strip()]
        if not lines:
            raise CorruptedDataRecordException("The provided CSV content is empty.")

        f = io.StringIO("\n".join(lines))
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise CorruptedDataRecordException("CSV is missing header row.")

        fieldnames = [fn.strip() for fn in reader.fieldnames]

        valid_rows: List[Dict[str, Any]] = []
        invalid_rows: List[Dict[str, Any]] = []
        existing_items = {it.item_id.lower(): it for it in self.repo.load_inventory_items()}
        existing_tx_ids = {t.transaction_id.lower() for t in self.repo.load_transactions()}

        seen_batch_ids = set()

        if target_entity == "inventory":
            expected_headers = ["item_id", "item_name", "category", "unit", "quantity", "minimum_stock"]
            missing_h = [h for h in expected_headers if h not in fieldnames]
            if missing_h:
                raise CorruptedDataRecordException(f"Missing required inventory CSV headers: {missing_h}")

            for row_num, row in enumerate(reader, start=2):
                row_cleaned = {k.strip(): (v.strip() if v else "") for k, v in row.items() if k}
                item_id = row_cleaned.get("item_id", "")
                if not item_id:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": "Missing item_id"})
                    continue

                if item_id.lower() in seen_batch_ids:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": f"Duplicate item_id '{item_id}' in batch"})
                    continue
                seen_batch_ids.add(item_id.lower())

                try:
                    item_obj = Item.from_dict(row_cleaned)
                    is_existing = item_id.lower() in existing_items
                    valid_rows.append({
                        "row": row_num,
                        "data": item_obj.to_dict(),
                        "action": "UPDATE" if is_existing else "INSERT"
                    })
                except Exception as err:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": str(err)})

        elif target_entity == "consumption":
            expected_headers = ["transaction_id", "item_id", "transaction_date", "transaction_type", "quantity"]
            missing_h = [h for h in expected_headers if h not in fieldnames]
            if missing_h:
                raise CorruptedDataRecordException(f"Missing required consumption CSV headers: {missing_h}")

            for row_num, row in enumerate(reader, start=2):
                row_cleaned = {k.strip(): (v.strip() if v else "") for k, v in row.items() if k}
                tx_id = row_cleaned.get("transaction_id", "")
                if not tx_id:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": "Missing transaction_id"})
                    continue

                if tx_id.lower() in existing_tx_ids or tx_id.lower() in seen_batch_ids:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": f"Duplicate transaction_id '{tx_id}'"})
                    continue
                seen_batch_ids.add(tx_id.lower())

                item_id = row_cleaned.get("item_id", "")
                if item_id.lower() not in existing_items:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": f"Unknown referenced item_id '{item_id}'"})
                    continue

                try:
                    tx_obj = Transaction.from_dict(row_cleaned)
                    valid_rows.append({"row": row_num, "data": tx_obj.to_dict(), "action": "INSERT"})
                except Exception as err:
                    invalid_rows.append({"row": row_num, "data": row_cleaned, "reason": str(err)})

        return {
            "target_entity": target_entity,
            "total_rows": len(lines) - 1,
            "valid_count": len(valid_rows),
            "invalid_count": len(invalid_rows),
            "valid_rows": valid_rows[:50],  # sample for preview
            "invalid_rows": invalid_rows,
            "can_commit": len(valid_rows) > 0
        }

    def commit_import_csv(
        self,
        raw_csv_text: str,
        target_entity: str = "inventory",
        reject_mode: str = "reject_invalid"  # "reject_invalid" or "all_or_nothing"
    ) -> Dict[str, Any]:
        """Commit an import batch safely. Creates pre-import backup and persists validated records."""
        preview = self.preview_import_csv(raw_csv_text, target_entity)

        if preview["invalid_count"] > 0 and reject_mode == "all_or_nothing":
            raise CorruptedDataRecordException(
                f"Import rejected in all-or-nothing mode. {preview['invalid_count']} malformed/invalid rows detected."
            )

        if preview["valid_count"] == 0:
            raise CorruptedDataRecordException("No valid records to import.")

        # 1. Automated safety backup before bulk mutation
        backup_res = self.backup_manager.create_backup(label=f"pre_import_{target_entity}")

        committed_count = 0
        if target_entity == "inventory":
            current_items = {it.item_id.lower(): it for it in self.repo.load_inventory_items()}
            for valid_entry in preview["valid_rows"]:
                item_data = valid_entry["data"]
                item = Item.from_dict(item_data)
                current_items[item.item_id.lower()] = item
                committed_count += 1
            self.repo.save_inventory_items(list(current_items.values()))

        elif target_entity == "consumption":
            current_txs = self.repo.load_transactions()
            current_items = {it.item_id: it for it in self.repo.load_inventory_items()}

            for valid_entry in preview["valid_rows"]:
                tx_data = valid_entry["data"]
                tx = Transaction.from_dict(tx_data)
                current_txs.append(tx)
                # Adjust stock accordingly
                it = current_items.get(tx.item_id)
                if it:
                    if tx.transaction_type == "IN":
                        it.quantity += tx.quantity
                    elif tx.transaction_type == "OUT":
                        it.quantity = max(0, it.quantity - tx.quantity)
                committed_count += 1

            self.repo.save_inventory_items(list(current_items.values()))
            self.repo.save_transactions(current_txs)

        logger_service.log_audit(
            operation="IMPORT_CSV",
            entity_type=target_entity.upper(),
            entity_id=f"BATCH-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            outcome="SUCCESS",
            details=f"Committed {committed_count} rows. Backup: {backup_res['backup_id']}"
        )

        return {
            "committed_count": committed_count,
            "rejected_count": preview["invalid_count"],
            "rejected_rows": preview["invalid_rows"],
            "backup_id": backup_res["backup_id"]
        }


# Global singleton instance
inventory_service = InventoryService()
