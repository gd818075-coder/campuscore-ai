"""FastAPI REST routes for MediStock Analytics companion web interface."""

from fastapi import APIRouter, HTTPException, Query, Response, status
from fastapi.responses import PlainTextResponse
from typing import Optional, List, Dict, Any
from pathlib import Path
import io

from app.config import config
from app.exceptions import (
    MedicalInventoryError,
    StockoutWarningException,
    CorruptedDataRecordException,
    InvalidQuantityException,
    DuplicateRecordException,
    UnknownItemException,
    StorageOperationException,
    BackupOperationException,
)
from app.services.inventory_service import inventory_service
from app.services.logger_service import logger_service
from app.repository.backup_manager import BackupManager
from app.analytics.numpy_metrics import calculate_consumption_metrics, calculate_item_runway_metrics
from app.analytics.pandas_reports import pandas_reports
from app.api.schemas import (
    ItemCreateSchema,
    ItemUpdateSchema,
    ReceiveStockSchema,
    IssueStockSchema,
    ImportPreviewRequest,
    ImportCommitRequest,
    BackupCreateRequest,
    SettingsUpdateSchema
)

router = APIRouter(prefix="/api", tags=["MediStock Analytics"])
backup_mgr = BackupManager()


# ==========================
# SYSTEM & HEALTH
# ==========================

@router.get("/health")
def get_system_health():
    """Return real-time application health and storage diagnostics."""
    return {
        "status": "healthy",
        "app_name": config.APP_NAME,
        "version": config.VERSION,
        "course_code": config.COURSE_CODE,
        "storage": {
            "inventory_file_exists": config.INVENTORY_CSV.exists(),
            "consumption_file_exists": config.CONSUMPTION_CSV.exists(),
            "inventory_size_bytes": config.INVENTORY_CSV.stat().st_size if config.INVENTORY_CSV.exists() else 0,
            "consumption_size_bytes": config.CONSUMPTION_CSV.stat().st_size if config.CONSUMPTION_CSV.exists() else 0,
            "journal_pending": config.JOURNAL_FILE.exists()
        }
    }


@router.get("/dashboard")
def get_dashboard_summary():
    """Aggregate live metrics, KPIs, and critical alerts for the web dashboard."""
    try:
        items = inventory_service.get_all_items()
        total_items = len(items)
        usable_units = sum(it.usable_quantity for it in items)
        physical_units = sum(it.quantity for it in items)
        low_stock_items = sum(1 for it in items if it.quantity <= it.minimum_stock and not it.is_expired())
        expired_items = sum(1 for it in items if it.is_expired())
        critical_items = sum(1 for it in items if it.minimum_stock > 0 and it.quantity <= int(it.minimum_stock * config.CRITICAL_STOCK_RATIO) and not it.is_expired())

        # Category aggregation via Pandas
        cat_df = pandas_reports.generate_category_summary()
        categories = cat_df.to_dict(orient="records")

        # Critical shortages list
        crit_df = pandas_reports.generate_critical_stock_report()
        critical_shortages = crit_df.to_dict(orient="records")

        # Recent transactions
        recent_txs = [t.to_dict() for t in inventory_service.get_transactions(limit=10)]

        return {
            "kpis": {
                "total_items": total_items,
                "usable_units": usable_units,
                "physical_units": physical_units,
                "low_stock_count": low_stock_items,
                "critical_count": critical_items,
                "expired_count": expired_items
            },
            "category_summary": categories,
            "critical_shortages": critical_shortages[:10],
            "recent_transactions": recent_txs
        }
    except Exception as e:
        logger_service.log_diagnostic("ERROR", f"Dashboard API failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==========================
# INVENTORY ENDPOINTS
# ==========================

@router.get("/inventory")
def list_inventory(
    query: Optional[str] = None,
    category: Optional[str] = None,
    status: Optional[str] = None
):
    """Retrieve catalog supplies with optional search and category filters."""
    try:
        items = inventory_service.search_items(query=query, category=category, status=status)
        return [it.to_dict() for it in items]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/inventory/{item_id}")
def get_inventory_item(item_id: str):
    """Fetch details for a single supply item."""
    try:
        item = inventory_service.get_item_by_id(item_id)
        return item.to_dict()
    except UnknownItemException as uie:
        raise HTTPException(status_code=404, detail=str(uie))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/inventory", status_code=status.HTTP_201_CREATED)
def add_inventory_item(item_in: ItemCreateSchema):
    """Add a new medical supply record to inventory."""
    try:
        created = inventory_service.add_item(item_in.model_dump())
        return created.to_dict()
    except DuplicateRecordException as dre:
        raise HTTPException(status_code=409, detail=str(dre))
    except (InvalidQuantityException, CorruptedDataRecordException) as err:
        raise HTTPException(status_code=400, detail=str(err))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/inventory/{item_id}")
def update_inventory_item(item_id: str, updates: ItemUpdateSchema):
    """Update attributes of an existing supply item."""
    try:
        clean_updates = {k: v for k, v in updates.model_dump().items() if v is not None}
        updated = inventory_service.update_item(item_id, clean_updates)
        return updated.to_dict()
    except UnknownItemException as uie:
        raise HTTPException(status_code=404, detail=str(uie))
    except (InvalidQuantityException, CorruptedDataRecordException) as err:
        raise HTTPException(status_code=400, detail=str(err))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/inventory/{item_id}")
def delete_inventory_item(item_id: str):
    """Delete a medical supply item from inventory."""
    try:
        inventory_service.delete_item(item_id)
        return {"status": "success", "message": f"Item {item_id} deleted."}
    except UnknownItemException as uie:
        raise HTTPException(status_code=404, detail=str(uie))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==========================
# TRANSACTION ENDPOINTS
# ==========================

@router.post("/transactions/receive", status_code=status.HTTP_201_CREATED)
def receive_stock(payload: ReceiveStockSchema):
    """Record receipt of incoming stock (Stock IN)."""
    try:
        item, tx = inventory_service.receive_stock(
            item_id=payload.item_id,
            quantity=payload.quantity,
            transaction_date=payload.transaction_date,
            reference=payload.reference or "",
            remarks=payload.remarks or ""
        )
        return {
            "transaction": tx.to_dict(),
            "item": item.to_dict()
        }
    except UnknownItemException as uie:
        raise HTTPException(status_code=404, detail=str(uie))
    except InvalidQuantityException as iqe:
        raise HTTPException(status_code=400, detail=str(iqe))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/transactions/issue", status_code=status.HTTP_201_CREATED)
def issue_stock(payload: IssueStockSchema):
    """Dispense stock to a clinic or patient (Stock OUT). Rejects stockouts."""
    try:
        item, tx = inventory_service.issue_stock(
            item_id=payload.item_id,
            quantity=payload.quantity,
            transaction_date=payload.transaction_date,
            reference=payload.reference or "",
            remarks=payload.remarks or ""
        )
        return {
            "transaction": tx.to_dict(),
            "item": item.to_dict()
        }
    except StockoutWarningException as swe:
        # 409 Conflict represents shortage/stockout condition
        raise HTTPException(status_code=409, detail=swe.to_dict())
    except UnknownItemException as uie:
        raise HTTPException(status_code=404, detail=str(uie))
    except InvalidQuantityException as iqe:
        raise HTTPException(status_code=400, detail=str(iqe))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/transactions")
def get_transactions(
    item_id: Optional[str] = None,
    transaction_type: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000)
):
    """Fetch transaction audit trail records with optional filters."""
    txs = inventory_service.get_transactions(item_id=item_id, transaction_type=transaction_type, limit=limit)
    return [t.to_dict() for t in txs]


# ==========================
# IMPORT CENTER ENDPOINTS
# ==========================

@router.post("/imports/preview")
def preview_import_csv(payload: ImportPreviewRequest):
    """Parse and validate CSV records without writing changes."""
    try:
        preview = inventory_service.preview_import_csv(payload.raw_csv, target_entity=payload.target_entity)
        return preview
    except CorruptedDataRecordException as cde:
        raise HTTPException(status_code=400, detail=str(cde))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/imports/commit")
def commit_import_csv(payload: ImportCommitRequest):
    """Safely commit an import batch with automatic pre-import safety backup."""
    try:
        res = inventory_service.commit_import_csv(
            payload.raw_csv,
            target_entity=payload.target_entity,
            reject_mode=payload.reject_mode
        )
        return res
    except CorruptedDataRecordException as cde:
        raise HTTPException(status_code=400, detail=str(cde))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==========================
# REPORTS & ANALYTICS
# ==========================

@router.get("/reports/low-stock")
def get_low_stock_report():
    """Pandas low-stock report (quantity <= minimum_stock)."""
    df = pandas_reports.generate_low_stock_report()
    return df.to_dict(orient="records")


@router.get("/reports/critical-stock")
def get_critical_stock_report():
    """Pandas critical shortage report (quantity <= 50% minimum_stock)."""
    df = pandas_reports.generate_critical_stock_report()
    return df.to_dict(orient="records")


@router.get("/reports/expiry")
def get_expiry_report(near_expiry_days: int = 45):
    """Pandas report for expired and near-expiry supplies."""
    df = pandas_reports.generate_expiry_report(near_expiry_days=near_expiry_days)
    return df.to_dict(orient="records")


@router.get("/reports/analytics")
def get_numerical_analytics(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """NumPy-driven continuous daily consumption metrics and item runway calculations."""
    items = inventory_service.get_all_items()
    txs = inventory_service.get_transactions(limit=2000)

    aggregate_metrics = calculate_consumption_metrics(txs, start_date=start_date, end_date=end_date)
    runway_items = calculate_item_runway_metrics(items, txs, lookback_days=30)

    return {
        "aggregate": aggregate_metrics,
        "runway": runway_items
    }


@router.get("/reports/export/{report_type}")
def export_report_csv(report_type: str):
    """Generate and download a CSV export of any report."""
    if report_type == "low-stock":
        df = pandas_reports.generate_low_stock_report()
    elif report_type == "critical":
        df = pandas_reports.generate_critical_stock_report()
    elif report_type == "expiry":
        df = pandas_reports.generate_expiry_report()
    elif report_type == "category":
        df = pandas_reports.generate_category_summary()
    elif report_type == "item-consumption":
        df = pandas_reports.generate_item_consumption_report()
    else:
        df = pandas_reports.get_inventory_df()

    buffer = io.StringIO()
    df.to_csv(buffer, index=False, encoding="utf-8")
    csv_bytes = buffer.getvalue()

    return Response(
        content=csv_bytes,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=medistock_{report_type}_report.csv"}
    )


# ==========================
# BACKUPS & RECOVERY
# ==========================

@router.get("/backups")
def list_backups():
    """List all available backup archives with metadata."""
    return backup_mgr.list_backups()


@router.post("/backups")
def create_backup(payload: Optional[BackupCreateRequest] = None):
    """Create a timestamped zip backup archive."""
    label = payload.label if payload and payload.label else "manual"
    try:
        res = backup_mgr.create_backup(label=label)
        return res
    except BackupOperationException as boe:
        raise HTTPException(status_code=500, detail=str(boe))


@router.post("/backups/{backup_id}/restore")
def restore_backup(backup_id: str):
    """Safely restore system state from a verified backup archive."""
    try:
        backup_mgr.restore_backup(backup_id)
        return {"status": "success", "message": f"Successfully restored from {backup_id}"}
    except BackupOperationException as boe:
        raise HTTPException(status_code=500, detail=str(boe))


# ==========================
# LOGS
# ==========================

@router.get("/logs")
def get_logs(
    log_type: str = Query("diagnostic", description="'diagnostic' or 'audit'"),
    level: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 150
):
    """Retrieve filtered lines from internal diagnostic logs or structured audit trail."""
    if log_type == "audit":
        return logger_service.get_audit_logs(limit=limit, search=search)
    else:
        lvl_filter = None if not level or level.upper() == "ALL" else level
        return logger_service.get_app_logs(limit=limit, level_filter=lvl_filter, search=search)


# ==========================
# SETTINGS & ABOUT
# ==========================

@router.get("/settings")
def get_settings():
    return {
        "critical_stock_ratio": config.CRITICAL_STOCK_RATIO,
        "backup_retention_count": config.BACKUP_RETENTION_COUNT,
        "exclude_expired_from_usable": config.EXCLUDE_EXPIRED_FROM_USABLE,
        "paths": {
            "base_dir": str(config.BASE_DIR),
            "data_dir": str(config.DATA_DIR),
            "backup_dir": str(config.BACKUP_DIR),
            "logs_dir": str(config.LOG_DIR)
        }
    }


@router.put("/settings")
def update_settings(payload: SettingsUpdateSchema):
    if payload.critical_stock_ratio is not None:
        config.CRITICAL_STOCK_RATIO = payload.critical_stock_ratio
    if payload.backup_retention_count is not None:
        config.BACKUP_RETENTION_COUNT = payload.backup_retention_count
    if payload.exclude_expired_from_usable is not None:
        config.EXCLUDE_EXPIRED_FROM_USABLE = payload.exclude_expired_from_usable
    return get_settings()


@router.get("/about")
def get_academic_info():
    return {
        "app_name": config.APP_NAME,
        "version": config.VERSION,
        "course_name": config.COURSE_NAME,
        "course_code": config.COURSE_CODE,
        "assignment": "Assignment 2 (Units 4, 5, 6)",
        "program": "BCA (BCA-IT, UG), SCA, FCIT",
        "assessment_marks": 40,
        "submission_deadline": config.SUBMISSION_DEADLINE,
        "student_name": "[STUDENT NAME PLACEHOLDER]",
        "student_usn": "[STUDENT USN PLACEHOLDER]",
        "course_outcomes": {
            "CO4": "Advanced File Handling, Exceptions, Logging & WAL Crash Recovery",
            "CO5": "Tkinter Desktop GUI, NumPy Numerical Computing & Pandas DataFrames",
            "CO6": "Multi-Tier Software Architecture, Testing & Dual-Interface Engineering"
        }
    }
