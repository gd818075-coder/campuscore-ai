"""Pydantic schemas for FastAPI request and response validation in MediStock Analytics."""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class ItemCreateSchema(BaseModel):
    item_id: str = Field(..., min_length=1, description="Unique medical supply identifier")
    item_name: str = Field(..., min_length=1, description="Clinical or trade name of the supply")
    category: str = Field(..., min_length=1, description="Supply category (e.g. PPE, Wound Care)")
    unit: str = Field(..., min_length=1, description="Unit of measure (e.g. Box, Bottle, Pack)")
    quantity: int = Field(..., ge=0, description="Current physical quantity")
    minimum_stock: int = Field(..., ge=0, description="Minimum reorder threshold")
    expiry_date: Optional[str] = Field("", description="Expiration date in ISO YYYY-MM-DD")
    location: Optional[str] = Field("Main Pharmacy", description="Physical storage shelf/room")


class ItemUpdateSchema(BaseModel):
    item_name: Optional[str] = None
    category: Optional[str] = None
    unit: Optional[str] = None
    quantity: Optional[int] = Field(None, ge=0)
    minimum_stock: Optional[int] = Field(None, ge=0)
    expiry_date: Optional[str] = None
    location: Optional[str] = None


class ReceiveStockSchema(BaseModel):
    item_id: str = Field(..., min_length=1)
    quantity: int = Field(..., gt=0, description="Units to receive (must be > 0)")
    transaction_date: Optional[str] = Field(None, description="ISO YYYY-MM-DD date")
    reference: Optional[str] = Field("", description="Purchase Order or delivery voucher number")
    remarks: Optional[str] = Field("", description="Receiving department or vendor remarks")


class IssueStockSchema(BaseModel):
    item_id: str = Field(..., min_length=1)
    quantity: int = Field(..., gt=0, description="Units to dispense (must be > 0)")
    transaction_date: Optional[str] = Field(None, description="ISO YYYY-MM-DD date")
    reference: Optional[str] = Field("", description="Clinical ward or patient requisition number")
    remarks: Optional[str] = Field("", description="Clinical reason or destination ward")


class ImportPreviewRequest(BaseModel):
    raw_csv: str = Field(..., min_length=1, description="Raw CSV content string")
    target_entity: str = Field("inventory", description="'inventory' or 'consumption'")


class ImportCommitRequest(BaseModel):
    raw_csv: str = Field(..., min_length=1)
    target_entity: str = Field("inventory", description="'inventory' or 'consumption'")
    reject_mode: str = Field("reject_invalid", description="'reject_invalid' or 'all_or_nothing'")


class BackupCreateRequest(BaseModel):
    label: Optional[str] = Field("manual", description="Descriptive label for the backup snapshot")


class SettingsUpdateSchema(BaseModel):
    critical_stock_ratio: Optional[float] = Field(None, gt=0, le=1.0)
    backup_retention_count: Optional[int] = Field(None, ge=1)
    exclude_expired_from_usable: Optional[bool] = None
