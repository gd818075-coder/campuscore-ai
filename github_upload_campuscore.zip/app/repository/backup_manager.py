"""Backup and Disaster Recovery Manager for MediStock Analytics.

Implements timestamped snapshots, structural validation, automated retention rotation,
and safe restoration with pre-restore state verification.
"""

import os
import zipfile
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

from app.config import config
from app.exceptions import BackupOperationException
from app.services.logger_service import logger_service


class BackupManager:
    def __init__(
        self,
        backup_dir: Optional[Path] = None,
        data_dir: Optional[Path] = None,
        retention_count: int = 15
    ):
        self.backup_dir = backup_dir or config.BACKUP_DIR
        self.data_dir = data_dir or config.DATA_DIR
        self.retention_count = retention_count
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def create_backup(self, label: str = "manual") -> Dict[str, Any]:
        """Create a timestamped zip archive of inventory.csv and consumption.csv.

        Strictly implements try / except / else / finally.
        """
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"backup_{label}_{timestamp_str}.zip"
        backup_path = self.backup_dir / backup_filename

        inv_path = self.data_dir / "inventory.csv"
        con_path = self.data_dir / "consumption.csv"

        temp_zip_path = None
        try:
            # Build manifest
            manifest = {
                "created_at": datetime.now().isoformat(),
                "label": label,
                "app_version": config.VERSION,
                "included_files": []
            }

            temp_zip_path = self.backup_dir / f".tmp_{backup_filename}"
            with zipfile.ZipFile(temp_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                if inv_path.exists():
                    zf.write(inv_path, arcname="inventory.csv")
                    manifest["included_files"].append("inventory.csv")
                if con_path.exists():
                    zf.write(con_path, arcname="consumption.csv")
                    manifest["included_files"].append("consumption.csv")
                
                # Write manifest inside zip
                zf.writestr("manifest.json", json.dumps(manifest, indent=2))

            # Atomic swap of backup archive
            os.replace(temp_zip_path, backup_path)
            temp_zip_path = None

            # Validate the newly created archive immediately
            self.validate_backup(backup_path)

        except Exception as e:
            logger_service.log_diagnostic("ERROR", f"Failed to create backup: {e}", exc_info=True)
            raise BackupOperationException(f"Backup creation failed: {e}") from e
        else:
            # else executes on clean success
            logger_service.log_audit(
                operation="CREATE_BACKUP",
                entity_type="BACKUP",
                entity_id=backup_filename,
                outcome="SUCCESS",
                details=f"Backup archive created at {backup_path.name}"
            )
            self._prune_old_backups()
            return {
                "backup_id": backup_filename,
                "path": str(backup_path),
                "timestamp": timestamp_str,
                "size_bytes": backup_path.stat().st_size
            }
        finally:
            if temp_zip_path and temp_zip_path.exists():
                try:
                    temp_zip_path.unlink()
                except OSError:
                    pass

    def validate_backup(self, backup_file: Path) -> Dict[str, Any]:
        """Verify readability and file integrity of a backup zip."""
        if not backup_file.exists():
            raise BackupOperationException(f"Backup file not found: {backup_file.name}")

        try:
            with zipfile.ZipFile(backup_file, "r") as zf:
                # Test CRC checksums
                bad_file = zf.testzip()
                if bad_file:
                    raise BackupOperationException(f"Corrupted file '{bad_file}' detected in backup archive.")

                names = zf.namelist()
                has_inv = "inventory.csv" in names
                has_manifest = "manifest.json" in names

                if not has_inv:
                    raise BackupOperationException("Backup archive is missing core inventory.csv.")

                manifest = {}
                if has_manifest:
                    manifest_data = zf.read("manifest.json").decode("utf-8")
                    manifest = json.loads(manifest_data)

                return {
                    "valid": True,
                    "filename": backup_file.name,
                    "files": names,
                    "manifest": manifest
                }
        except zipfile.BadZipFile as bz:
            raise BackupOperationException(f"Invalid or corrupted zip archive: {bz}") from bz
        except Exception as e:
            raise BackupOperationException(f"Backup validation failed: {e}") from e

    def list_backups(self) -> List[Dict[str, Any]]:
        """List all available backup archives with metadata."""
        if not self.backup_dir.exists():
            return []

        backups = []
        for file in sorted(self.backup_dir.glob("backup_*.zip"), reverse=True):
            stat = file.stat()
            backups.append({
                "backup_id": file.name,
                "filename": file.name,
                "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "size_bytes": stat.st_size,
                "size_display": f"{stat.st_size / 1024:.1f} KB"
            })
        return backups

    def restore_backup(self, backup_filename: str) -> None:
        """Safely restore inventory and consumption data from a verified backup archive.

        Strictly implements try / except / else / finally.
        """
        backup_path = self.backup_dir / backup_filename
        if not backup_path.exists():
            raise BackupOperationException(f"Selected backup archive does not exist: {backup_filename}")

        # 1. First validate archive
        self.validate_backup(backup_path)

        # 2. Create safety snapshot of current data before overwriting
        try:
            pre_restore_snapshot = self.create_backup(label="pre_restore_safety")
        except Exception as err:
            logger_service.log_diagnostic("WARNING", f"Safety snapshot before restore failed: {err}")

        # 3. Perform restoration
        try:
            with zipfile.ZipFile(backup_path, "r") as zf:
                if "inventory.csv" in zf.namelist():
                    zf.extract("inventory.csv", path=self.data_dir)
                if "consumption.csv" in zf.namelist():
                    zf.extract("consumption.csv", path=self.data_dir)
        except Exception as e:
            logger_service.log_diagnostic("ERROR", f"Failed restoring backup {backup_filename}: {e}", exc_info=True)
            raise BackupOperationException(f"Restoration from {backup_filename} failed: {e}") from e
        else:
            logger_service.log_audit(
                operation="RESTORE_BACKUP",
                entity_type="BACKUP",
                entity_id=backup_filename,
                outcome="SUCCESS",
                details=f"System data successfully restored from archive {backup_filename}"
            )

    def _prune_old_backups(self) -> None:
        """Retain only the most recent N backups, safely pruning older snapshots."""
        try:
            all_backups = sorted(
                self.backup_dir.glob("backup_*.zip"),
                key=lambda p: p.stat().st_mtime,
                reverse=True
            )
            if len(all_backups) > self.retention_count:
                for old_file in all_backups[self.retention_count:]:
                    try:
                        old_file.unlink()
                        logger_service.log_diagnostic("INFO", f"Pruned aged backup archive: {old_file.name}")
                    except OSError:
                        pass
        except Exception as e:
            logger_service.log_diagnostic("WARNING", f"Backup pruning encountered non-fatal error: {e}")
