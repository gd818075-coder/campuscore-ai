"""Repository package initialization."""
# Keep package init clean to avoid circular dependencies
