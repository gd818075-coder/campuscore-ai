"""Safe, atomic, and crash-resilient CSV Repository for MediStock Analytics.

Implements:
1. Thread-safe file operations with reentrant locking.
2. Atomic replacement of individual CSV files via os.replace and os.fsync.
3. Write-Ahead Journaling (WAL) for multi-file transaction consistency.
4. Header and schema validation with custom domain exceptions.
"""

import os
import csv
import json
import tempfile
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional

from app.config import config
from app.exceptions import (
    CorruptedDataRecordException,
    StorageOperationException,
)
from app.models import Item, Transaction
from app.services.logger_service import logger_service


INVENTORY_HEADERS = [
    "item_id",
    "item_name",
    "category",
    "unit",
    "quantity",
    "minimum_stock",
    "expiry_date",
    "location",
]

CONSUMPTION_HEADERS = [
    "transaction_id",
    "item_id",
    "transaction_date",
    "transaction_type",
    "quantity",
    "reference",
    "remarks",
]


class CSVRepository:
    def __init__(
        self,
        data_dir: Optional[Path] = None,
        inventory_file: Optional[Path] = None,
        consumption_file: Optional[Path] = None,
        journal_file: Optional[Path] = None,
    ):
        self.data_dir = data_dir or config.DATA_DIR
        self.inventory_file = inventory_file or config.INVENTORY_CSV
        self.consumption_file = consumption_file or config.CONSUMPTION_CSV
        self.journal_file = journal_file or config.JOURNAL_FILE

        self._lock = threading.RLock()
        self.init_storage()

    def init_storage(self) -> None:
        """Ensure directories exist, initialize headers if missing, and recover pending transactions."""
        with self._lock:
            try:
                self.data_dir.mkdir(parents=True, exist_ok=True)
                self._recover_journal_if_needed()

                if not self.inventory_file.exists():
                    self._create_empty_csv(self.inventory_file, INVENTORY_HEADERS)
                if not self.consumption_file.exists():
                    self._create_empty_csv(self.consumption_file, CONSUMPTION_HEADERS)
            except Exception as e:
                logger_service.log_diagnostic("ERROR", f"Storage initialization failed: {e}", exc_info=True)
                raise StorageOperationException(f"Failed to initialize CSV storage in {self.data_dir}: {e}") from e

    def _create_empty_csv(self, file_path: Path, headers: List[str]) -> None:
        """Create an empty CSV with proper headers using atomic write."""
        self._atomic_write_csv(file_path, headers, [])

    def _recover_journal_if_needed(self) -> None:
        """Crash-recovery algorithm: rollback or cleanup incomplete transactions from journal."""
        if not self.journal_file.exists():
            return

        logger_service.log_diagnostic("WARNING", f"Found pending transaction journal at {self.journal_file}. Initiating recovery.")
        try:
            with open(self.journal_file, "r", encoding="utf-8") as f:
                journal_data = json.load(f)

            staged_files = journal_data.get("staged_files", [])
            for staged_path_str in staged_files:
                staged_path = Path(staged_path_str)
                if staged_path.exists():
                    try:
                        staged_path.unlink()
                        logger_service.log_diagnostic("INFO", f"Cleaned uncommitted staged file: {staged_path}")
                    except OSError as err:
                        logger_service.log_diagnostic("WARNING", f"Could not remove staged file {staged_path}: {err}")

            self.journal_file.unlink(missing_ok=True)
            logger_service.log_diagnostic("INFO", "Transaction recovery complete. Journal cleared.")
        except Exception as e:
            logger_service.log_diagnostic("ERROR", f"Journal recovery encountered an error: {e}", exc_info=True)

    def _atomic_write_csv(self, target_file: Path, headers: List[str], rows: List[Dict[str, Any]]) -> None:
        """Atomically write CSV rows to target_file using temporary file and os.replace."""
        temp_file = None
        try:
            target_dir = target_file.parent
            target_dir.mkdir(parents=True, exist_ok=True)

            # Create temp file in same directory to ensure atomic os.replace across filesystem boundaries
            fd, temp_path_str = tempfile.mkstemp(
                dir=target_dir,
                prefix=f".tmp_{target_file.stem}_",
                suffix=".csv"
            )
            temp_file = Path(temp_path_str)

            with os.fdopen(fd, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
                writer.writeheader()
                for row in rows:
                    writer.writerow(row)
                f.flush()
                os.fsync(f.fileno())

            # Atomic swap
            os.replace(temp_file, target_file)
            temp_file = None  # Successfully replaced
        except OSError as e:
            raise StorageOperationException(f"Atomic file write failed for {target_file.name}: {e}") from e
        finally:
            if temp_file and temp_file.exists():
                try:
                    temp_file.unlink(missing_ok=True)
                except OSError:
                    pass

    # ==========================
    # INVENTORY OPERATIONS
    # ==========================

    def load_inventory_items(self) -> List[Item]:
        """Read and validate all items from inventory.csv."""
        with self._lock:
            if not self.inventory_file.exists():
                return []

            items: List[Item] = []
            try:
                with open(self.inventory_file, "r", newline="", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    if reader.fieldnames is None:
                        return []
                    
                    # Validate header presence
                    missing = set(INVENTORY_HEADERS) - set(reader.fieldnames)
                    if missing:
                        raise CorruptedDataRecordException(
                            f"inventory.csv is missing required headers: {list(missing)}"
                        )

                    for row_idx, row in enumerate(reader, start=2):
                        try:
                            item = Item.from_dict(row)
                            items.append(item)
                        except Exception as e:
                            raise CorruptedDataRecordException(
                                f"Malformed inventory record at line {row_idx}: {e}"
                            ) from e
                return items
            except UnicodeDecodeError as ude:
                raise CorruptedDataRecordException(f"inventory.csv encoding error: {ude}") from ude
            except OSError as ose:
                raise StorageOperationException(f"Failed to read {self.inventory_file}: {ose}") from ose

    def save_inventory_items(self, items: List[Item]) -> None:
        """Atomically persist a complete list of items to inventory.csv."""
        with self._lock:
            rows = [item.to_csv_dict() for item in items]
            self._atomic_write_csv(self.inventory_file, INVENTORY_HEADERS, rows)

    # ==========================
    # TRANSACTION OPERATIONS
    # ==========================

    def load_transactions(self) -> List[Transaction]:
        """Read and validate all transaction records from consumption.csv."""
        with self._lock:
            if not self.consumption_file.exists():
                return []

            txs: List[Transaction] = []
            try:
                with open(self.consumption_file, "r", newline="", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    if reader.fieldnames is None:
                        return []

                    missing = set(CONSUMPTION_HEADERS) - set(reader.fieldnames)
                    if missing:
                        raise CorruptedDataRecordException(
                            f"consumption.csv is missing required headers: {list(missing)}"
                        )

                    for row_idx, row in enumerate(reader, start=2):
                        try:
                            tx = Transaction.from_dict(row)
                            txs.append(tx)
                        except Exception as e:
                            raise CorruptedDataRecordException(
                                f"Malformed transaction record at line {row_idx}: {e}"
                            ) from e
                return txs
            except UnicodeDecodeError as ude:
                raise CorruptedDataRecordException(f"consumption.csv encoding error: {ude}") from ude
            except OSError as ose:
                raise StorageOperationException(f"Failed to read {self.consumption_file}: {ose}") from ose

    def save_transactions(self, transactions: List[Transaction]) -> None:
        """Atomically persist all transactions to consumption.csv."""
        with self._lock:
            rows = [tx.to_csv_dict() for tx in transactions]
            self._atomic_write_csv(self.consumption_file, CONSUMPTION_HEADERS, rows)

    # ===============================================
    # MULTI-FILE TRANSACTION (INVENTORY + CONSUMPTION)
    # ===============================================

    def commit_stock_mutation(
        self,
        updated_items: List[Item],
        new_transaction: Transaction
    ) -> None:
        """Atomically commit an inventory change and a transaction record together using WAL journaling.

        Strictly implements try / except / else / finally.
        """
        staged_inv_file = None
        staged_con_file = None

        with self._lock:
            try:
                # 1. Load current transactions and append new transaction
                current_txs = self.load_transactions()
                current_txs.append(new_transaction)

                # 2. Prepare staged temporary files for both targets
                fd_inv, inv_tmp_path = tempfile.mkstemp(
                    dir=self.data_dir, prefix=".staged_inv_", suffix=".csv"
                )
                staged_inv_file = Path(inv_tmp_path)
                with os.fdopen(fd_inv, "w", newline="", encoding="utf-8") as f_inv:
                    w_inv = csv.DictWriter(f_inv, fieldnames=INVENTORY_HEADERS)
                    w_inv.writeheader()
                    for item in updated_items:
                        w_inv.writerow(item.to_csv_dict())
                    f_inv.flush()
                    os.fsync(f_inv.fileno())

                fd_con, con_tmp_path = tempfile.mkstemp(
                    dir=self.data_dir, prefix=".staged_con_", suffix=".csv"
                )
                staged_con_file = Path(con_tmp_path)
                with os.fdopen(fd_con, "w", newline="", encoding="utf-8") as f_con:
                    w_con = csv.DictWriter(f_con, fieldnames=CONSUMPTION_HEADERS)
                    w_con.writeheader()
                    for tx in current_txs:
                        w_con.writerow(tx.to_csv_dict())
                    f_con.flush()
                    os.fsync(f_con.fileno())

                # 3. Write journal record (WAL)
                journal_data = {
                    "status": "PREPARED",
                    "transaction_id": new_transaction.transaction_id,
                    "staged_files": [str(staged_inv_file), str(staged_con_file)]
                }
                with open(self.journal_file, "w", encoding="utf-8") as jf:
                    json.dump(journal_data, jf)
                    jf.flush()
                    os.fsync(jf.fileno())

                # 4. Atomic replaces
                os.replace(staged_inv_file, self.inventory_file)
                staged_inv_file = None

                os.replace(staged_con_file, self.consumption_file)
                staged_con_file = None

            except Exception as e:
                logger_service.log_diagnostic(
                    "ERROR",
                    f"Stock mutation transaction failed for tx={new_transaction.transaction_id}: {e}",
                    exc_info=True
                )
                raise StorageOperationException(f"Failed to commit stock transaction: {e}") from e
            else:
                # else block executes ONLY when try completes without exception
                logger_service.log_diagnostic(
                    "INFO",
                    f"Stock mutation committed successfully for tx={new_transaction.transaction_id}"
                )
            finally:
                # Cleanup WAL journal and any lingering staged temp files
                if self.journal_file.exists():
                    try:
                        self.journal_file.unlink(missing_ok=True)
                    except OSError:
                        pass
                if staged_inv_file and staged_inv_file.exists():
                    try:
                        staged_inv_file.unlink(missing_ok=True)
                    except OSError:
                        pass
                if staged_con_file and staged_con_file.exists():
                    try:
                        staged_con_file.unlink(missing_ok=True)
                    except OSError:
                        pass
