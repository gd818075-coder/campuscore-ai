"""Data models and input validation routines for MediStock Analytics.

Enforces schema constraints, ISO dates, integer quantities, and CSV injection protection.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, date
import re
from typing import Optional, Dict, Any, Tuple
import math

from app.exceptions import (
    CorruptedDataRecordException,
    InvalidQuantityException,
)


def sanitize_csv_field(val: Any) -> str:
    """Protect against CSV / Formula Injection in spreadsheet software."""
    if val is None:
        return ""
    text = str(val).strip()
    if text and text[0] in ("=", "+", "-", "@", "\t", "\r"):
        return f"'{text}"
    return text


def parse_and_validate_quantity(value: Any, field_name: str = "quantity", allow_zero: bool = True) -> int:
    """Validate quantity value.

    Rejects negative, fractional, NaN, inf, empty, and non-numeric representations.
    Raises InvalidQuantityException if invalid.
    """
    if value is None:
        raise InvalidQuantityException(f"{field_name} cannot be null or empty.")

    if isinstance(value, bool):
        raise InvalidQuantityException(f"{field_name} cannot be a boolean value.")

    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise InvalidQuantityException(f"{field_name} cannot be NaN or infinite.")
        if not value.is_integer():
            raise InvalidQuantityException(f"{field_name} must be a whole integer, received fractional float: {value}")
        int_val = int(value)
    elif isinstance(value, int):
        int_val = value
    elif isinstance(value, str):
        val_str = value.strip()
        if not val_str:
            raise InvalidQuantityException(f"{field_name} cannot be an empty string.")
        try:
            # Check for fractional string (e.g., '12.5')
            if "." in val_str:
                f_val = float(val_str)
                if not f_val.is_integer():
                    raise InvalidQuantityException(f"{field_name} cannot be fractional: '{val_str}'")
                int_val = int(f_val)
            else:
                int_val = int(val_str)
        except ValueError as err:
            raise InvalidQuantityException(f"{field_name} must be a valid integer string: '{val_str}'") from err
    else:
        raise InvalidQuantityException(f"{field_name} has invalid type: {type(value).__name__}")

    if allow_zero:
        if int_val < 0:
            raise InvalidQuantityException(f"{field_name} cannot be negative (received {int_val}).")
    else:
        if int_val <= 0:
            raise InvalidQuantityException(f"{field_name} must be a positive integer > 0 (received {int_val}).")

    return int_val


def validate_iso_date(date_str: Optional[str], field_name: str = "date", required: bool = False) -> Optional[str]:
    """Validate ISO YYYY-MM-DD date string. Returns normalized date string."""
    if not date_str or not str(date_str).strip():
        if required:
            raise CorruptedDataRecordException(f"{field_name} is required in ISO YYYY-MM-DD format.")
        return ""

    val = str(date_str).strip()
    try:
        dt = datetime.strptime(val, "%Y-%m-%d").date()
        return dt.isoformat()
    except ValueError as err:
        raise CorruptedDataRecordException(
            f"Invalid date format for {field_name}: '{val}'. Must be ISO YYYY-MM-DD."
        ) from err


@dataclass
class Item:
    item_id: str
    item_name: str
    category: str
    unit: str
    quantity: int
    minimum_stock: int
    expiry_date: str = ""
    location: str = "Central Storage"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Item":
        """Construct and validate an Item instance from raw dictionary/CSV row."""
        item_id = str(data.get("item_id", "")).strip()
        if not item_id:
            raise CorruptedDataRecordException("item_id is required and cannot be blank.")

        item_name = str(data.get("item_name", "")).strip()
        if not item_name:
            raise CorruptedDataRecordException(f"item_name is required for item '{item_id}'.")

        category = str(data.get("category", "")).strip()
        if not category:
            raise CorruptedDataRecordException(f"category is required for item '{item_id}'.")

        unit = str(data.get("unit", "")).strip()
        if not unit:
            raise CorruptedDataRecordException(f"unit is required for item '{item_id}'.")

        location = str(data.get("location", "Main Pharmacy")).strip()
        if not location:
            location = "Main Pharmacy"

        # Validate numbers
        quantity = parse_and_validate_quantity(data.get("quantity"), field_name="quantity", allow_zero=True)
        minimum_stock = parse_and_validate_quantity(
            data.get("minimum_stock"), field_name="minimum_stock", allow_zero=True
        )

        # Validate expiry date
        expiry = validate_iso_date(data.get("expiry_date"), field_name="expiry_date", required=False) or ""

        return cls(
            item_id=item_id,
            item_name=item_name,
            category=category,
            unit=unit,
            quantity=quantity,
            minimum_stock=minimum_stock,
            expiry_date=expiry,
            location=location,
        )

    def is_expired(self, reference_date: Optional[date] = None) -> bool:
        """Check if supply item has passed its expiration date."""
        if not self.expiry_date:
            return False
        ref = reference_date or date.today()
        try:
            exp_date = datetime.strptime(self.expiry_date, "%Y-%m-%d").date()
            return exp_date < ref
        except ValueError:
            return False

    def is_near_expiry(self, days_threshold: int = 30, reference_date: Optional[date] = None) -> bool:
        """Check if item will expire within the given threshold days."""
        if not self.expiry_date:
            return False
        ref = reference_date or date.today()
        try:
            exp_date = datetime.strptime(self.expiry_date, "%Y-%m-%d").date()
            delta = (exp_date - ref).days
            return 0 <= delta <= days_threshold
        except ValueError:
            return False

    def get_usable_quantity(self, reference_date: Optional[date] = None) -> int:
        """Calculate usable quantity; expired stock cannot be issued to patients."""
        if self.is_expired(reference_date):
            return 0
        return self.quantity

    @property
    def usable_quantity(self) -> int:
        """Property alias for usable quantity using today's date."""
        return self.get_usable_quantity()

    def get_stock_status(self, critical_ratio: float = 0.50) -> str:
        """Return stock health status string: 'Expired', 'Critical', 'Low Stock', or 'Normal'."""
        if self.is_expired():
            return "Expired"
        if self.quantity == 0:
            return "Out of Stock"
        
        critical_threshold = max(1, int(self.minimum_stock * critical_ratio)) if self.minimum_stock > 0 else 0
        if self.minimum_stock > 0 and self.quantity <= critical_threshold:
            return "Critical"
        if self.quantity <= self.minimum_stock:
            return "Low Stock"
        return "Normal"

    def to_csv_dict(self) -> Dict[str, str]:
        """Convert Item to clean CSV format with sanitized values."""
        return {
            "item_id": sanitize_csv_field(self.item_id),
            "item_name": sanitize_csv_field(self.item_name),
            "category": sanitize_csv_field(self.category),
            "unit": sanitize_csv_field(self.unit),
            "quantity": str(self.quantity),
            "minimum_stock": str(self.minimum_stock),
            "expiry_date": self.expiry_date,
            "location": sanitize_csv_field(self.location),
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert Item to serializable dictionary with computed attributes."""
        d = asdict(self)
        d["usable_quantity"] = self.get_usable_quantity()
        d["is_expired"] = self.is_expired()
        d["status"] = self.get_stock_status()
        return d


@dataclass
class Transaction:
    transaction_id: str
    item_id: str
    transaction_date: str
    transaction_type: str  # 'IN' or 'OUT'
    quantity: int
    reference: str = ""
    remarks: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Transaction":
        """Construct and validate a Transaction from raw input/CSV row."""
        t_id = str(data.get("transaction_id", "")).strip()
        if not t_id:
            raise CorruptedDataRecordException("transaction_id is required.")

        item_id = str(data.get("item_id", "")).strip()
        if not item_id:
            raise CorruptedDataRecordException("item_id is required for transaction.")

        t_date = validate_iso_date(data.get("transaction_date"), field_name="transaction_date", required=True)

        t_type = str(data.get("transaction_type", "")).strip().upper()
        if t_type not in ("IN", "OUT"):
            raise CorruptedDataRecordException(
                f"transaction_type must be exactly 'IN' or 'OUT', received '{t_type}'."
            )

        qty = parse_and_validate_quantity(data.get("quantity"), field_name="quantity", allow_zero=False)

        ref = str(data.get("reference", "")).strip()
        remarks = str(data.get("remarks", "")).strip()

        return cls(
            transaction_id=t_id,
            item_id=item_id,
            transaction_date=t_date,
            transaction_type=t_type,
            quantity=qty,
            reference=ref,
            remarks=remarks,
        )

    def to_csv_dict(self) -> Dict[str, str]:
        """Convert Transaction to clean CSV format."""
        return {
            "transaction_id": sanitize_csv_field(self.transaction_id),
            "item_id": sanitize_csv_field(self.item_id),
            "transaction_date": self.transaction_date,
            "transaction_type": self.transaction_type,
            "quantity": str(self.quantity),
            "reference": sanitize_csv_field(self.reference),
            "remarks": sanitize_csv_field(self.remarks),
        }

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
