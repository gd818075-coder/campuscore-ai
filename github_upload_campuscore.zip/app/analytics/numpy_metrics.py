"""NumPy Numerical Analytics Engine for MediStock Analytics.

Demonstrates rigorous mathematical operations using NumPy:
- np.array
- np.sum
- np.mean
- np.var (ddof=0 for population variance, ddof=1 for sample variance)
- np.std (ddof=0 for population standard deviation)
- Continuous date-range zero-padding to eliminate upward statistical bias.
"""

from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional, Tuple
import numpy as np

from app.models import Transaction, Item


def generate_date_range(start_date: str, end_date: str) -> List[str]:
    """Generate continuous list of ISO YYYY-MM-DD dates between start and end inclusive."""
    d_start = datetime.strptime(start_date, "%Y-%m-%d").date()
    d_end = datetime.strptime(end_date, "%Y-%m-%d").date()
    if d_start > d_end:
        d_start, d_end = d_end, d_start

    delta_days = (d_end - d_start).days
    return [(d_start + timedelta(days=i)).isoformat() for i in range(delta_days + 1)]


def calculate_consumption_metrics(
    transactions: List[Transaction],
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
) -> Dict[str, Any]:
    """Calculate aggregate consumption statistics across a date range using NumPy.

    Ensures dates with 0 transactions are represented, preventing upward bias.
    Uses population conventions (ddof=0) by default for closed audit periods.
    """
    out_txs = [t for t in transactions if t.transaction_type == "OUT"]

    if not out_txs:
        return {
            "total_consumed_units": 0,
            "days_in_period": 0,
            "average_daily_consumption": 0.0,
            "variance": 0.0,
            "std_deviation": 0.0,
            "sample_variance": 0.0,
            "sample_std_deviation": 0.0,
            "statistical_convention": "Population (ddof=0) and Sample (ddof=1)",
            "daily_series": []
        }

    # Determine date bounds
    all_dates = [t.transaction_date for t in out_txs]
    resolved_start = start_date or min(all_dates)
    resolved_end = end_date or max(all_dates)

    date_series = generate_date_range(resolved_start, resolved_end)
    days_count = len(date_series)

    # Accumulate consumption by date
    daily_totals: Dict[str, int] = {d: 0 for d in date_series}
    for t in out_txs:
        if t.transaction_date in daily_totals:
            daily_totals[t.transaction_date] += t.quantity

    # Convert to pure NumPy array
    consumption_array = np.array(list(daily_totals.values()), dtype=np.float64)

    # Core NumPy operations
    total_consumed = float(np.sum(consumption_array))
    mean_daily = float(np.mean(consumption_array))
    
    # Population variance and standard deviation (ddof=0)
    pop_var = float(np.var(consumption_array, ddof=0))
    pop_std = float(np.std(consumption_array, ddof=0))

    # Sample variance and standard deviation (ddof=1, valid when N > 1)
    sample_var = float(np.var(consumption_array, ddof=1)) if days_count > 1 else 0.0
    sample_std = float(np.std(consumption_array, ddof=1)) if days_count > 1 else 0.0

    return {
        "period_start": resolved_start,
        "period_end": resolved_end,
        "days_in_period": days_count,
        "total_consumed_units": int(total_consumed),
        "average_daily_consumption": round(mean_daily, 2),
        "variance": round(pop_var, 4),
        "std_deviation": round(pop_std, 4),
        "sample_variance": round(sample_var, 4),
        "sample_std_deviation": round(sample_std, 4),
        "statistical_convention": "Population variance/std (N, ddof=0); Sample (N-1, ddof=1)",
        "daily_series": [{"date": d, "quantity": daily_totals[d]} for d in date_series]
    }


def calculate_item_runway_metrics(
    items: List[Item],
    transactions: List[Transaction],
    lookback_days: int = 30
) -> List[Dict[str, Any]]:
    """Compute item-wise daily consumption rates and estimated days of supply remaining.

    Days Remaining = Usable Stock / Average Daily Consumption (defined when average daily consumption > 0).
    """
    ref_end = date.today()
    ref_start = ref_end - timedelta(days=lookback_days - 1)
    date_series = generate_date_range(ref_start.isoformat(), ref_end.isoformat())
    days_count = len(date_series)

    # Filter OUT transactions in lookback window
    out_txs = [
        t for t in transactions
        if t.transaction_type == "OUT" and ref_start.isoformat() <= t.transaction_date <= ref_end.isoformat()
    ]

    item_consumption_map: Dict[str, Dict[str, int]] = {
        item.item_id: {d: 0 for d in date_series} for item in items
    }

    for t in out_txs:
        if t.item_id in item_consumption_map and t.transaction_date in item_consumption_map[t.item_id]:
            item_consumption_map[t.item_id][t.transaction_date] += t.quantity

    results = []
    for item in items:
        arr = np.array(list(item_consumption_map[item.item_id].values()), dtype=np.float64)
        total_used = float(np.sum(arr))
        daily_avg = float(np.mean(arr))
        pop_std = float(np.std(arr, ddof=0))

        usable_stock = item.get_usable_quantity()

        if daily_avg > 0:
            days_remaining = round(usable_stock / daily_avg, 1)
        else:
            days_remaining = None  # Undefined/infinite if no usage

        # Simple trend indication
        if len(arr) >= 7:
            first_half = float(np.mean(arr[:len(arr)//2]))
            second_half = float(np.mean(arr[len(arr)//2:]))
            if second_half > first_half * 1.15:
                trend = "Surging"
            elif second_half < first_half * 0.85:
                trend = "Declining"
            else:
                trend = "Stable"
        else:
            trend = "Insufficient Data"

        results.append({
            "item_id": item.item_id,
            "item_name": item.item_name,
            "category": item.category,
            "unit": item.unit,
            "physical_stock": item.quantity,
            "usable_stock": usable_stock,
            "is_expired": item.is_expired(),
            "total_lookback_consumed": int(total_used),
            "average_daily_rate": round(daily_avg, 2),
            "rate_std_deviation": round(pop_std, 2),
            "estimated_days_remaining": days_remaining,
            "trend": trend,
            "lookback_days": lookback_days
        })

    return results
