"""Pandas Reporting and Analytics Module for MediStock Analytics.

Utilizes pandas.DataFrame, vectorized boolean filtering, groupby aggregations,
merges, and CSV exports to generate critical hospital management reports.
"""

from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path
import pandas as pd
import numpy as np

from app.config import config
from app.exceptions import CorruptedDataRecordException
from app.repository.csv_repository import CSVRepository


class PandasReports:
    def __init__(self, repository: Optional[CSVRepository] = None):
        self.repo = repository or CSVRepository()

    def get_inventory_df(self) -> pd.DataFrame:
        """Load and return inventory as a clean, typed Pandas DataFrame."""
        inv_file = self.repo.inventory_file
        if not inv_file.exists() or inv_file.stat().st_size == 0:
            return pd.DataFrame(columns=[
                "item_id", "item_name", "category", "unit",
                "quantity", "minimum_stock", "expiry_date", "location",
                "is_expired", "usable_quantity", "stock_status"
            ])

        try:
            df = pd.read_csv(
                inv_file,
                dtype={
                    "item_id": str,
                    "item_name": str,
                    "category": str,
                    "unit": str,
                    "quantity": int,
                    "minimum_stock": int,
                    "location": str
                },
                na_values=["", "NA", "NaN"],
                keep_default_na=False
            )
            df["expiry_date"] = df["expiry_date"].astype(str).str.strip()

            today_str = date.today().isoformat()
            # Calculate computed columns
            df["is_expired"] = (df["expiry_date"] != "") & (df["expiry_date"] < today_str)
            df["usable_quantity"] = np.where(df["is_expired"], 0, df["quantity"])

            # Compute stock status
            conditions = [
                df["is_expired"],
                df["quantity"] == 0,
                (df["minimum_stock"] > 0) & (df["quantity"] <= (df["minimum_stock"] * config.CRITICAL_STOCK_RATIO)),
                df["quantity"] <= df["minimum_stock"]
            ]
            choices = ["Expired", "Out of Stock", "Critical", "Low Stock"]
            df["stock_status"] = np.select(conditions, choices, default="Normal")

            return df
        except Exception as e:
            raise CorruptedDataRecordException(f"Pandas failed to parse inventory CSV: {e}") from e

    def get_consumption_df(self) -> pd.DataFrame:
        """Load and return transactions as a clean, typed Pandas DataFrame."""
        con_file = self.repo.consumption_file
        if not con_file.exists() or con_file.stat().st_size == 0:
            return pd.DataFrame(columns=[
                "transaction_id", "item_id", "transaction_date",
                "transaction_type", "quantity", "reference", "remarks"
            ])

        try:
            df = pd.read_csv(
                con_file,
                dtype={
                    "transaction_id": str,
                    "item_id": str,
                    "transaction_date": str,
                    "transaction_type": str,
                    "quantity": int,
                    "reference": str,
                    "remarks": str
                },
                na_values=["", "NA", "NaN"],
                keep_default_na=False
            )
            df["transaction_date"] = pd.to_datetime(df["transaction_date"], format="%Y-%m-%d", errors="coerce").dt.strftime("%Y-%m-%d")
            return df
        except Exception as e:
            raise CorruptedDataRecordException(f"Pandas failed to parse consumption CSV: {e}") from e

    # ==========================
    # DOMAIN REPORTS
    # ==========================

    def generate_low_stock_report(self) -> pd.DataFrame:
        """Filter items where quantity <= minimum_stock (excluding expired)."""
        df = self.get_inventory_df()
        if df.empty:
            return df
        mask = (df["quantity"] <= df["minimum_stock"]) & (~df["is_expired"])
        res = df[mask].copy()
        res["shortage_units"] = res["minimum_stock"] - res["quantity"]
        return res.sort_values(by="shortage_units", ascending=False)

    def generate_critical_stock_report(self, ratio: Optional[float] = None) -> pd.DataFrame:
        """Filter items in critical shortage (quantity <= ratio * minimum_stock)."""
        critical_ratio = ratio or config.CRITICAL_STOCK_RATIO
        df = self.get_inventory_df()
        if df.empty:
            return df
        mask = (
            (df["minimum_stock"] > 0) &
            (df["quantity"] <= (df["minimum_stock"] * critical_ratio)) &
            (~df["is_expired"])
        )
        res = df[mask].copy()
        res["critical_threshold"] = (res["minimum_stock"] * critical_ratio).astype(int)
        return res.sort_values(by="quantity", ascending=True)

    def generate_expiry_report(self, near_expiry_days: int = 30) -> pd.DataFrame:
        """Identify both expired items and supplies expiring within near_expiry_days."""
        df = self.get_inventory_df()
        if df.empty:
            return df

        today = date.today()
        threshold_date = (today + timedelta(days=near_expiry_days)).isoformat()
        today_str = today.isoformat()

        mask_exp = (df["expiry_date"] != "") & (df["expiry_date"] < today_str)
        mask_near = (df["expiry_date"] != "") & (df["expiry_date"] >= today_str) & (df["expiry_date"] <= threshold_date)

        report_df = df[mask_exp | mask_near].copy()
        if not report_df.empty:
            report_df["expiry_category"] = np.where(report_df["is_expired"], "Expired (Do Not Use)", "Expiring Soon")
            # Calculate days until expiry
            exp_dates = pd.to_datetime(report_df["expiry_date"])
            today_ts = pd.to_datetime(today_str)
            report_df["days_to_expiry"] = (exp_dates - today_ts).dt.days
        return report_df.sort_values(by="expiry_date", ascending=True)

    def generate_category_summary(self) -> pd.DataFrame:
        """Aggregate total items, total units, and usable units grouped by category."""
        df = self.get_inventory_df()
        if df.empty:
            return pd.DataFrame(columns=["category", "total_items", "total_physical_units", "total_usable_units", "low_stock_items"])

        grouped = df.groupby("category").agg(
            total_items=("item_id", "count"),
            total_physical_units=("quantity", "sum"),
            total_usable_units=("usable_quantity", "sum"),
            low_stock_items=("stock_status", lambda s: (s.isin(["Low Stock", "Critical", "Out of Stock"])).sum())
        ).reset_index()

        return grouped.sort_values(by="total_items", ascending=False)

    def generate_daily_consumption_report(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Aggregate total issued quantity per day, merged with inventory names."""
        con_df = self.get_consumption_df()
        if con_df.empty:
            return pd.DataFrame(columns=["transaction_date", "units_issued", "transaction_count"])

        out_df = con_df[con_df["transaction_type"] == "OUT"].copy()
        if start_date:
            out_df = out_df[out_df["transaction_date"] >= start_date]
        if end_date:
            out_df = out_df[out_df["transaction_date"] <= end_date]

        if out_df.empty:
            return pd.DataFrame(columns=["transaction_date", "units_issued", "transaction_count"])

        daily = out_df.groupby("transaction_date").agg(
            units_issued=("quantity", "sum"),
            transaction_count=("transaction_id", "count")
        ).reset_index()

        return daily.sort_values(by="transaction_date", ascending=True)

    def generate_item_consumption_report(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Item-wise consumption breakdown merged with current stock and names."""
        inv_df = self.get_inventory_df()
        con_df = self.get_consumption_df()

        if inv_df.empty:
            return pd.DataFrame()

        out_df = con_df[con_df["transaction_type"] == "OUT"].copy() if not con_df.empty else pd.DataFrame()
        if not out_df.empty:
            if start_date:
                out_df = out_df[out_df["transaction_date"] >= start_date]
            if end_date:
                out_df = out_df[out_df["transaction_date"] <= end_date]

        if not out_df.empty:
            consumed = out_df.groupby("item_id").agg(
                units_consumed=("quantity", "sum"),
                transactions_count=("transaction_id", "count")
            ).reset_index()
        else:
            consumed = pd.DataFrame(columns=["item_id", "units_consumed", "transactions_count"])

        # Merge with inventory
        merged = pd.merge(inv_df, consumed, on="item_id", how="left")
        merged["units_consumed"] = merged["units_consumed"].fillna(0).astype(int)
        merged["transactions_count"] = merged["transactions_count"].fillna(0).astype(int)

        cols = [
            "item_id", "item_name", "category", "unit",
            "quantity", "usable_quantity", "units_consumed",
            "transactions_count", "stock_status"
        ]
        return merged[cols].sort_values(by="units_consumed", ascending=False)

    def export_report_to_csv(self, df: pd.DataFrame, output_path: Path) -> str:
        """Export any generated DataFrame report to CSV with explicit UTF-8 encoding."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False, encoding="utf-8")
        return str(output_path)


pandas_reports = PandasReports()
