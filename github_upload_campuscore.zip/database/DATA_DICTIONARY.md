# CAMPUSCORE — DATA DICTIONARY
**Database:** `campuscore_db`  
**Engine:** InnoDB  
**Character Set:** utf8mb4  
**Collation:** utf8mb4_unicode_ci  

---

### Table 1: `departments`
Stores academic departments overseeing degree programs and faculty.
- `department_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Unique system surrogate key.
- `code` (VARCHAR(10), NOT NULL, UNIQUE): Department short code (e.g., 'DCA', 'DIT').
- `name` (VARCHAR(100), NOT NULL): Official name of the department.
- `established_year` (INT, NOT NULL, CHECK: >= 1950): Foundation year.
- `building` (VARCHAR(50), NOT NULL): Campus building/block location.
- `head_of_dept` (VARCHAR(100), NULL): Current Department Chairperson / HOD.
- `created_at` (TIMESTAMP, DEFAULT: CURRENT_TIMESTAMP): Audit timestamp.

### Table 2: `courses`
Stores degree programs (BCA, MCA, etc.) offered by departments.
- `course_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Unique course key.
- `code` (VARCHAR(10), NOT NULL, UNIQUE): Academic code (e.g., 'BCA').
- `name` (VARCHAR(120), NOT NULL): Course title.
- `department_id` (INT, NOT NULL, FK -> `departments.department_id`): Parent department.
- `duration_years` (INT, NOT NULL, DEFAULT: 3): Duration in years.
- `total_semesters` (INT, NOT NULL, DEFAULT: 6, CHECK: 1..12): Number of semesters.
- `degree_level` (ENUM, NOT NULL): 'Undergraduate', 'Postgraduate', 'Diploma', 'Doctorate'.

### Table 3: `semesters`
Defines academic terms and scheduling per course.
- `semester_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Unique semester record.
- `course_id` (INT, NOT NULL, FK -> `courses.course_id`): Associated course.
- `semester_number` (INT, NOT NULL, CHECK: 1..12): Semester order index.
- `academic_year` (VARCHAR(9), NOT NULL): Academic cohort format 'YYYY-YYYY'.
- `term` (ENUM('Odd', 'Even'), NOT NULL): Term classification.
- `start_date` (DATE, NOT NULL): Session start date.
- `end_date` (DATE, NOT NULL, CHECK: > start_date): Session end date.
- `is_current` (BOOLEAN, DEFAULT: FALSE): Flags active term.
- *Unique Constraint:* `(course_id, semester_number, academic_year)`

### Table 4: `students`
Master entity recording student demographics and academic status.
- `student_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Surrogate student key.
- `reg_number` (VARCHAR(20), NOT NULL, UNIQUE): Official university register number.
- `first_name` (VARCHAR(50), NOT NULL): Given name.
- `last_name` (VARCHAR(50), NOT NULL): Family name / surname.
- `email` (VARCHAR(100), NOT NULL, UNIQUE): Institutional email address.
- `phone` (VARCHAR(15), NOT NULL): Primary contact telephone.
- `dob` (DATE, NOT NULL): Date of birth.
- `gender` (ENUM('Male', 'Female', 'Other'), NOT NULL): Gender.
- `blood_group` (ENUM, DEFAULT 'O+'): Blood type for medical campus records.
- `address` (VARCHAR(255), NOT NULL): Permanent residential address.
- `city` (VARCHAR(50), NOT NULL): City.
- `state` (VARCHAR(50), NOT NULL): State.
- `admission_date` (DATE, NOT NULL): University admission date.
- `current_semester_id` (INT, NULL, FK -> `semesters.semester_id`): Current semester.
- `status` (ENUM('Active', 'Graduated', 'Suspended', 'Withdrawn'), DEFAULT 'Active').

### Table 5: `faculty`
Faculty members, qualifications, and department affiliations.
- `faculty_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Surrogate faculty key.
- `employee_code` (VARCHAR(15), NOT NULL, UNIQUE): Institutional employee identifier.
- `first_name` (VARCHAR(50), NOT NULL): Given name.
- `last_name` (VARCHAR(50), NOT NULL): Surname.
- `email` (VARCHAR(100), NOT NULL, UNIQUE): Official email.
- `phone` (VARCHAR(15), NOT NULL): Contact phone.
- `department_id` (INT, NOT NULL, FK -> `departments.department_id`): Department.
- `designation` (ENUM('Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'HOD')).
- `qualification` (VARCHAR(100), NOT NULL): Highest degree achieved.
- `joining_date` (DATE, NOT NULL): Appointment date.
- `status` (ENUM('Active', 'On Leave', 'Resigned'), DEFAULT 'Active').

### Table 6: `subjects`
Curriculum subjects and course syllabus details.
- `subject_id` (INT, AUTO_INCREMENT, PRIMARY KEY): Subject identifier.
- `code` (VARCHAR(15), NOT NULL, UNIQUE): Subject course code (e.g., 'BCA301').
- `name` (VARCHAR(100), NOT NULL): Subject title.
- `credits` (INT, NOT NULL, CHECK: 1..10): Course credits.
- `course_id` (INT, NOT NULL, FK -> `courses.course_id`): Course syllabus owner.
- `semester_number` (INT, NOT NULL): Curricular semester semester level.
- `subject_type` (ENUM('Theory', 'Lab', 'Project', 'Elective'), DEFAULT 'Theory').
- `max_internal_marks` (DECIMAL(5,2), NOT NULL, DEFAULT 30.00).
- `max_exam_marks` (DECIMAL(5,2), NOT NULL, DEFAULT 70.00).

### Table 7: `faculty_subject_assignments`
Bridge table linking faculty to taught subjects per academic year.
- `assignment_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `faculty_id` (INT, NOT NULL, FK -> `faculty.faculty_id`).
- `subject_id` (INT, NOT NULL, FK -> `subjects.subject_id`).
- `academic_year` (VARCHAR(9), NOT NULL).
- `semester_id` (INT, NOT NULL, FK -> `semesters.semester_id`).
- `assigned_date` (DATE, NOT NULL).
- *Unique Constraint:* `(faculty_id, subject_id, academic_year)`

### Table 8: `enrollments`
Tracks student progression across semesters.
- `enrollment_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `student_id` (INT, NOT NULL, FK -> `students.student_id`).
- `course_id` (INT, NOT NULL, FK -> `courses.course_id`).
- `semester_id` (INT, NOT NULL, FK -> `semesters.semester_id`).
- `academic_year` (VARCHAR(9), NOT NULL).
- `enrollment_date` (DATE, NOT NULL).
- `status` (ENUM('Active', 'Completed', 'Dropped'), DEFAULT 'Active').
- *Unique Constraint:* `(student_id, semester_id, academic_year)`

### Table 9: `attendance`
Session-level attendance tracking.
- `attendance_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `student_id` (INT, NOT NULL, FK -> `students.student_id`).
- `subject_id` (INT, NOT NULL, FK -> `subjects.subject_id`).
- `attendance_date` (DATE, NOT NULL).
- `status` (ENUM('Present', 'Absent', 'Late', 'Excused'), DEFAULT 'Present').
- `remarks` (VARCHAR(100), NULL).
- `recorded_by_faculty_id` (INT, NULL, FK -> `faculty.faculty_id`).
- *Unique Constraint:* `(student_id, subject_id, attendance_date)`

### Table 10: `assessments`
Assessment definitions (CIA 1, CIA 2, Semester Final).
- `assessment_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `subject_id` (INT, NOT NULL, FK -> `subjects.subject_id`).
- `semester_id` (INT, NOT NULL, FK -> `semesters.semester_id`).
- `name` (VARCHAR(50), NOT NULL).
- `assessment_type` (ENUM('Internal', 'Semester_Exam'), NOT NULL).
- `max_marks` (DECIMAL(5,2), NOT NULL).
- `weightage_percent` (DECIMAL(5,2), NOT NULL, DEFAULT 100.00).
- `conduct_date` (DATE, NOT NULL).

### Table 11: `marks`
Recorded marks for students on assessments.
- `mark_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `assessment_id` (INT, NOT NULL, FK -> `assessments.assessment_id`).
- `student_id` (INT, NOT NULL, FK -> `students.student_id`).
- `marks_obtained` (DECIMAL(5,2), NOT NULL, CHECK: >= 0).
- `is_absent` (BOOLEAN, NOT NULL, DEFAULT FALSE).
- `remarks` (VARCHAR(100), NULL).
- *Unique Constraint:* `(assessment_id, student_id)`

### Table 12: `fee_records`
Financial receivables billed to students per semester.
- `fee_record_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `student_id` (INT, NOT NULL, FK -> `students.student_id`).
- `semester_id` (INT, NOT NULL, FK -> `semesters.semester_id`).
- `fee_type` (ENUM('Tuition', 'Examination', 'Library', 'Laboratory', 'Hostel', 'Special')).
- `amount_due` (DECIMAL(10,2), NOT NULL, CHECK: > 0).
- `due_date` (DATE, NOT NULL).

### Table 13: `fee_payments`
Receipted transactions against billed fee records.
- `payment_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `fee_record_id` (INT, NOT NULL, FK -> `fee_records.fee_record_id`).
- `receipt_number` (VARCHAR(30), NOT NULL, UNIQUE).
- `amount_paid` (DECIMAL(10,2), NOT NULL, CHECK: > 0).
- `payment_date` (DATE, NOT NULL).
- `payment_mode` (ENUM('Cash', 'Demand Draft', 'Bank Transfer', 'UPI Reference')).
- `transaction_ref` (VARCHAR(50), NULL).
- `notes` (VARCHAR(200), NULL).

### Table 14: `student_feedback`
Quality feedback submitted by students regarding faculty and infrastructure.
- `feedback_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `student_id` (INT, NOT NULL, FK -> `students.student_id`).
- `faculty_id` (INT, NULL, FK -> `faculty.faculty_id`).
- `subject_id` (INT, NULL, FK -> `subjects.subject_id`).
- `rating` (INT, NOT NULL, CHECK: 1..5).
- `category` (ENUM('Course Delivery', 'Lab Facilities', 'Examination Evaluation', 'General Campus')).
- `comments` (TEXT, NOT NULL).
- `status` (ENUM('Reviewed', 'Pending'), DEFAULT 'Pending').

### Table 15: `users`
Authentication credentials, RBAC roles, and portal accounts.
- `user_id` (INT, AUTO_INCREMENT, PRIMARY KEY).
- `username` (VARCHAR(50), NOT NULL, UNIQUE).
- `password_hash` (VARCHAR(255), NOT NULL).
- `full_name` (VARCHAR(100), NOT NULL).
- `email` (VARCHAR(100), NOT NULL, UNIQUE).
- `role` (ENUM('Administrator', 'Faculty', 'Student')).
- `linked_id` (INT, NULL).
- `is_active` (BOOLEAN, NOT NULL, DEFAULT TRUE).
