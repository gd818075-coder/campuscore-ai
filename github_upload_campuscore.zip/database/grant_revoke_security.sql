-- =============================================================================
-- CAMPUSCORE — DCL (DATA CONTROL LANGUAGE) & SECURITY SCRIPT
-- Concepts: CREATE USER, CREATE ROLE, GRANT, REVOKE, Least Privilege
-- Project: BCA Semester 3 DBMS Project-Based Learning Assignment
-- Note: Must be executed by a Database Administrator (DBA/root) account
-- =============================================================================

USE campuscore_db;

-- -----------------------------------------------------------------------------
-- 1. SECURITY RATIONALE (ACADEMIC REQUIREMENT)
-- Applications must NEVER connect using root or administrative credentials.
-- Least Privilege Principle: Every user and application role should only possess
-- the minimum database permissions required to perform their authorized tasks.
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- 2. CREATE DATABASE ROLES FOR UNIVERSITY PERSONAS
-- -----------------------------------------------------------------------------

-- Role for Application Backend Service Account
CREATE ROLE IF NOT EXISTS 'campuscore_app_role';

-- Role for University Faculty (Read student/subject data, Write attendance & marks)
CREATE ROLE IF NOT EXISTS 'faculty_role';

-- Role for Students (Read-only on own academic records, Insert feedback)
CREATE ROLE IF NOT EXISTS 'student_role';

-- Role for Department Examination Officer
CREATE ROLE IF NOT EXISTS 'exam_controller_role';


-- -----------------------------------------------------------------------------
-- 3. GRANT STATEMENTS (ASSIGNING PRIVILEGES TO ROLES)
-- -----------------------------------------------------------------------------

-- 3.1 Application Backend Role: Requires DML and View access, but NO DDL (DROP/ALTER) in production
GRANT SELECT, INSERT, UPDATE, DELETE ON campuscore_db.* TO 'campuscore_app_role';

-- 3.2 Faculty Role: Can manage attendance and marks, read student directory
GRANT SELECT ON campuscore_db.students TO 'faculty_role';
GRANT SELECT ON campuscore_db.subjects TO 'faculty_role';
GRANT SELECT, INSERT, UPDATE ON campuscore_db.attendance TO 'faculty_role';
GRANT SELECT, INSERT, UPDATE ON campuscore_db.marks TO 'faculty_role';
GRANT SELECT ON campuscore_db.v_student_attendance_summary TO 'faculty_role';

-- 3.3 Student Role: Restricted strictly from modifying marks, attendance, or fees
GRANT SELECT ON campuscore_db.v_student_academic_summary TO 'student_role';
GRANT SELECT ON campuscore_db.v_student_attendance_summary TO 'student_role';
GRANT SELECT ON campuscore_db.v_student_performance TO 'student_role';
GRANT SELECT ON campuscore_db.v_fee_summary TO 'student_role';
GRANT INSERT ON campuscore_db.student_feedback TO 'student_role';

-- 3.4 Examination Controller: Manages assessments and official grades
GRANT SELECT, INSERT, UPDATE ON campuscore_db.assessments TO 'exam_controller_role';
GRANT SELECT, INSERT, UPDATE ON campuscore_db.marks TO 'exam_controller_role';


-- -----------------------------------------------------------------------------
-- 4. CREATE DEDICATED USERS & ASSIGN ROLES
-- -----------------------------------------------------------------------------

-- Create Application Database User
CREATE USER IF NOT EXISTS 'campuscore_user'@'localhost' IDENTIFIED BY 'StrongP@ssw0rd2024!';
CREATE USER IF NOT EXISTS 'campuscore_user'@'%' IDENTIFIED BY 'StrongP@ssw0rd2024!';

-- Assign Application Role
GRANT 'campuscore_app_role' TO 'campuscore_user'@'localhost';
GRANT 'campuscore_app_role' TO 'campuscore_user'@'%';
SET DEFAULT ROLE 'campuscore_app_role' TO 'campuscore_user'@'localhost';
SET DEFAULT ROLE 'campuscore_app_role' TO 'campuscore_user'@'%';

-- Create Demo Faculty DB User
CREATE USER IF NOT EXISTS 'prof_anand'@'%' IDENTIFIED BY 'FacultyPass#123';
GRANT 'faculty_role' TO 'prof_anand'@'%';
SET DEFAULT ROLE 'faculty_role' TO 'prof_anand'@'%';


-- -----------------------------------------------------------------------------
-- 5. REVOKE STATEMENTS (WITHDRAWING PRIVILEGES)
-- Demonstrating how permissions are revoked when security policy changes
-- -----------------------------------------------------------------------------

-- Revoke DELETE privilege on attendance from faculty (only Admin can delete historic records)
REVOKE DELETE ON campuscore_db.attendance FROM 'faculty_role';

-- Revoke direct table access if migrated to stored procedures / views
-- REVOKE SELECT ON campuscore_db.students FROM 'student_role';

-- Show Grants for verification
SHOW GRANTS FOR 'campuscore_user'@'localhost';
SHOW GRANTS FOR 'faculty_role';

-- Apply changes
FLUSH PRIVILEGES;
