-- =============================================================================
-- CAMPUSCORE — DBMS LAB SQL SCRIPTS & DEMONSTRATION QUERIES
-- BCA Semester 3 Database Management Systems (DBMS & SQL)
-- Categorized: DDL, DML, DQL, Joins, Aggregates, Subqueries, Views, DCL, TCL
-- =============================================================================

USE campuscore_db;

-- =============================================================================
-- SECTION 1: DDL (DATA DEFINITION LANGUAGE)
-- Purpose: Defining, altering, and dropping database structures and constraints
-- =============================================================================

-- 1.1 CREATE TABLE with Primary Key, Foreign Key, and CHECK Constraints
CREATE TABLE IF NOT EXISTS student_clubs (
    club_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    category ENUM('Technical', 'Cultural', 'Sports', 'Academic') NOT NULL,
    faculty_mentor_id INT,
    annual_budget DECIMAL(10,2) DEFAULT 5000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_mentor_id) REFERENCES faculty(faculty_id) ON DELETE SET NULL,
    CONSTRAINT chk_budget CHECK (annual_budget >= 0)
) ENGINE=InnoDB;

-- 1.2 ALTER TABLE: Add a new column with DEFAULT constraint
ALTER TABLE students ADD COLUMN IF NOT EXISTS guardian_contact VARCHAR(15) NULL;

-- 1.3 ALTER TABLE: Add Index for query performance
CREATE INDEX IF NOT EXISTS idx_students_city ON students(city);

-- 1.4 DROP TABLE safely
-- DROP TABLE IF EXISTS student_clubs;


-- =============================================================================
-- SECTION 2: DML (DATA MANIPULATION LANGUAGE)
-- Purpose: Inserting, updating, and deleting rows in relational tables
-- =============================================================================

-- 2.1 INSERT with explicit column names
INSERT INTO subjects (code, name, credits, course_id, semester_number, subject_type, max_internal_marks, max_exam_marks)
VALUES ('BCA306', 'Web Application Development', 3, 1, 3, 'Theory', 30.00, 70.00);

-- 2.2 UPDATE with WHERE clause and parameterized values
UPDATE students 
SET phone = '9888877777', address = '50 Innovation Boulevard'
WHERE reg_number = 'BCA2023001';

-- 2.3 DELETE with condition and integrity consideration
DELETE FROM student_feedback 
WHERE feedback_id = 999;


-- =============================================================================
-- SECTION 3: DQL (DATA QUERY LANGUAGE) & RELATIONAL FILTERING
-- Purpose: Querying data with projections, restrictions, pattern matching
-- =============================================================================

-- 3.1 Projections and Sorting (ORDER BY)
SELECT reg_number, first_name, last_name, email, city, admission_date
FROM students
WHERE status = 'Active'
ORDER BY last_name ASC, first_name ASC;

-- 3.2 Pattern Matching with LIKE & Wildcards
SELECT reg_number, first_name, last_name, email
FROM students
WHERE email LIKE '%@student.campuscore.edu' AND first_name LIKE 'A%';

-- 3.3 Set Membership (IN) and Range Filtering (BETWEEN)
SELECT student_id, reg_number, first_name, dob
FROM students
WHERE dob BETWEEN '2004-01-01' AND '2004-12-31';


-- =============================================================================
-- SECTION 4: RELATIONAL JOINS (INNER, LEFT, SELF)
-- Purpose: Combining tuples from two or more tables based on join predicates
-- =============================================================================

-- 4.1 INNER JOIN: Students enrolled with Course and Semester details
SELECT 
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    c.name AS course_name,
    sem.semester_number,
    sem.academic_year,
    e.enrollment_date
FROM enrollments e
INNER JOIN students s ON e.student_id = s.student_id
INNER JOIN courses c ON e.course_id = c.course_id
INNER JOIN semesters sem ON e.semester_id = sem.semester_id
WHERE e.status = 'Active';

-- 4.2 LEFT OUTER JOIN: All Faculty and any assigned Subjects (including faculty without assignments)
SELECT 
    f.employee_code,
    CONCAT(f.first_name, ' ', f.last_name) AS faculty_name,
    f.designation,
    d.name AS department_name,
    sub.code AS subject_code,
    sub.name AS assigned_subject
FROM faculty f
LEFT JOIN departments d ON f.department_id = d.department_id
LEFT JOIN faculty_subject_assignments fsa ON f.faculty_id = fsa.faculty_id
LEFT JOIN subjects sub ON fsa.subject_id = sub.subject_id
ORDER BY f.employee_code;

-- 4.3 MULTI-TABLE JOIN: Comprehensive Attendance Record with Subject and Faculty
SELECT 
    a.attendance_date,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    sub.name AS subject_name,
    a.status AS attendance_status,
    CONCAT(f.first_name, ' ', f.last_name) AS marked_by_faculty
FROM attendance a
JOIN students s ON a.student_id = s.student_id
JOIN subjects sub ON a.subject_id = sub.subject_id
LEFT JOIN faculty f ON a.recorded_by_faculty_id = f.faculty_id
ORDER BY a.attendance_date DESC, s.reg_number ASC;


-- =============================================================================
-- SECTION 5: AGGREGATE FUNCTIONS & GROUP BY / HAVING
-- Purpose: Summarizing datasets across partitions using COUNT, SUM, AVG, MIN, MAX
-- =============================================================================

-- 5.1 Department-wise Faculty Count and Average Course Duration
SELECT 
    d.code AS dept_code,
    d.name AS dept_name,
    COUNT(DISTINCT f.faculty_id) AS total_faculty,
    COUNT(DISTINCT c.course_id) AS total_courses,
    ROUND(AVG(c.duration_years), 1) AS avg_course_duration
FROM departments d
LEFT JOIN faculty f ON d.department_id = f.department_id
LEFT JOIN courses c ON d.department_id = c.department_id
GROUP BY d.department_id, d.code, d.name;

-- 5.2 Subject-wise Attendance Percentage with HAVING Clause (Attendance < 75% warning)
SELECT 
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    sub.code AS subject_code,
    COUNT(a.attendance_id) AS total_classes,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_classes,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) * 100.0) / COUNT(a.attendance_id), 2) AS attendance_pct
FROM attendance a
JOIN students s ON a.student_id = s.student_id
JOIN subjects sub ON a.subject_id = sub.subject_id
GROUP BY s.student_id, s.reg_number, s.first_name, s.last_name, sub.subject_id, sub.code
HAVING attendance_pct < 75.00;


-- =============================================================================
-- SECTION 6: SUBQUERIES (SCALAR, IN, EXISTS, CORRELATED)
-- Purpose: Nesting SQL queries inside SELECT, WHERE, or FROM clauses
-- =============================================================================

-- 6.1 Subquery with IN: Students who scored higher than the Class Average in CIA-1
SELECT 
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    m.marks_obtained
FROM marks m
JOIN students s ON m.student_id = s.student_id
WHERE m.assessment_id = 1
  AND m.marks_obtained > (
      SELECT AVG(marks_obtained) 
      FROM marks 
      WHERE assessment_id = 1
  )
ORDER BY m.marks_obtained DESC;

-- 6.2 Correlated Subquery with EXISTS: Students with Overdue Pending Fees
SELECT 
    s.student_id,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    s.email
FROM students s
WHERE EXISTS (
    SELECT 1 
    FROM fee_records fr
    LEFT JOIN fee_payments fp ON fr.fee_record_id = fp.fee_record_id
    WHERE fr.student_id = s.student_id
    GROUP BY fr.fee_record_id, fr.amount_due
    HAVING (fr.amount_due - COALESCE(SUM(fp.amount_paid), 0)) > 0
);


-- =============================================================================
-- SECTION 7: DATABASE VIEWS
-- Purpose: Providing logical abstraction, security filtering, and reporting
-- =============================================================================

-- Query the Student Academic Summary View
SELECT * FROM v_student_academic_summary WHERE semester_number = 3;

-- Query the Fee Summary View
SELECT * FROM v_fee_summary WHERE pending_balance > 0;
