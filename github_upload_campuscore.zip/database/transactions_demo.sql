-- =============================================================================
-- CAMPUSCORE — TCL (TRANSACTION CONTROL LANGUAGE) DEMONSTRATION SCRIPT
-- Concepts: START TRANSACTION, COMMIT, ROLLBACK, SAVEPOINT
-- Project: BCA Semester 3 DBMS Project-Based Learning Assignment
-- =============================================================================

USE campuscore_db;

-- -----------------------------------------------------------------------------
-- SCENARIO 1: ATOMIC FEE PAYMENT RECORDING (COMMIT)
-- Objective: Insert payment and verify fee record status inside a single transaction.
-- If all operations succeed, COMMIT permanently writes the transaction.
-- -----------------------------------------------------------------------------

START TRANSACTION;

-- Step 1: Check pending balance for fee_record_id = 5
SELECT fee_record_id, amount_due FROM fee_records WHERE fee_record_id = 5;

-- Step 2: Insert new payment of 20000.00
INSERT INTO fee_payments (
    fee_record_id, 
    receipt_number, 
    amount_paid, 
    payment_date, 
    payment_mode, 
    transaction_ref, 
    notes
) VALUES (
    5, 
    'RCP-TXN-DEMO-01', 
    20000.00, 
    CURRENT_DATE, 
    'UPI Reference', 
    'UPI-DEMO-9918237', 
    'Demonstration atomic fee clearance'
);

-- Step 3: Verify the payment within the uncommitted transaction scope
SELECT * FROM fee_payments WHERE receipt_number = 'RCP-TXN-DEMO-01';

-- Step 4: Make changes permanent
COMMIT;

-- Verify changes persist after commit:
SELECT * FROM fee_payments WHERE receipt_number = 'RCP-TXN-DEMO-01';


-- -----------------------------------------------------------------------------
-- SCENARIO 2: ERROR SIMULATION & ROLLBACK
-- Objective: Attempt to perform operations that violate business constraints or encounter
-- an exception, then ROLLBACK to restore initial state cleanly without partial corruption.
-- -----------------------------------------------------------------------------

START TRANSACTION;

-- Step 1: Record initial count of students
SELECT COUNT(*) AS initial_student_count FROM students;

-- Step 2: Insert temporary test student
INSERT INTO students (
    reg_number, first_name, last_name, email, phone, dob, gender, blood_group, 
    address, city, state, admission_date, current_semester_id, status
) VALUES (
    'TEMP-TEST-999', 'Rollback', 'Demo', 'rollback.demo@test.com', '9000000000', 
    '2004-01-01', 'Other', 'O+', '100 Virtual Way', 'Test City', 'State', 
    CURRENT_DATE, 3, 'Active'
);

-- Step 3: Observe student is visible to this transaction
SELECT reg_number, first_name, last_name FROM students WHERE reg_number = 'TEMP-TEST-999';

-- Step 4: Simulate a business rule violation or user cancellation:
-- We decide to discard all uncommitted changes
ROLLBACK;

-- Step 5: Verify that the student is NOT in the database after ROLLBACK
SELECT reg_number FROM students WHERE reg_number = 'TEMP-TEST-999';
-- Returns 0 rows, demonstrating ACID Atomicity & Durability preservation.


-- -----------------------------------------------------------------------------
-- SCENARIO 3: PARTIAL ROLLBACK USING SAVEPOINT
-- Objective: Rollback to a specific checkpoint without undoing earlier valid work.
-- -----------------------------------------------------------------------------

START TRANSACTION;

-- Step 1: Valid initial insert
INSERT INTO student_feedback (student_id, faculty_id, subject_id, rating, category, comments, status)
VALUES (1, 1, 1, 5, 'Course Delivery', 'Valid feedback before savepoint', 'Reviewed');

-- Step 2: Set Savepoint A
SAVEPOINT StepOneCompleted;

-- Step 3: Insert second, experimental record
INSERT INTO student_feedback (student_id, faculty_id, subject_id, rating, category, comments, status)
VALUES (2, 2, 3, 2, 'Lab Facilities', 'Experimental remark that should be undone', 'Pending');

-- Step 4: Rollback ONLY to Savepoint StepOneCompleted
ROLLBACK TO SAVEPOINT StepOneCompleted;

-- Step 5: Commit the transaction (Step 1 feedback is kept, Step 3 feedback is discarded)
COMMIT;

-- Verification:
SELECT comments FROM student_feedback WHERE comments LIKE '%before savepoint%';
-- Found!
SELECT comments FROM student_feedback WHERE comments LIKE '%Experimental remark%';
-- Empty set (0 rows)!
