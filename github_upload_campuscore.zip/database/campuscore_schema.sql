-- =============================================================================
-- CAMPUSCORE — STUDENT MANAGEMENT DATABASE SYSTEM
-- Relational Database Schema Definition (MySQL 8.0+ Compatible)
-- Project: BCA Semester 3 DBMS Project-Based Learning Assignment
-- Normalization Level: 3NF (Third Normal Form)
-- =============================================================================

DROP DATABASE IF EXISTS campuscore_db;
CREATE DATABASE campuscore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campuscore_db;

-- -----------------------------------------------------------------------------
-- 1. DEPARTMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    established_year INT NOT NULL,
    building VARCHAR(50) NOT NULL,
    head_of_dept VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_dept_year CHECK (established_year >= 1950 AND established_year <= 2100)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 2. COURSES / DEGREE PROGRAMS
-- -----------------------------------------------------------------------------
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    department_id INT NOT NULL,
    duration_years INT NOT NULL DEFAULT 3,
    total_semesters INT NOT NULL DEFAULT 6,
    degree_level ENUM('Undergraduate', 'Postgraduate', 'Diploma', 'Doctorate') NOT NULL DEFAULT 'Undergraduate',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_course_sem CHECK (total_semesters >= 1 AND total_semesters <= 12)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 3. SEMESTERS
-- -----------------------------------------------------------------------------
CREATE TABLE semesters (
    semester_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    semester_number INT NOT NULL,
    academic_year VARCHAR(9) NOT NULL, -- e.g., '2024-2025'
    term ENUM('Odd', 'Even') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_current BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_course_sem_year (course_id, semester_number, academic_year),
    CONSTRAINT chk_sem_num CHECK (semester_number >= 1 AND semester_number <= 12),
    CONSTRAINT chk_sem_dates CHECK (end_date > start_date)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 4. STUDENTS
-- -----------------------------------------------------------------------------
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    reg_number VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    dob DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') DEFAULT 'O+',
    address VARCHAR(255) NOT NULL,
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    admission_date DATE NOT NULL,
    current_semester_id INT NULL,
    status ENUM('Active', 'Graduated', 'Suspended', 'Withdrawn') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (current_semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 5. FACULTY
-- -----------------------------------------------------------------------------
CREATE TABLE faculty (
    faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(15) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    department_id INT NOT NULL,
    designation ENUM('Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'HOD') NOT NULL,
    qualification VARCHAR(100) NOT NULL,
    joining_date DATE NOT NULL,
    status ENUM('Active', 'On Leave', 'Resigned') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 6. SUBJECTS
-- -----------------------------------------------------------------------------
CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(15) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    credits INT NOT NULL DEFAULT 4,
    course_id INT NOT NULL,
    semester_number INT NOT NULL,
    subject_type ENUM('Theory', 'Lab', 'Project', 'Elective') NOT NULL DEFAULT 'Theory',
    max_internal_marks DECIMAL(5,2) NOT NULL DEFAULT 30.00,
    max_exam_marks DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_credits CHECK (credits >= 1 AND credits <= 10),
    CONSTRAINT chk_marks_pos CHECK (max_internal_marks > 0 AND max_exam_marks > 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 7. FACULTY SUBJECT ASSIGNMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE faculty_subject_assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    faculty_id INT NOT NULL,
    subject_id INT NOT NULL,
    academic_year VARCHAR(9) NOT NULL,
    semester_id INT NOT NULL,
    assigned_date DATE NOT NULL DEFAULT (CURRENT_DATE),
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_faculty_subj_year (faculty_id, subject_id, academic_year)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 8. ENROLLMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester_id INT NOT NULL,
    academic_year VARCHAR(9) NOT NULL,
    enrollment_date DATE NOT NULL,
    status ENUM('Active', 'Completed', 'Dropped') NOT NULL DEFAULT 'Active',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE KEY uk_student_sem_year (student_id, semester_id, academic_year)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 9. ATTENDANCE
-- -----------------------------------------------------------------------------
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL DEFAULT 'Present',
    remarks VARCHAR(100) NULL,
    recorded_by_faculty_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (recorded_by_faculty_id) REFERENCES faculty(faculty_id) ON UPDATE CASCADE ON DELETE SET NULL,
    UNIQUE KEY uk_student_subj_date (student_id, subject_id, attendance_date)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 10. ASSESSMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE assessments (
    assessment_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_id INT NOT NULL,
    semester_id INT NOT NULL,
    name VARCHAR(50) NOT NULL, -- e.g., 'Continuous Internal Assessment 1', 'Semester End Exam'
    assessment_type ENUM('Internal', 'Semester_Exam') NOT NULL,
    max_marks DECIMAL(5,2) NOT NULL,
    weightage_percent DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    conduct_date DATE NOT NULL,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_assessment_marks CHECK (max_marks > 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 11. MARKS
-- -----------------------------------------------------------------------------
CREATE TABLE marks (
    mark_id INT AUTO_INCREMENT PRIMARY KEY,
    assessment_id INT NOT NULL,
    student_id INT NOT NULL,
    marks_obtained DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    is_absent BOOLEAN NOT NULL DEFAULT FALSE,
    entered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    remarks VARCHAR(100) NULL,
    FOREIGN KEY (assessment_id) REFERENCES assessments(assessment_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_assessment_student (assessment_id, student_id),
    CONSTRAINT chk_marks_obtained CHECK (marks_obtained >= 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 12. FEE RECORDS (DUE AMOUNTS)
-- -----------------------------------------------------------------------------
CREATE TABLE fee_records (
    fee_record_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    fee_type ENUM('Tuition', 'Examination', 'Library', 'Laboratory', 'Hostel', 'Special') NOT NULL DEFAULT 'Tuition',
    amount_due DECIMAL(10,2) NOT NULL,
    due_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_fee_due CHECK (amount_due > 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 13. FEE PAYMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE fee_payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    fee_record_id INT NOT NULL,
    receipt_number VARCHAR(30) NOT NULL UNIQUE,
    amount_paid DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_mode ENUM('Cash', 'Demand Draft', 'Bank Transfer', 'UPI Reference') NOT NULL,
    transaction_ref VARCHAR(50) NULL,
    notes VARCHAR(200) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (fee_record_id) REFERENCES fee_records(fee_record_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_amt_paid CHECK (amount_paid > 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 14. STUDENT FEEDBACK
-- -----------------------------------------------------------------------------
CREATE TABLE student_feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    faculty_id INT NULL,
    subject_id INT NULL,
    rating INT NOT NULL,
    category ENUM('Course Delivery', 'Lab Facilities', 'Examination Evaluation', 'General Campus') NOT NULL,
    comments TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Reviewed', 'Pending') NOT NULL DEFAULT 'Pending',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON UPDATE CASCADE ON DELETE SET NULL,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT chk_rating CHECK (rating >= 1 AND rating <= 5)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 15. USERS & ROLES
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('Administrator', 'Faculty', 'Student') NOT NULL DEFAULT 'Administrator',
    linked_id INT NULL, -- references student_id or faculty_id if applicable
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================================================
-- DATABASE INDEXES FOR QUERY OPTIMIZATION
-- =============================================================================
CREATE INDEX idx_students_reg ON students(reg_number);
CREATE INDEX idx_students_sem ON students(current_semester_id);
CREATE INDEX idx_courses_dept ON courses(department_id);
CREATE INDEX idx_subjects_course_sem ON subjects(course_id, semester_number);
CREATE INDEX idx_attendance_date ON attendance(attendance_date);
CREATE INDEX idx_attendance_lookup ON attendance(student_id, subject_id);
CREATE INDEX idx_marks_student ON marks(student_id);
CREATE INDEX idx_fee_records_student ON fee_records(student_id);
CREATE INDEX idx_fee_payments_record ON fee_payments(fee_record_id);

-- =============================================================================
-- DATABASE VIEWS (DQL ABSTRACTION & REPORTING)
-- =============================================================================

-- View 1: Student Comprehensive Academic Summary
CREATE OR REPLACE VIEW v_student_academic_summary AS
SELECT 
    s.student_id,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    s.email,
    s.status,
    c.name AS course_name,
    c.code AS course_code,
    d.name AS department_name,
    sem.semester_number,
    sem.academic_year
FROM students s
LEFT JOIN semesters sem ON s.current_semester_id = sem.semester_id
LEFT JOIN courses c ON sem.course_id = c.course_id
LEFT JOIN departments d ON c.department_id = d.department_id;

-- View 2: Student Subject-Wise Attendance Percentage
CREATE OR REPLACE VIEW v_student_attendance_summary AS
SELECT 
    s.student_id,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    sub.subject_id,
    sub.code AS subject_code,
    sub.name AS subject_name,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND(
        CASE 
            WHEN COUNT(a.attendance_id) = 0 THEN 0.00
            ELSE (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) * 100.0) / COUNT(a.attendance_id)
        END, 2
    ) AS attendance_percentage
FROM students s
CROSS JOIN subjects sub
LEFT JOIN attendance a ON s.student_id = a.student_id AND sub.subject_id = a.subject_id
GROUP BY s.student_id, s.reg_number, s.first_name, s.last_name, sub.subject_id, sub.code, sub.name;

-- View 3: Fee Balance & Payment Status
CREATE OR REPLACE VIEW v_fee_summary AS
SELECT 
    fr.fee_record_id,
    s.student_id,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    fr.fee_type,
    fr.amount_due,
    fr.due_date,
    COALESCE(SUM(fp.amount_paid), 0) AS total_paid,
    (fr.amount_due - COALESCE(SUM(fp.amount_paid), 0)) AS pending_balance,
    CASE 
        WHEN COALESCE(SUM(fp.amount_paid), 0) >= fr.amount_due THEN 'Paid'
        WHEN COALESCE(SUM(fp.amount_paid), 0) > 0 THEN 'Partially_Paid'
        ELSE 'Pending'
    END AS calculated_status
FROM fee_records fr
JOIN students s ON fr.student_id = s.student_id
LEFT JOIN fee_payments fp ON fr.fee_record_id = fp.fee_record_id
GROUP BY fr.fee_record_id, s.student_id, s.reg_number, s.first_name, s.last_name, fr.fee_type, fr.amount_due, fr.due_date;

-- View 4: Student Exam Performance Breakdown
CREATE OR REPLACE VIEW v_student_performance AS
SELECT 
    s.student_id,
    s.reg_number,
    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
    sub.subject_id,
    sub.code AS subject_code,
    sub.name AS subject_name,
    sub.credits,
    MAX(CASE WHEN asm.assessment_type = 'Internal' THEN m.marks_obtained ELSE NULL END) AS internal_marks,
    MAX(CASE WHEN asm.assessment_type = 'Internal' THEN asm.max_marks ELSE NULL END) AS internal_max,
    MAX(CASE WHEN asm.assessment_type = 'Semester_Exam' THEN m.marks_obtained ELSE NULL END) AS exam_marks,
    MAX(CASE WHEN asm.assessment_type = 'Semester_Exam' THEN asm.max_marks ELSE NULL END) AS exam_max,
    (COALESCE(MAX(CASE WHEN asm.assessment_type = 'Internal' THEN m.marks_obtained ELSE NULL END), 0) +
     COALESCE(MAX(CASE WHEN asm.assessment_type = 'Semester_Exam' THEN m.marks_obtained ELSE NULL END), 0)) AS total_marks
FROM students s
JOIN marks m ON s.student_id = m.student_id
JOIN assessments asm ON m.assessment_id = asm.assessment_id
JOIN subjects sub ON asm.subject_id = sub.subject_id
GROUP BY s.student_id, s.reg_number, s.first_name, s.last_name, sub.subject_id, sub.code, sub.name, sub.credits;

-- View 5: Faculty Workload Allocation
CREATE OR REPLACE VIEW v_faculty_workload AS
SELECT 
    f.faculty_id,
    f.employee_code,
    CONCAT(f.first_name, ' ', f.last_name) AS faculty_name,
    f.designation,
    d.name AS department_name,
    COUNT(fsa.assignment_id) AS total_subjects_assigned,
    COALESCE(SUM(sub.credits), 0) AS total_teaching_credits
FROM faculty f
JOIN departments d ON f.department_id = d.department_id
LEFT JOIN faculty_subject_assignments fsa ON f.faculty_id = fsa.faculty_id
LEFT JOIN subjects sub ON fsa.subject_id = sub.subject_id
GROUP BY f.faculty_id, f.employee_code, f.first_name, f.last_name, f.designation, d.name;
