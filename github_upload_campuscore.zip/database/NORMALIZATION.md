# CAMPUSCORE — RELATIONAL DATABASE NORMALIZATION REPORT
**Course:** BCA Semester 3 — Database Management Systems (DBMS)  
**Project:** Student Management Database System Using DBMS and SQL  
**Standard Enforced:** Third Normal Form (3NF)  

---

## 1. Executive Summary & Design Philosophy
In university administration databases, bad database design causes severe anomalies:
- **Insertion Anomalies:** Inability to record a department or course before a student enrolls.
- **Update Anomalies:** Updating a course fee or department name requires editing thousands of student rows.
- **Deletion Anomalies:** Deleting a student inadvertently deletes department or subject information.

CampusCore solves this by strictly decomposing relations to **Third Normal Form (3NF)** while preserving dependency preservation and lossless joins.

---

## 2. Normalization Process Walkthrough

### 2.1 Unnormalized Form (UNF)
Consider a naive single-table spreadsheet design:
```
UNF_STUDENT_RECORD = (
    RegNo, StudentName, Phone, Email, DeptCode, DeptName, Building,
    CourseCode, CourseName, SemNo, SubjectsTaken (repeating group: SubjCode, SubjName, Faculty, Marks, Attendance),
    FeesDue, FeesPaidList (ReceiptNo, Amount, Date)
)
```
- **Problems:** Multivalued attributes, non-atomic data, repeating groups, and massive redundancy.

---

### 2.2 First Normal Form (1NF)
**Rule:** A relation is in 1NF if and only if all attribute domains contain only atomic (indivisible) values, and there are no repeating groups.

**Actions taken:**
1. Split composite name into atomic `first_name` and `last_name`.
2. Removed repeating groups for subjects, marks, and payments into separate relations (`subjects`, `marks`, `fee_payments`).
3. Assigned unambiguous primary keys (`reg_number`, `subject_id`, `payment_id`).
4. Guaranteed column domain atomicity (e.g., date formats, decimal numeric types for amounts).

---

### 2.3 Second Normal Form (2NF)
**Rule:** A relation is in 2NF if it is in 1NF and **every non-prime attribute is fully functionally dependent on the entire primary key** (no partial functional dependency on any candidate key).

**Detection of 2NF Violation in Un-decomposed Design:**
In a combined table `STUDENT_SUBJECT_ENROLLMENT(student_id, subject_id, semester_id, subject_name, credits, marks_obtained)`:
- Composite Candidate Key: `{student_id, subject_id}`
- Functional Dependencies:
  - `{student_id, subject_id} -> marks_obtained` (Full dependency)
  - `subject_id -> subject_name, credits` (**Partial dependency!** `subject_name` does not depend on `student_id`).

**Decomposition to 2NF:**
- Separate into `subjects` (keyed solely by `subject_id`) and `marks` / `enrollments` (keyed by composite/foreign keys).
- Every non-key attribute in `subjects` (`code`, `name`, `credits`, `course_id`) now depends solely on `subject_id`.

---

### 2.4 Third Normal Form (3NF)
**Rule:** A relation is in 3NF if it is in 2NF and **no non-prime attribute is transitively dependent on the primary key** (i.e., for every non-trivial functional dependency $X \rightarrow A$, either $X$ is a superkey, or $A$ is a prime attribute).

**Detection of 3NF Violation in Naive Course/Dept Design:**
In `courses(course_id, course_name, department_id, department_name, building, head_of_dept)`:
- Primary Key: `course_id`
- Functional Dependencies:
  - `course_id -> department_id`
  - `department_id -> department_name, building, head_of_dept`
- Transitive Dependency: `course_id -> department_name, building, head_of_dept` via `department_id`.

**Decomposition to 3NF:**
- Split into `departments` (PK: `department_id`) and `courses` (PK: `course_id`, FK: `department_id`).
- Now `courses` only retains `department_id` as a foreign key; all department attributes are stored once in `departments`.

---

## 3. Treatment of Derived & Calculated Fields
Academic grading often questions whether `attendance_percentage` or `pending_fees` should be stored as columns in the `students` table.

**DBMS Core Principle:** Storing calculated values violates 3NF by introducing transitive and functional dependencies on aggregated child tables.
- Storing `pending_fee = total_due - sum(payments)` violates database consistency because a new payment would cause an inconsistent state if not synchronously synchronized.
- **CampusCore Solution:** 
  Calculated metrics are generated dynamically via SQL Expressions, Aggregates (`SUM`, `COUNT`), and Database Views (`v_student_attendance_summary`, `v_fee_summary`). This ensures 100% mathematical consistency without duplicate storage.

---

## 4. Referential Integrity Actions Table

| Parent Table | Child Table | Foreign Key | ON UPDATE | ON DELETE | Academic Rationale |
|---|---|---|---|---|---|
| `departments` | `courses` | `department_id` | CASCADE | RESTRICT | Cannot delete a department with active academic courses. |
| `courses` | `subjects` | `course_id` | CASCADE | CASCADE | Removing a course removes its syllabus subjects. |
| `courses` | `semesters` | `course_id` | CASCADE | CASCADE | Deleting a program removes associated semester structures. |
| `semesters` | `students` | `current_semester_id`| CASCADE | SET NULL | If a semester concludes or is archived, student record remains intact. |
| `students` | `enrollments` | `student_id` | CASCADE | CASCADE | Enrollment history belongs strictly to student lifecycle. |
| `students` | `attendance` | `student_id` | CASCADE | CASCADE | Attendance sessions cascade with student record. |
| `faculty` | `attendance` | `recorded_by_faculty_id` | CASCADE | SET NULL | Faculty departure preserves historical attendance record with NULL recorder. |
| `fee_records` | `fee_payments` | `fee_record_id` | CASCADE | RESTRICT | Financial audit trail cannot be orphaned if payments exist. |
