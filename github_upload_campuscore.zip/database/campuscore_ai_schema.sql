-- =============================================================================
-- CAMPUSCORE AI — SMART CAMPUS MANAGEMENT SYSTEM
-- Relational Database Schema Definition (MySQL 8.0+ Compatible)
-- Project: BCA Semester 1 Introduction to AI PBL
-- =============================================================================

DROP DATABASE IF EXISTS campuscore_db;
CREATE DATABASE campuscore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campuscore_db;

-- 1. DEPARTMENTS
CREATE TABLE IF NOT EXISTS departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    building VARCHAR(50) NOT NULL,
    head_of_dept VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. COURSES / DEGREE PROGRAMS
CREATE TABLE IF NOT EXISTS courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    department_id INT NOT NULL,
    duration_years INT NOT NULL DEFAULT 3,
    total_semesters INT NOT NULL DEFAULT 6,
    degree_level ENUM('Undergraduate', 'Postgraduate', 'Diploma') NOT NULL DEFAULT 'Undergraduate',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 3. SEMESTERS
CREATE TABLE IF NOT EXISTS semesters (
    semester_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    semester_number INT NOT NULL,
    academic_year VARCHAR(9) NOT NULL,
    term ENUM('Odd', 'Even') NOT NULL,
    is_current BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_course_sem (course_id, semester_number, academic_year)
) ENGINE=InnoDB;

-- 4. FACULTY
CREATE TABLE IF NOT EXISTS faculty (
    faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(15) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    department_id INT NOT NULL,
    designation ENUM('Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'HOD') NOT NULL,
    qualification VARCHAR(100) NOT NULL,
    specialization VARCHAR(100) NULL,
    joining_date DATE NOT NULL,
    status ENUM('Active', 'On Leave', 'Resigned') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 5. STUDENTS
CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    reg_number VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    dob DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    course_id INT NOT NULL,
    current_semester_id INT NULL,
    cgpa DECIMAL(3,2) DEFAULT 0.00,
    admission_date DATE NOT NULL,
    status ENUM('Active', 'Graduated', 'Suspended') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (current_semester_id) REFERENCES semesters(semester_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 6. SUBJECTS
CREATE TABLE IF NOT EXISTS subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(15) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    credits INT NOT NULL DEFAULT 4,
    course_id INT NOT NULL,
    semester_number INT NOT NULL,
    subject_type ENUM('Theory', 'Lab', 'Project', 'Elective') NOT NULL DEFAULT 'Theory',
    faculty_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 7. ATTENDANCE
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL DEFAULT 'Present',
    remarks VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_student_subj_date (student_id, subject_id, attendance_date)
) ENGINE=InnoDB;

-- 8. MARKS / ACADEMIC PERFORMANCE
CREATE TABLE IF NOT EXISTS marks (
    mark_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    exam_type ENUM('Internal 1', 'Internal 2', 'Assignment', 'Semester Exam') NOT NULL,
    marks_obtained DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    max_marks DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    remarks VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 9. EVENTS
CREATE TABLE IF NOT EXISTS events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Academic') NOT NULL DEFAULT 'Technical',
    venue VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    max_seats INT NOT NULL DEFAULT 100,
    registered_count INT NOT NULL DEFAULT 0,
    status ENUM('Upcoming', 'Ongoing', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Upcoming',
    created_by VARCHAR(100) DEFAULT 'Campus Admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 10. EVENT REGISTRATIONS
CREATE TABLE IF NOT EXISTS event_registrations (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    student_id INT NOT NULL,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Confirmed', 'Waitlisted', 'Cancelled') NOT NULL DEFAULT 'Confirmed',
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uk_event_student (event_id, student_id)
) ENGINE=InnoDB;

-- 11. CAMPUS RESOURCES
CREATE TABLE IF NOT EXISTS campus_resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    resource_type ENUM('Classroom', 'Computer Lab', 'Seminar Hall', 'Projector', 'GPU Server', 'Auditorium') NOT NULL,
    building VARCHAR(50) NOT NULL,
    room_number VARCHAR(20) NOT NULL,
    capacity INT NOT NULL DEFAULT 60,
    status ENUM('Available', 'Booked', 'Maintenance') NOT NULL DEFAULT 'Available',
    features TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 12. RESOURCE BOOKINGS
CREATE TABLE IF NOT EXISTS resource_bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT NOT NULL,
    user_id INT NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    booking_date DATE NOT NULL,
    time_slot VARCHAR(50) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Completed') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resource_id) REFERENCES campus_resources(resource_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 13. STUDENT FEEDBACK
CREATE TABLE IF NOT EXISTS student_feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    category ENUM('Faculty & Teaching', 'Lab Facilities', 'Campus Infrastructure', 'Curriculum & Courses', 'Administration') NOT NULL,
    target_name VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comments TEXT NOT NULL,
    sentiment ENUM('Positive', 'Neutral', 'Negative') NOT NULL DEFAULT 'Neutral',
    sentiment_score DECIMAL(3,2) DEFAULT 0.50,
    ai_summary TEXT NULL,
    status ENUM('Reviewed', 'Pending', 'Action Taken') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 14. CAREER PROFILES & RECOMMENDATIONS
CREATE TABLE IF NOT EXISTS career_profiles (
    profile_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL UNIQUE,
    technical_skills TEXT NOT NULL,
    interests TEXT NOT NULL,
    preferred_domain VARCHAR(100) NOT NULL,
    ai_recommended_path VARCHAR(100) NULL,
    ai_match_score INT DEFAULT 85,
    ai_learning_roadmap TEXT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 15. AI CONTENT LIBRARY
CREATE TABLE IF NOT EXISTS ai_content_library (
    content_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content_type ENUM('study_notes', 'summary', 'quiz', 'assignment', 'practice_questions', 'announcement', 'academic_report') NOT NULL,
    title VARCHAR(200) NOT NULL,
    prompt_context TEXT NOT NULL,
    output_text MEDIUMTEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 16. NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    target_role ENUM('All', 'Administrator', 'Faculty', 'Student') NOT NULL DEFAULT 'All',
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'warning', 'success', 'alert') NOT NULL DEFAULT 'info',
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 17. USERS & ROLES
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('Administrator', 'Faculty', 'Student') NOT NULL DEFAULT 'Student',
    linked_id INT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 18. RESPONSIBLE AI LOGS & AUDIT
CREATE TABLE IF NOT EXISTS responsible_ai_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    tool_name VARCHAR(100) NOT NULL,
    prompt_summary VARCHAR(255) NOT NULL,
    pii_detected BOOLEAN DEFAULT FALSE,
    safety_rating VARCHAR(50) DEFAULT 'Safe',
    ai_engine ENUM('Gemini-1.5-Flash', 'Local-Heuristic-AI') NOT NULL DEFAULT 'Local-Heuristic-AI',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


-- 19. ADMISSIONS INQUIRIES (PUBLIC WEBSITE PORTAL)
CREATE TABLE IF NOT EXISTS admissions_inquiries (
    inquiry_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    program_interested VARCHAR(120) NOT NULL,
    academic_score DECIMAL(5,2) DEFAULT 0.00,
    message TEXT NULL,
    status ENUM('New', 'Under Review', 'Interview Scheduled', 'Admitted', 'Rejected') NOT NULL DEFAULT 'New',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 20. CONTACT MESSAGES (PUBLIC WEBSITE)
CREATE TABLE IF NOT EXISTS contact_messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('Unread', 'Read', 'Replied') NOT NULL DEFAULT 'Unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
