# AI Tool Ecosystem for Smart Campus Management
## Project-Based Learning (PBL) Final Presentation | BCA Semester 1 — Introduction to Artificial Intelligence
---

## Executive Summary & Vision
- **Project Title:** AI Tool Ecosystem for Smart Campus Management (CampusCore AI)
- **Academic Benchmark:** BCA Semester 1 — Introduction to AI Project-Based Learning (PBL)
- **Design Inspiration:** GM University (Davangere, Karnataka — https://www.gmu.ac.in/)
- **Core Mission:** Unify 11 specialized AI campus management modules into a single, responsive, production-ready web application.
- **Architectural Excellence:** 
  - Dual-Engine AI (Google Gemini 1.5 Cloud + Local NLP Heuristics)
  - Strict Role-Based Access Control (RBAC) across 3 isolated portals
  - Third Normal Form (3NF) relational database schema (18 tables)
  - Responsible AI and automated PII privacy scrubbing

---

## The Problem Statement
### Critical Inefficiencies in Traditional Campus Administration
- **Siloed Systems:** Disconnected software for admissions, fees, attendance, internal marks, and event management.
- **Academic Blind Spots:** Manual calculations delay identification of students with <75% attendance or critical academic risk.
- **Administrative Overload:** Faculty spend disproportionate hours manually compiling study notes, quizzes, circulars, and CIA reports.
- **Lack of Real-Time Guidance:** Students lack 24/7 access to authenticated syllabus queries, academic doubt solving, and personalized career roadmaps.

---

## The Proposed Solution: CampusCore AI
### An All-in-One Intelligent Campus Management Platform
- **Public University Website:** Professional collegiate web presence inspired by GM University with live announcement tickers, key statistics, program highlights, and online admissions inquiries.
- **Three Isolated Login Gateways:** Distinct authentication routes and visual identities for Administrator, Faculty, and Students.
- **Dual-Engine AI Architecture:** Cloud LLM intelligence with an automatic offline heuristic fallback guaranteeing zero downtime during viva evaluations.
- **Zero-Manual Overhead:** Automated CIA scoring, attendance shortage forecasting, sentiment classification, and digital receipts.

---

## System Architecture & Technology Stack
### End-to-End Full-Stack Implementation
- **Frontend Layer:**
  - React 18 (Single Page Application architecture)
  - Tailwind CSS with GMU Collegiate Blue (`#002B49`) & Regal Gold (`#D4AF37`) palette
  - Lucide Vector Icons & Chart.js graphical visualizations
- **Backend Layer:**
  - Python 3 with Flask RESTful API Framework & Flask-CORS
  - 48+ RESTful endpoints serving all 11 PBL modules
- **Database Layer:**
  - MySQL 8.0+ Relational Database (3NF Normalized, 18 tables)
  - Transparent embedded SQLite fallback (`campuscore_ai.db`) for instant zero-configuration setup
- **AI Intelligence Layer:**
  - Online Mode: Google Gemini 1.5 Flash API
  - Offline Mode: Deterministic Local NLP Knowledge Graph & Heuristic Inference Engine

---

## Three Isolated Authentication Portals
### Strict Role-Based Access Control (RBAC) & Visual Identity Separation
- **Administrator Gateway (`/admin/login`):**
  - Identifiers: `admin` or `admin@campuscore.edu` | Pass: `admin123`
  - Theme: Imperial Navy & Gold with Security Shield heraldry
  - Capabilities: Full campus governance, student/faculty dossiers, fee ledgers, admissions leads, and AI audit logs
- **Faculty Member Gateway (`/faculty/login`):**
  - Identifiers: `dr_vikram` or `FAC103` | Pass: `faculty123`
  - Theme: Midnight Blue & Emerald with Academic Cap insignia
  - Capabilities: Direct attendance marking, CIA 1 & 2 marks grading, AI study notes & quiz generation, and personal timetable
- **Student Academic Portal (`/student/login`):**
  - Identifiers: `BCA24001` (Aarav) or `BCA24002` (Diya) | Pass: `student123`
  - Theme: Royal Blue & Amber with Digital ID Badge
  - Capabilities: Digital Student ID Card, <75% attendance alert & classes-needed planner, CIA scorecard, 24/7 AI chatbot, and online fees payment
- **Enforced Security:** Cross-role breach attempts return **HTTP 403 Forbidden** with descriptive security alerts.

---

## Administrator Governance Suite
### Total Institutional Oversight & Decision Support
- **Key Performance Indicators:** Live counters for 12+ students, 6+ faculty members, 81.4% average attendance, and 42+ smart tech labs.
- **Student & Faculty CRUD:** Full lifecycle management (Add, View, Update, Filter, Delete) connected to relational database.
- **Financial & Fee Ledgers:** Track university fee collections, outstanding student balances, and record payments.
- **Admissions Management:** Review online applications submitted via the landing page and update status (*Admitted / Under Review / Rejected*).
- **User Account Administration:** Instant toggle to activate or suspend user accounts across all roles.
- **Data Export:** 1-Click CSV export for official student registers, attendance rosters, and event registrations.

---

## Faculty Instruction & Grading Suite
### Streamlined Classroom Management & Assessment
- **Faculty Profile Dossier:** Dr. Vikram Malhotra (FAC103), Associate Professor, Department of AI & Data Science.
- **Assigned Courses:** BCA101 (Intro to AI) and BCA105 (Python & AI Lab).
- **Fast Roll Call Attendance Tool:** 1-Click marking of Present, Absent, or Late with bulk actions (*Mark All Present*).
- **Continuous Internal Assessment (CIA) Logger:** Grade CIA 1 and CIA 2 marks out of maximum points with qualitative faculty remarks.
- **Class Timetable:** Weekly schedule of lecture slots and lab allocations in RT-204 and AB-301.
- **Student Feedback Review:** Real-time visibility into qualitative feedback and student sentiment.

---

## Student Academic Hub & Digital ID
### Personalized Learning & Student Lifecycle Services
- **Digital Student ID Card:** Physical badge design featuring student photo, Registration Number (`BCA24001`), course details, barcode, QR code, blood group, and validity.
- **Continuous Internal Assessment Scorecard:** Detailed subject-wise breakdown of CIA-1 and CIA-2 marks with CGPA calculation (**8.85 / 10.0**).
- **Online Fees Portal:** View tuition invoices, outstanding balance, and pay online with instant receipt generation (`REC-2024-XXXX`).
- **College Events & RSVPs:** Browse hackathons and tech symposiums with 1-click RSVP and instant digital QR pass.
- **Class Timetable:** Daily and weekly lecture timetable with lecture hall and lab room numbers.

---

## Attendance Analysis & Predictive Planner
### Mathematical Modeling of Examination Eligibility
- **Statutory Rules:** Enforces university 75% examination eligibility threshold and 65% condonation boundary.
- **Real-Time Warning Badges:** Instant visual alert for students below 75% attendance.
- **Predictive Classes-Needed Formula:**
  $$\text{Classes Needed} = \left\lceil \frac{0.75 \times \text{Total} - \text{Attended}}{0.25} \right\rceil$$
- **Actionable Guidance:** Directly informs at-risk students exactly how many consecutive future lectures they must attend without absence to regain exam eligibility.

---

## 24/7 AI Campus Chatbot
### Real-Time Conversational Knowledge Assistant
- **Intent Recognition Engine:** Categorizes student queries into Academics, Admissions, Facilities, Timetables, and Policies.
- **Knowledge Graph Grounding:** Answers questions regarding syllabus modules, lab workstation configurations, hostel timings, and exam passing criteria.
- **Dual-Engine Response:** Powered by Gemini 1.5 Flash when online, and offline fallback NLP templates when disconnected.
- **Suggested Prompt Pills:** 1-Click prompt shortcuts for swift viva examination demonstrations.

---

## AI Academic Assistant: Study Notes & Quizzes
### Automated Educational Content Generation
- **Topic-Wise Study Notes Synthesizer:**
  - Input: Topic name (e.g., *State Space Search & Heuristics*), course, and semester.
  - Output: Structured markdown notes with theoretical foundations, algorithms, code snippets, and key exam takeaways.
- **5-Question Concept Mastery Quiz:**
  - Generates pedagogically sound multiple-choice questions based on Bloom's taxonomy.
  - Includes answer keys, distractors, and concept explanations.
- **Difficulty Scaler:** Foundational (Intro), Intermediate (Core BCA), and Advanced (Honors/Viva).

---

## Student Performance Analysis
### Data-Driven Academic Diagnostics
- **Automated Score Aggregation:** Aggregates marks across theory lectures, coding labs, and continuous assessments.
- **Four Academic Performance Tiers:**
  - Tier 1: High Distinction / Honors (>= 85%)
  - Tier 2: Good Standing / Consistent (70% - 84%)
  - Tier 3: Average / Needs Focus (50% - 69%)
  - Tier 4: Critical Academic Risk (< 50%)
- **Personalized Remediation Advice:** Identifies subject-specific weaknesses and generates tailored revision schedules.

---

## Student Feedback Analysis & NLP Sentiment
### Qualitative Review Mining & Action Formulation
- **Multi-Category Review Intake:** Collects ratings (1-5 stars) and qualitative feedback across Teaching, Labs, Infrastructure, and Curriculum.
- **NLP Sentiment Classifier:** Computes sentiment polarity (*Positive, Neutral, Negative*) and confidence score (0.0 to 1.0).
- **Administrative Action Synthesizer:** Formulates concrete remediation recommendations (e.g., *"Student requests additional practical SQL query sessions before CIA 2"*).

---

## AI Career Guidance & Learning Roadmap
### Skills-Based Industry Track Alignment
- **Student Profile Intake:** Analyzes programming languages, tools, interests, and academic performance.
- **Industry Pathway Matching:** Matches student profile against 8+ high-demand tech domains (*AI/ML Engineer, Full-Stack Developer, Data Scientist, Cloud Architect*).
- **Match Score & 4-Stage Roadmap:** Outputs match percentage (e.g., 92%) and a milestone-by-milestone preparation roadmap from foundational math to production deployment.

---

## Campus Resource Management & Scheduling
### Conflict-Free Facilities Allocation
- **Smart Campus Infrastructure:** Classrooms, Ada Lovelace AI Supercomputing Lab (NVIDIA RTX 4080 GPUs), Turing Science Center, and Main Auditorium.
- **Timetable Scheduling:** Weekly day-wise schedule allocation (Monday to Friday) by course, semester, faculty, and room number.
- **Booking Conflict Prevention:** Automatically detects and prevents double-booking of rooms or equipment for overlapping time slots.

---

## Relational Database Design (Third Normal Form)
### Robust 3NF Normalized Schema (18 Tables)
- **Academic Hierarchy:** `departments` -> `courses` -> `semesters` -> `subjects`
- **Users & People:** `users`, `students`, `faculty`
- **Operations & Records:** `attendance`, `marks`, `fee_records`, `fee_payments`, `timetables`
- **Campus Life:** `events`, `event_registrations`, `campus_resources`, `resource_bookings`
- **AI Ecosystem:** `student_feedback`, `career_profiles`, `ai_content_library`, `notifications`, `responsible_ai_logs`, `admissions_inquiries`, `contact_messages`
- **Data Integrity:** Foreign key cascades, candidate keys, and zero redundancy.

---

## Responsible AI & Ethical Governance
### Privacy, Safety, and Content Attribution
- **Automated PII Privacy Scrubber:** Regex-based filter that intercepts and redacts personal identifiers (phone numbers, email addresses, passwords) before prompt processing.
- **Safety Rating & Content Attribution:** Every generated piece of educational content is stamped with an AI watermark and safety classification.
- **Compliance Audit Trail:** All AI requests, prompt summaries, PII flags, and safety evaluations are permanently recorded in `responsible_ai_logs`.

---

## Verification, Testing & Results
### 100% Passing Test Suite Across All Modules
- **Test Suite Command:** `python -m pytest tests/test_campuscore.py -v`
- **Results:** **20 passed in 0.71s**
- **Verified Functionalities:**
  - System status & database integrity (18 tables verified)
  - 3 Separate login systems & HTTP 403 Forbidden role mismatch rejection
  - Students & Faculty CRUD operations
  - AI Chatbot conversational intent responses
  - Attendance calculation & 75% shortage alert logic
  - Fees recording & online payment receipt generation (`REC-2024-XXXX`)
  - Timetable scheduling endpoints
  - Admissions inquiry workflow & CSV report exports

---

## Project Demonstration & Viva Highlights
### Key Takeaways for BCA AI PBL Viva Evaluation
1. **Full-Stack Working Application:** Not a prototype or mock design — all buttons, forms, database operations, and AI tools are fully functional.
2. **Dual-Engine Resilience:** Guaranteed zero-failure presentation capability through seamless offline heuristic fallback.
3. **Role-Based Security:** Strict institutional separation between Administrator, Faculty, and Student workflows.
4. **Authentic Collegiate Experience:** Inspired by GM University (Davangere), combining public university branding with enterprise campus operations.
5. **Ready for Production:** Clean code architecture, modular design, full test coverage, and clear documentation.

---

## Thank You! Questions & Live Demonstration
- **Live System URL:** `http://127.0.0.1:5000`
- **Project Folder:** `C:\Users\Vishwaradhya M S\OneDrive\Desktop\campus`
- **Repository Archive:** `campus.zip`
- **Student Name:** Vishwaradhya M S
- **Degree Program:** Bachelor of Computer Applications (BCA) — Semester 1
- **Course:** Introduction to Artificial Intelligence Project-Based Learning (PBL)
